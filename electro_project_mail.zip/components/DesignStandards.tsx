'use client';
import React, { useState } from 'react';

/* ── Data types ──────────────────────────────────────────── */
interface TableRow { [key: string]: string | number }
interface CritTable { headers: string[]; rows: TableRow[] }

/* ── Shared table renderer ───────────────────────────────── */
function CritTable({ headers, rows, accent = '#4ade80' }: { headers: string[]; rows: TableRow[]; accent?: string }) {
  return (
    <div style={{ overflowX: 'auto', borderRadius: 8, border: '1px solid rgba(255,255,255,0.08)', marginBottom: 20 }}>
      <table style={{ borderCollapse: 'collapse', width: '100%', fontSize: 11 }}>
        <thead>
          <tr style={{ background: `${accent}12`, borderBottom: `1px solid ${accent}30` }}>
            {headers.map(h => (
              <th key={h} style={{ padding: '8px 12px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: accent, letterSpacing: '0.05em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i} style={{ background: i % 2 === 0 ? 'rgba(255,255,255,0.01)' : 'transparent', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
              {headers.map(h => (
                <td key={h} style={{ padding: '7px 12px', color: '#e2e8f0', verticalAlign: 'top' }}>
                  {String(row[h] ?? '—')}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Section({ title, children, accent = '#4ade80' }: { title: string; children: React.ReactNode; accent?: string }) {
  return (
    <div style={{ marginBottom: 28 }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14,
        paddingBottom: 8, borderBottom: `1px solid ${accent}30`,
      }}>
        <div style={{ width: 4, height: 18, background: accent, borderRadius: 2 }} />
        <h3 style={{ margin: 0, fontSize: 13, fontWeight: 700, color: accent }}>{title}</h3>
      </div>
      {children}
    </div>
  );
}

function Alert({ type, children }: { type: 'info' | 'warning' | 'caution'; children: React.ReactNode }) {
  const cfg = {
    info:    { color: '#60a5fa', icon: 'ℹ', bg: 'rgba(96,165,250,0.08)', border: 'rgba(96,165,250,0.25)' },
    warning: { color: '#fbbf24', icon: '⚠', bg: 'rgba(251,191,36,0.08)',  border: 'rgba(251,191,36,0.25)' },
    caution: { color: '#f87171', icon: '🚫', bg: 'rgba(248,113,113,0.08)', border: 'rgba(248,113,113,0.25)' },
  }[type];
  return (
    <div style={{
      display: 'flex', gap: 10, padding: '10px 14px', marginBottom: 14,
      background: cfg.bg, border: `1px solid ${cfg.border}`,
      borderRadius: 8, borderLeft: `3px solid ${cfg.color}`,
    }}>
      <span style={{ fontSize: 14, flexShrink: 0, marginTop: 1 }}>{cfg.icon}</span>
      <div style={{ fontSize: 11, color: '#e2e8f0', lineHeight: 1.6 }}>{children}</div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   TAB 1 — 브라인 정제 설계기준 (100 SEC)
══════════════════════════════════════════════════════════ */
function Tab100SEC() {
  return (
    <div>
      <Alert type="info">
        <strong>공급 브라인 순도 요건 (이온교환막 입구 기준):</strong><br />
        Ca²⁺ &lt; 0.02 mg/L · Mg²⁺ &lt; 0.02 mg/L · SO₄²⁻ &lt; 3 g/L · I⁻ &lt; 0.02 mg/L · TOC &lt; 1 mg/L · SS &lt; 0.1 mg/L
      </Alert>

      <Section title="D-010 포화조 (Salt Dissolving Tank)" accent="#4ade80">
        <CritTable accent="#4ade80" headers={['설계 항목','기준값','비고']} rows={[
          { '설계 항목':'체류시간', '기준값':'60~120 min', '비고':'암염 60, 천일염 90~120' },
          { '설계 항목':'운전온도', '기준값':'60~70 °C', '비고':'NaCl 용해도 최대화' },
          { '설계 항목':'NaCl 포화농도', '기준값':'315 g/L @70°C', '비고':'' },
          { '설계 항목':'교반기 동력', '기준값':'50~100 W/m³', '비고':'소금 부유·용해 필요' },
          { '설계 항목':'소금 장입속도', '기준값':'200~250 kg/m³·h', '비고':'' },
          { '설계 항목':'재질', '기준값':'FRP', '비고':'고무라이닝 강재도 가능' },
          { '설계 항목':'형상', '기준값':'원추형 하부', '비고':'소금 퇴적 방지' },
        ]} />
      </Section>

      <Section title="D-020 반응조 (Chemical Reaction Tank)" accent="#4ade80">
        <CritTable accent="#4ade80" headers={['설계 항목','기준값','비고']} rows={[
          { '설계 항목':'체류시간', '기준값':'30~60 min (최소 30)', '비고':'2조 직렬 권장' },
          { '설계 항목':'운전온도', '기준값':'60~70 °C', '비고':'' },
          { '설계 항목':'pH 범위', '기준값':'10.5~11.5', '비고':'Mg(OH)₂ 완전 침전 조건' },
          { '설계 항목':'교반기 동력', '기준값':'80~120 W/m³', '비고':'완전 혼합 (CSTR)' },
          { '설계 항목':'NaOH 주입량', '기준값':'Mg 당량 × 2.1배', '비고':'10% 과잉' },
          { '설계 항목':'Na₂CO₃ 주입량', '기준값':'Ca 당량 × 1.05배', '비고':'' },
          { '설계 항목':'BaCl₂ 주입량', '기준값':'SO₄ 당량 × 1.05~1.10배', '비고':'과잉분 IX에 부하' },
          { '설계 항목':'처리 후 Ca 목표', '기준값':'< 2 mg/L', '비고':'IX 이전' },
          { '설계 항목':'처리 후 Mg 목표', '기준값':'< 1 mg/L', '비고':'' },
        ]} />
        <Alert type="info">반응조 2조 직렬 구성 시 단락류 방지 효과로 동일 체류시간 대비 처리 성능 향상. 1조 30 min보다 2조 × 15 min이 효과적.</Alert>
      </Section>

      <Section title="T-030 침전조 (Thickener/Clarifier)" accent="#4ade80">
        <CritTable accent="#4ade80" headers={['설계 항목','기준값','비고']} rows={[
          { '설계 항목':'표면부하율 (SLR)', '기준값':'0.3~0.8 m³/m²·h', '비고':'CaCO₃ 입자 침강속도 기준' },
          { '설계 항목':'체류시간', '기준값':'4~8 h', '비고':'상등액 기준' },
          { '설계 항목':'슬러지 농축 목표', '기준값':'15~30% 고형물', '비고':'' },
          { '설계 항목':'상등액 탁도', '기준값':'< 50 mg/L TSS', '비고':'' },
          { '설계 항목':'응집제', '기준값':'폴리아크릴아마이드 0.1~0.5 mg/L', '비고':'선택적 사용' },
          { '설계 항목':'슬러지 배출 주기', '기준값':'4~8 h', '비고':'자동 타이머' },
          { '설계 항목':'탑 직경 (기준 규모)', '기준값':'~23 m', '비고':'SLR 0.5 m³/m²h, Q=205 m³/h 기준' },
        ]} />
      </Section>

      <Section title="F-150 카본 필터 (GAC Filter)" accent="#4ade80">
        <CritTable accent="#4ade80" headers={['설계 항목','기준값','비고']} rows={[
          { '설계 항목':'여과 선속도 (LV)', '기준값':'5~10 m/h', '비고':'압력 필터 최대 12 m/h' },
          { '설계 항목':'활성탄 층 깊이', '기준값':'1.0~1.5 m', '비고':'' },
          { '설계 항목':'활성탄 규격', '기준값':'8×16 또는 10×20 mesh', '비고':'입상 활성탄 (GAC)' },
          { '설계 항목':'역세 선속도', '기준값':'15~20 m/h', '비고':'10~15 min' },
          { '설계 항목':'역세 주기', '기준값':'8~24 h 또는 ΔP > 0.5 kg/cm²', '비고':'' },
          { '설계 항목':'출구 탁도', '기준값':'< 1 mg/L TSS', '비고':'' },
          { '설계 항목':'필터 수', '기준값':'2~4조', '비고':'1조 역세 중 운전 유지' },
        ]} />
      </Section>

      <Section title="T-160 이온교환수지탑 ★ 핵심 장치" accent="#00d4ff">
        <Alert type="warning">Ca+Mg 총합 &lt; 40 ppb 미달성 시 막 수명 급격히 단축. 가장 중요한 설계 항목.</Alert>
        <CritTable accent="#00d4ff" headers={['설계 항목','기준값','비고']} rows={[
          { '설계 항목':'수지 형태', '기준값':'킬레이트형 (IDA type)', '비고':'Purolite S930+, Lewatit TP-207' },
          { '설계 항목':'공간속도 (SV)', '기준값':'10~20 BV/h', '비고':'' },
          { '설계 항목':'공급 pH', '기준값':'10~11', '비고':'산성 시 수지 손상' },
          { '설계 항목':'공급 온도', '기준값':'55~70 °C', '비고':'' },
          { '설계 항목':'처리수 Ca+Mg', '기준값':'< 0.04 mg/L (< 40 ppb)', '비고':'Asahi Kasei 요구 기준' },
          { '설계 항목':'운전 사이클', '기준값':'8~24 h/사이클', '비고':'공급 수질에 따라 변동' },
          { '설계 항목':'L/D 비', '기준값':'1.5~3.0', '비고':'' },
          { '설계 항목':'수지 층 높이', '기준값':'1.5~3.0 m', '비고':'' },
          { '설계 항목':'여유공간 (Freeboard)', '기준값':'수지 층의 50~60%', '비고':'역세 팽창 고려' },
          { '설계 항목':'컬럼 수', '기준값':'2조 이상', '비고':'1 운전 + 1 재생 (고순도 시 3조)' },
          { '설계 항목':'컬럼 직경 (기준 규모)', '기준값':'~2.1 m', '비고':'SV 15 BV/h, Q=206 m³/h 기준' },
        ]} />
        <div style={{ padding: '10px 14px', background: 'rgba(255,255,255,0.03)', borderRadius: 8, marginBottom: 14 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#00d4ff', marginBottom: 8 }}>재생 순서</div>
          {[
            ['① 역세 (Backwash)', '상향류, 10~15 m/h, 10~15 min — 슬러지 제거, 수지 이완'],
            ['② 산 재생', '4~6% HCl, 2~4 BV, 1.5~3 BV/h, 50~60°C — Ca/Mg 탈착'],
            ['③ 치환 세정', '연화수, 2~3 BV — 산 치환'],
            ['④ 가성 세정', '1~2% NaOH, 2~3 BV — BaCl₂ 제거 (Asahi Kasei 특유)'],
            ['⑤ 물 세정', '5~10 BV — 출구 pH >10, Cl⁻ <50 ppm 확인 후 운전 전환'],
          ].map(([step, desc]) => (
            <div key={step} style={{ display: 'flex', gap: 12, marginBottom: 6, fontSize: 11 }}>
              <span style={{ color: '#00d4ff', fontWeight: 700, whiteSpace: 'nowrap', minWidth: 120 }}>{step}</span>
              <span style={{ color: '#94a3b8' }}>{desc}</span>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   TAB 2 — Cl2 처리 패킹탑 설계기준 (400 SEC)
══════════════════════════════════════════════════════════ */
function Tab400SEC() {
  return (
    <div>
      <Alert type="info">
        기준 Cl₂ 유량: 19,500 kg/h | 몰 유량: 275 kmol/h | 실제 부피유량 (40°C, 0.27 kg/cm²G): ~6,900 m³/h
      </Alert>

      <Section title="패킹탑 공통 설계 기준 (F-Factor법)" accent="#60a5fa">
        <CritTable accent="#60a5fa" headers={['충전물 형태','설계 F-factor (Pa⁰·⁵)','접근율','비고']} rows={[
          { '충전물 형태':'무작위 충전 25mm Pall Ring', '설계 F-factor (Pa⁰·⁵)':'0.5~0.7', '접근율':'65~75%', '비고':'일반 적용' },
          { '충전물 형태':'무작위 충전 50mm Pall Ring', '설계 F-factor (Pa⁰·⁵)':'0.7~0.9', '접근율':'65~75%', '비고':'대형 탑' },
          { '충전물 형태':'규칙 충전 (Structured)', '설계 F-factor (Pa⁰·⁵)':'1.0~1.5', '접근율':'70~80%', '비고':'저압손실 필요 시' },
        ]} />
        <div style={{ fontSize: 11, color: '#94a3b8', padding: '8px 12px', background: 'rgba(96,165,250,0.05)', borderRadius: 6, borderLeft: '2px solid #60a5fa44', marginBottom: 14 }}>
          F = u_g × √ρ_g &nbsp;|&nbsp; 운전압력손실 목표: 20~30 mmH₂O / m 충전
        </div>
      </Section>

      <Section title="T-410 Cl2 세정탑 (Chlorine Wash Tower)" accent="#60a5fa">
        <CritTable accent="#60a5fa" headers={['설계 항목','기준값','비고']} rows={[
          { '설계 항목':'탑 직경', '기준값':'2.0~2.8 m', '비고':'F-factor 0.6 Pa⁰·⁵ 기준' },
          { '설계 항목':'가스 입구 온도', '기준값':'85~87 °C', '비고':'전해조 출구' },
          { '설계 항목':'가스 출구 온도', '기준값':'35~45 °C', '비고':'' },
          { '설계 항목':'충전 높이', '기준값':'2~3 m', '비고':'' },
          { '설계 항목':'HETP (HCl 흡수)', '기준값':'0.3~0.5 m', '비고':'필요 단수 4~6단' },
          { '설계 항목':'액/가스 비 L/G', '기준값':'2~5 L/m³-gas', '비고':'' },
          { '설계 항목':'충전물 재질', '기준값':'PVDF 필수', '비고':'PP는 습윤 Cl₂에 부적합' },
          { '설계 항목':'충전물 규격', '기준값':'PVDF Pall Ring 38~50 mm', '비고':'' },
          { '설계 항목':'탑 재질', '기준값':'FRP + PVDF 내장 타일', '비고':'' },
          { '설계 항목':'세정액', '기준값':'냉각 HCl수 (pH 1~2)', '비고':'16~20°C로 냉각 후 상부 공급' },
          { '설계 항목':'HCl 제거 효율', '기준값':'> 99%', '비고':'' },
        ]} />
        <Alert type="caution">충전물 재질은 반드시 PVDF 사용. 습윤 Cl₂ + HCl 환경에서 PP, PVC는 급격히 열화됨.</Alert>
      </Section>

      <Section title="E-413 Cl2 냉각기" accent="#60a5fa">
        <CritTable accent="#60a5fa" headers={['설계 항목','기준값','비고']} rows={[
          { '설계 항목':'유형', '기준값':'Shell-&-Tube (수직형)', '비고':'' },
          { '설계 항목':'냉각제', '기준값':'Chilled Water (7~12°C)', '비고':'' },
          { '설계 항목':'Cl₂ 출구 온도', '기준값':'10~15 °C', '비고':'수분 응결 최대화' },
          { '설계 항목':'튜브 재질', '기준값':'하스탈로이 C-276 or 티타늄', '비고':'습윤 Cl₂ 내식성 필수' },
          { '설계 항목':'출구 수분 (목표)', '기준값':'< 5,000 ppm by vol', '비고':'건조탑 이전' },
        ]} />
      </Section>

      <Section title="T-420/T-430 Cl2 건조탑 (H₂SO₄ Drying Tower)" accent="#60a5fa">
        <Alert type="warning">H₂SO₄ 온도 &gt; 35°C 시 Cl₂ 용해도 증가 → 탑 하부 순환 냉각 시스템 필수 설치.</Alert>
        <CritTable accent="#60a5fa" headers={['항목','T-420 (1단)','T-430 (2단)','비고']} rows={[
          { '항목':'H₂SO₄ 농도 (입구)', 'T-420 (1단)':'98%', 'T-430 (2단)':'88~93%', '비고':'탑 상부 공급' },
          { '항목':'H₂SO₄ 농도 (출구)', 'T-420 (1단)':'88~93%', 'T-430 (2단)':'75~80%', '비고':'탑 하부 배출' },
          { '항목':'가스 입구 수분', 'T-420 (1단)':'~1,000 ppm', 'T-430 (2단)':'< 100 ppm', '비고':'' },
          { '항목':'가스 출구 수분', 'T-420 (1단)':'< 100 ppm', 'T-430 (2단)':'< 5 ppm', '비고':'Asahi Kasei 기준' },
          { '항목':'가스 온도', 'T-420 (1단)':'10~25 °C', 'T-430 (2단)':'20~30 °C', '비고':'' },
          { '항목':'충전 높이', 'T-420 (1단)':'2~3 m', 'T-430 (2단)':'1.5~2 m', '비고':'' },
          { '항목':'탑 직경', 'T-420 (1단)':'2.4~2.8 m', 'T-430 (2단)':'2.0~2.4 m', '비고':'F-factor 0.5 기준' },
          { '항목':'L/G 비 (H₂SO₄/Cl₂)', 'T-420 (1단)':'1.5~3.0 L/m³', 'T-430 (2단)':'1.0~2.0 L/m³', '비고':'' },
          { '항목':'충전물 재질', 'T-420 (1단)':'PP or 세라믹', 'T-430 (2단)':'PP or 세라믹', '비고':'건조 Cl₂ 환경' },
          { '항목':'H₂SO₄ 온도', 'T-420 (1단)':'< 35 °C', 'T-430 (2단)':'< 30 °C', '비고':'냉각 필수' },
        ]} />
      </Section>

      <Section title="C-450 Cl2 압축기" accent="#f97316">
        <CritTable accent="#f97316" headers={['설계 항목','기준값','비고']} rows={[
          { '설계 항목':'형식', '기준값':'왕복동 (Oil-Free)', '비고':'건식 Cl₂ 오일 오염 금지' },
          { '설계 항목':'입구 조건', '기준값':'건조 Cl₂, 25°C, 0.17 kg/cm²G', '비고':'' },
          { '설계 항목':'출구 조건', '기준값':'40°C, 3.0 kg/cm²G', '비고':'' },
          { '설계 항목':'실린더 재질', '기준값':'하스탈로이 C-276', '비고':'' },
          { '설계 항목':'씰/밸브', '기준값':'PTFE', '비고':'' },
          { '설계 항목':'씰 가스', '기준값':'건조 N₂', '비고':'' },
          { '설계 항목':'냉각', '기준값':'단간 냉각 (After-cooler)', '비고':'' },
        ]} />
      </Section>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   TAB 3 — 재질 선정 기준
══════════════════════════════════════════════════════════ */
function TabMaterial() {
  return (
    <div>
      <Section title="유체 환경별 재질 선정" accent="#a78bfa">
        <CritTable accent="#a78bfa" headers={['유체 환경','권장 재질','주의사항']} rows={[
          { '유체 환경':'포화 브라인 (중성, 60~70°C)',   '권장 재질':'FRP, PP, PVDF',                '주의사항':'탄소강 부적합 (Cl⁻ 부식)' },
          { '유체 환경':'포화 브라인 (알칼리, pH 10~11)', '권장 재질':'FRP, PP',                      '주의사항':'PVDF 고온 알칼리 주의' },
          { '유체 환경':'포화 브라인 (산성, pH 2~4)',     '권장 재질':'PVDF, FRP',                    '주의사항':'PP는 산성 Cl⁻에 취약' },
          { '유체 환경':'습윤 Cl₂ 가스',                  '권장 재질':'PVDF, 하스탈로이 C-276, Ti',   '주의사항':'절대 탄소강/PP/PVC 불가' },
          { '유체 환경':'건조 Cl₂ 가스 (< 10 ppm H₂O)',  '권장 재질':'탄소강, FRP, PP 가능',         '주의사항':'수분 침입 방지 필수' },
          { '유체 환경':'액체 Cl₂ (건조)',                 '권장 재질':'탄소강',                        '주의사항':'수분 혼입 시 즉시 부식' },
          { '유체 환경':'묽은 HCl (< 30%)',              '권장 재질':'PVDF, FRP, 하스탈로이',         '주의사항':'' },
          { '유체 환경':'진한 H₂SO₄ (> 70%)',            '권장 재질':'탄소강, FRP',                   '주의사항':'희석 시 발열 주의' },
          { '유체 환경':'H₂SO₄ 75~88% (건조탑)',         '권장 재질':'FRP + PP 라이닝',               '주의사항':'' },
          { '유체 환경':'NaOH (< 50%, 상온)',             '권장 재질':'탄소강, SS316L, PP, FRP',       '주의사항':'' },
          { '유체 환경':'NaOH (32%, 85~90°C)',           '권장 재질':'탄소강 + Ni 라이닝',             '주의사항':'고온 고농도 SCC 위험' },
          { '유체 환경':'50% NaOH (> 100°C)',            '권장 재질':'Ni, Ni합금',                    '주의사항':'316L SS 부적합' },
          { '유체 환경':'H₂ 가스 (고압)',                  '권장 재질':'SS 316L, 탄소강',               '주의사항':'수소취성 주의 (고강도강 금지)' },
        ]} />
      </Section>

      <Section title="개스킷 / 씰 재질 선정" accent="#a78bfa">
        <CritTable accent="#a78bfa" headers={['유체','권장 재질','부적합 재질']} rows={[
          { '유체':'습윤 Cl₂',    '권장 재질':'PTFE, 하스탈로이 C-276 금속', '부적합 재질':'고무, NBR, EPDM' },
          { '유체':'건조 Cl₂',    '권장 재질':'PTFE, PVDF',                  '부적합 재질':'고무' },
          { '유체':'진한 H₂SO₄', '권장 재질':'PTFE, FPM (Viton)',           '부적합 재질':'NBR, CR' },
          { '유체':'HCl',        '권장 재질':'PTFE, FPM',                   '부적합 재질':'금속 일반' },
          { '유체':'NaOH 32%',  '권장 재질':'EPDM, PTFE, NBR',             '부적합 재질':'알루미늄, 아연' },
          { '유체':'H₂ 고압',    '권장 재질':'PTFE, 금속 (316L)',            '부적합 재질':'다공성 재질' },
        ]} />
      </Section>

      <Section title="용접 / 열처리 기준" accent="#a78bfa">
        <Alert type="warning">
          <strong>NaOH 환경 (특히 &gt; 30% 고온):</strong> 응력 부식 균열(SCC) 방지를 위해 용접 후 반드시 PWHT(용접 후 열처리) 실시. 설계 잔류응력 &lt; 20% σ_yield 유지.
        </Alert>
        <Alert type="caution">
          <strong>Cl₂ 계통 탄소강 배관:</strong> 수분 침입 감지 시 즉각 격리. 습윤 Cl₂는 수 시간 내 탄소강을 완전 부식시킴.
        </Alert>
      </Section>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   TAB 4 — 탈염소 및 기타 탑
══════════════════════════════════════════════════════════ */
function TabDechlorination() {
  return (
    <div>
      <Section title="탈염소탑 (Depleted Brine Dechlorination Tower)" accent="#fbbf24">
        <Alert type="info">
          목적: 전해조 출구 애노라이트(묽은 브라인)에 용존된 Cl₂ 제거 후 D-010 복귀.<br />
          공정: 산성화 (HCl, pH 1~2) → N₂ 스트리핑 → 재알칼리화 (NaOH, pH 8~9)
        </Alert>
        <CritTable accent="#fbbf24" headers={['설계 항목','기준값','비고']} rows={[
          { '설계 항목':'입구 용존 Cl₂', '기준값':'400~800 mg/L', '비고':'전해조 출구 기준' },
          { '설계 항목':'출구 용존 Cl₂', '기준값':'< 1 mg/L', '비고':'' },
          { '설계 항목':'스트리핑 가스', '기준값':'N₂ (1차 선택)', '비고':'Cl₂ 회수 목적 시 N₂ 사용' },
          { '설계 항목':'탑내 온도', '기준값':'50~70 °C', '비고':'고온일수록 헨리 상수 유리' },
          { '설계 항목':'스트리핑 인수 S', '기준값':'> 2 (H × G/L)', '비고':'99% 이상 제거 목표' },
          { '설계 항목':'HTU (전달 단위 높이)', '기준값':'0.3~0.6 m', '비고':'' },
          { '설계 항목':'NTU (전달 단위 수)', '기준값':'5~8', '비고':'99%+ 제거 기준' },
          { '설계 항목':'충전 높이 Z = HTU × NTU', '기준값':'2~4 m', '비고':'' },
          { '설계 항목':'충전물 재질', '기준값':'PVDF Pall Ring 25~38 mm', '비고':'알칼리 + Cl₂ 내성' },
          { '설계 항목':'탑 재질', '기준값':'FRP 내면 타일 또는 PVDF 내장', '비고':'' },
        ]} />
      </Section>

      <Section title="압력 손실 설계 기준" accent="#fbbf24">
        <CritTable accent="#fbbf24" headers={['장치','허용 ΔP','비고']} rows={[
          { '장치':'패킹탑 운전', '허용 ΔP':'20~30 mmH₂O / m 충전', '비고':'설계점 65~75% 플러딩' },
          { '장치':'미스트 엘리미네이터', '허용 ΔP':'5~10 mmH₂O', '비고':'' },
          { '장치':'건조탑 전체', '허용 ΔP':'< 50 mmH₂O', '비고':'압축기 앞 압력 보전' },
          { '장치':'이온교환탑 (운전)', '허용 ΔP':'0.5~1.5 kg/cm²', '비고':'역세 개시 기준 상한' },
          { '장치':'카본 필터', '허용 ΔP':'0.2~0.5 kg/cm²', '비고':'역세 개시 기준 0.5' },
        ]} />
      </Section>

      <Section title="충전물 선정 가이드" accent="#fbbf24">
        <CritTable accent="#fbbf24" headers={['용도','권장 재질','권장 규격','이유']} rows={[
          { '용도':'Cl₂ 세정탑 T-410 (습윤)', '권장 재질':'PVDF', '권장 규격':'38~50 mm Pall Ring', '이유':'습윤 Cl₂ + HCl 내성' },
          { '용도':'Cl₂ 건조탑 T-420/430', '권장 재질':'PP 또는 세라믹', '권장 규격':'25~38 mm Pall Ring', '이유':'건조 Cl₂, H₂SO₄ 내성' },
          { '용도':'탈염소탑', '권장 재질':'PVDF', '권장 규격':'25~38 mm', '이유':'알칼리 + 용존 Cl₂' },
          { '용도':'H₂ 세정탑 (600 SEC)', '권장 재질':'PP', '권장 규격':'25~38 mm', '이유':'알칼리성 환경' },
        ]} />
      </Section>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   MAIN EXPORT
══════════════════════════════════════════════════════════ */
const DESIGN_TABS = [
  { id: '100sec',     label: '100 SEC 브라인정제',   icon: '🧂', color: '#4ade80',  Component: Tab100SEC },
  { id: '400sec',     label: '400 SEC Cl₂ 패킹탑',  icon: '🏭', color: '#60a5fa',  Component: Tab400SEC },
  { id: 'material',  label: '재질 선정 기준',         icon: '🔩', color: '#a78bfa',  Component: TabMaterial },
  { id: 'other',     label: '탈염소탑 · 기타',        icon: '📐', color: '#fbbf24',  Component: TabDechlorination },
];

export default function DesignStandards() {
  const [active, setActive] = useState('100sec');
  const ActiveComp = DESIGN_TABS.find(t => t.id === active)?.Component ?? Tab100SEC;

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Tab bar */}
      <div style={{
        display: 'flex', alignItems: 'flex-end',
        padding: '0 16px', gap: 2,
        background: 'var(--bg-surface)',
        borderBottom: '1px solid var(--border-subtle)',
        flexShrink: 0, height: 40,
      }}>
        <span style={{ fontSize: 12, fontWeight: 700, color: '#64748b', paddingBottom: 8, marginRight: 12 }}>
          📏 장치 설계기준
        </span>
        {DESIGN_TABS.map(tab => {
          const isActive = active === tab.id;
          return (
            <button key={tab.id} onClick={() => setActive(tab.id)} style={{
              height: 32, padding: '0 14px', borderRadius: '6px 6px 0 0',
              border: `1px solid ${isActive ? `${tab.color}44` : 'transparent'}`,
              borderBottom: isActive ? '1px solid var(--bg-base)' : '1px solid transparent',
              background: isActive ? 'var(--bg-base)' : 'transparent',
              color: isActive ? tab.color : '#64748b',
              fontSize: 11, fontWeight: 600, cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: 6,
              transition: 'all 0.15s',
            }}>
              <span>{tab.icon}</span>
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflow: 'auto', padding: '20px 24px' }}>
        <ActiveComp />
      </div>
    </div>
  );
}
