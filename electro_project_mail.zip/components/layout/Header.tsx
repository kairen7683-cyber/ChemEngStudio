'use client';

export default function Header() {
  return (
    <header className="header">
      <div className="header-logo">
        <div className="header-logo-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <circle cx="9" cy="12" r="3.5"/>
            <circle cx="15" cy="12" r="3.5"/>
            <path d="M3 5h18M3 19h18" strokeOpacity="0.5"/>
          </svg>
        </div>
        <div>
          <div className="header-title">ClorSim Pro</div>
          <div className="header-subtitle">전해공장 공정 시뮬레이터</div>
        </div>
      </div>

      <div className="header-spacer" />

      <div className="header-badge">
        <span className="header-badge-dot" />
        Asahi Kasei 이온교환막
      </div>

      <div className="header-badge" style={{ borderColor: 'rgba(255,107,53,0.2)', color: 'var(--accent-secondary)', background: 'rgba(255,107,53,0.08)' }}>
        MB-2012 CA NO.3 · 468 TON/일 Base
      </div>

      <button
        style={{
          background: 'rgba(0,212,255,0.1)',
          border: '1px solid rgba(0,212,255,0.25)',
          color: 'var(--accent-primary)',
          padding: '5px 14px',
          borderRadius: '6px',
          fontSize: '12px',
          fontWeight: 600,
          cursor: 'pointer',
          transition: 'all 0.15s ease',
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
        }}
        onMouseEnter={e => {
          (e.currentTarget as HTMLButtonElement).style.background = 'rgba(0,212,255,0.18)';
        }}
        onMouseLeave={e => {
          (e.currentTarget as HTMLButtonElement).style.background = 'rgba(0,212,255,0.1)';
        }}
      >
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
          <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/>
        </svg>
        엑셀 내보내기
      </button>
    </header>
  );
}
