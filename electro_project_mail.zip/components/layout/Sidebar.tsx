'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useBalanceStore } from '@/lib/stores/balanceStore';

export default function Sidebar() {
  const pathname = usePathname();
  const { inputs, setInput, balance } = useBalanceStore();
  const { summary, electrolyzerResult: elec } = balance;
  const [collapsed, setCollapsed] = useState(false);

  return (
    <nav
      className="sidebar"
      style={{
        width: collapsed ? 44 : 260,
        transition: 'width 0.22s ease',
        flexShrink: 0,
        overflowY: 'auto',
        overflowX: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        background: 'var(--bg-surface)',
        borderRight: '1px solid var(--border-subtle)',
        position: 'relative',
      }}
    >
      {/* ─── 접기/펼치기 버튼 ─── */}
      <button
        onClick={() => setCollapsed(c => !c)}
        title={collapsed ? '패널 펼치기' : '패널 접기'}
        style={{
          position: 'absolute', top: 8, right: 6, zIndex: 10,
          width: 26, height: 26, borderRadius: 6,
          background: 'var(--bg-elevated)',
          border: '1px solid var(--border-default)',
          cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--text-muted)',
          transition: 'all 0.15s',
          flexShrink: 0,
        }}
        onMouseEnter={e => (e.currentTarget.style.color = 'var(--accent-primary)')}
        onMouseLeave={e => (e.currentTarget.style.color = 'var(--text-muted)')}
      >
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2">
          {collapsed
            ? <path d="M3 6h6M7 3l3 3-3 3" strokeLinecap="round" strokeLinejoin="round"/>
            : <path d="M9 6H3M5 3L2 6l3 3" strokeLinecap="round" strokeLinejoin="round"/>}
        </svg>
      </button>

      {!collapsed && (
        <>
          {/* ══════════════════════════════════════════════
              1. 운전 파라미터 (슬라이더)
          ══════════════════════════════════════════════ */}
          <div style={{ padding: '12px 14px 0' }}>
            <div style={{
              fontSize: 9, fontWeight: 700, color: 'var(--text-muted)',
              textTransform: 'uppercase', letterSpacing: '0.8px', marginBottom: 10,
            }}>⚙ 운전 파라미터</div>

            {/* 전해조 수량 */}
            <ControlRow
              label="전해조 수량" unit="기"
              value={inputs.numElectrolyzers}
              display={String(inputs.numElectrolyzers)}
              min={1} max={20} step={1}
              onChange={v => setInput('numElectrolyzers', v)}
            />

            {/* 셀 수량 */}
            <ControlRow
              label="셀 수량" unit="셀/전해조"
              value={inputs.cellsPerElectrolyzer}
              display={String(inputs.cellsPerElectrolyzer)}
              min={50} max={500} step={1}
              onChange={v => setInput('cellsPerElectrolyzer', v)}
            />

            {/* 운전 전류 */}
            <ControlRow
              label="운전 전류" unit="kA"
              value={inputs.operatingCurrentKA}
              display={inputs.operatingCurrentKA.toFixed(1)}
              min={1} max={30} step={0.1}
              onChange={v => setInput('operatingCurrentKA', v)}
            />

            {/* 전류 효율 */}
            <ControlRow
              label="전류 효율 (CE)" unit="%"
              value={inputs.currentEfficiency * 100}
              display={(inputs.currentEfficiency * 100).toFixed(1)}
              min={80} max={99} step={0.1}
              onChange={v => setInput('currentEfficiency', v / 100)}
            />

            {/* 총 셀수 */}
            <div style={{
              marginTop: 8, padding: '8px 10px', borderRadius: 8,
              background: 'rgba(255,212,59,0.07)',
              border: '1px solid rgba(255,212,59,0.2)',
            }}>
              <div style={{ fontSize: 9, color: 'var(--text-muted)', marginBottom: 3 }}>총 셀수</div>
              <div style={{
                fontSize: 20, fontWeight: 700, color: 'var(--accent-warn)',
                fontFamily: 'JetBrains Mono, monospace', lineHeight: 1,
              }}>
                {(inputs.numElectrolyzers * inputs.cellsPerElectrolyzer).toLocaleString()}
                <span style={{ fontSize: 11, color: 'var(--text-muted)', marginLeft: 4 }}>PCS</span>
              </div>
            </div>
          </div>

          <div style={{ height: 1, background: 'var(--border-subtle)', margin: '10px 0' }} />

          {/* ══════════════════════════════════════════════
              2. 생산량 요약
          ══════════════════════════════════════════════ */}
          <div style={{ padding: '0 14px' }}>
            <div style={{
              fontSize: 9, fontWeight: 700, color: 'var(--text-muted)',
              textTransform: 'uppercase', letterSpacing: '0.8px', marginBottom: 8,
            }}>📊 생산량 요약</div>

            <SummaryCard
              label="Cl₂ 생산량" accent="#00d4ff"
              main={`${summary.cl2_tonDay.toFixed(1)} ton/일`}
              sub={`${elec.cl2ProductionKgH.toFixed(0)} kg/h`}
            />
            <SummaryCard
              label="NaOH 32% (용액)" accent="#f97316"
              main={`${summary.naoh32_tonDay.toFixed(1)} ton/일`}
              sub={`${(summary.naoh32_tonDay / 24 * 1000).toFixed(0)} kg/h (용액)`}
            />
            <SummaryCard
              label="NaOH 50% (용액)" accent="#fb923c"
              main={`${summary.naoh50_tonDay.toFixed(1)} ton/일`}
              sub={`드라이 ${elec.naohProductionKgH.toFixed(0)} kg/h`}
            />
            <SummaryCard
              label="H₂ 생산량" accent="#a78bfa"
              main={`${summary.h2_tonDay.toFixed(2)} ton/일`}
              sub={`${elec.h2ProductionKgH.toFixed(1)} kg/h`}
            />
            <SummaryCard
              label="NaCl 소모" accent="#fbbf24"
              main={`${summary.naclUsage_tonDay.toFixed(1)} ton/일`}
              sub={`소금 ${summary.saltUsage_tonDay.toFixed(1)} ton/일`}
            />
          </div>

          <div style={{ height: 1, background: 'var(--border-subtle)', margin: '10px 0' }} />

          {/* ══════════════════════════════════════════════
              3. 내비게이션 (작동하는 메뉴만)
          ══════════════════════════════════════════════ */}
          <div style={{ padding: '0 14px' }}>
            <div style={{
              fontSize: 9, fontWeight: 700, color: 'var(--text-muted)',
              textTransform: 'uppercase', letterSpacing: '0.8px', marginBottom: 6,
            }}>모듈</div>

            <NavItem
              href="/material-balance" label="머티리얼 발란스" active={pathname === '/material-balance'}
              icon={<PFDIcon />}
            />
            <NavItem href="#" label="전해조 관리" disabled icon={<ElecIcon />} badge="Soon" />
            <NavItem href="/equipment-design" label="장치 설계" active={pathname === '/equipment-design' || pathname.startsWith('/equipment-design')} icon={<DesignIcon />} />
            <NavItem href="#" label="운전 기록" disabled icon={<LogIcon />} badge="Soon" />
          </div>
        </>
      )}

      {/* 접혔을 때: 세로 아이콘 메뉴 */}
      {collapsed && (
        <div style={{ paddingTop: 48, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
          {[
            { icon: <PFDIcon />, tip: '머티리얼 발란스', href: '/material-balance' },
            { icon: <ElecIcon />, tip: '전해조 관리', href: '#' },
            { icon: <DesignIcon />, tip: '장치 설계', href: '#' },
          ].map((item, i) => (
            <Link key={i} href={item.href} title={item.tip} style={{
              width: 32, height: 32, borderRadius: 8,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--text-muted)', textDecoration: 'none',
              background: 'transparent', border: '1px solid transparent',
            }}>
              {item.icon}
            </Link>
          ))}
        </div>
      )}
    </nav>
  );
}

// ── 슬라이더 컨트롤 ────────────────────────────────────────
function ControlRow({ label, unit, value, display, min, max, step, onChange }: {
  label: string; unit: string; value: number; display: string;
  min: number; max: number; step: number; onChange: (v: number) => void;
}) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
        marginBottom: 4,
      }}>
        <span style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 600 }}>{label}</span>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 3 }}>
          <span style={{
            fontSize: 16, fontWeight: 700, color: 'var(--accent-primary)',
            fontFamily: 'JetBrains Mono, monospace', lineHeight: 1,
          }}>{display}</span>
          <span style={{ fontSize: 9, color: 'var(--text-muted)' }}>{unit}</span>
        </div>
      </div>
      <input
        type="range"
        min={min} max={max} step={step} value={value}
        onChange={e => onChange(Number(e.target.value))}
        style={{
          width: '100%', height: 4, borderRadius: 2,
          accentColor: 'var(--accent-primary)',
          cursor: 'pointer',
        }}
      />
    </div>
  );
}

// ── 생산량 카드 ────────────────────────────────────────────
function SummaryCard({ label, accent, main, sub }: {
  label: string; accent: string; main: string; sub: string;
}) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '6px 8px', borderRadius: 6, marginBottom: 4,
      background: `${accent}08`,
      borderLeft: `2px solid ${accent}`,
    }}>
      <div>
        <div style={{ fontSize: 9, color: 'var(--text-muted)', fontWeight: 600 }}>{label}</div>
        <div style={{ fontSize: 9, color: `${accent}bb`, marginTop: 1 }}>{sub}</div>
      </div>
      <div style={{
        fontSize: 13, fontWeight: 700, color: accent,
        fontFamily: 'JetBrains Mono, monospace',
        textAlign: 'right',
      }}>{main}</div>
    </div>
  );
}

// ── 내비게이션 아이템 ──────────────────────────────────────
function NavItem({ href, label, icon, active, disabled, badge }: {
  href: string; label: string; icon: React.ReactNode;
  active?: boolean; disabled?: boolean; badge?: string;
}) {
  return (
    <Link
      href={disabled ? '#' : href}
      style={{
        display: 'flex', alignItems: 'center', gap: 8,
        padding: '7px 8px', borderRadius: 6, marginBottom: 2,
        color: active ? 'var(--accent-primary)' : disabled ? 'var(--text-muted)' : 'var(--text-secondary)',
        background: active ? 'rgba(0,212,255,0.08)' : 'transparent',
        border: active ? '1px solid rgba(0,212,255,0.15)' : '1px solid transparent',
        textDecoration: 'none', fontSize: 12, fontWeight: 500,
        opacity: disabled ? 0.4 : 1,
        pointerEvents: disabled ? 'none' : 'auto',
        transition: 'all 0.15s',
      }}
    >
      <span style={{ width: 16, height: 16, flexShrink: 0, opacity: 0.8 }}>{icon}</span>
      <span style={{ flex: 1 }}>{label}</span>
      {badge && (
        <span style={{
          fontSize: 9, padding: '1px 5px', borderRadius: 8,
          background: 'rgba(255,107,53,0.15)', color: 'var(--accent-secondary)', fontWeight: 700,
        }}>{badge}</span>
      )}
    </Link>
  );
}

// ── 아이콘들 ───────────────────────────────────────────────
function PFDIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="2" y="3" width="20" height="14" rx="2"/>
      <path d="M8 21h8M12 17v4"/>
      <path d="M6 10h2M11 10h2M16 10h2"/>
    </svg>
  );
}
function ElecIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="6" width="18" height="12" rx="2"/>
      <path d="M8 6V4M16 6V4M8 18v2M16 18v2"/>
      <path d="M10 12h4M12 10v4"/>
    </svg>
  );
}
function DesignIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"/>
    </svg>
  );
}
function LogIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
      <polyline points="14,2 14,8 20,8"/>
      <line x1="16" y1="13" x2="8" y2="13"/>
      <line x1="16" y1="17" x2="8" y2="17"/>
    </svg>
  );
}
