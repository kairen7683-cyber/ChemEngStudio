'use client';

import { Handle, Position, NodeProps } from 'reactflow';
import { useBalanceStore } from '@/lib/stores/balanceStore';
import { StreamData } from '@/lib/calculations/streams';
import { useState } from 'react';
import { editModeRef } from './SectionGroupNode';

// ── 공통 핸들 스타일 ────────────────────────────────────────
const hs = (color: string) => ({
  background: color, width: 8, height: 8,
  border: '2px solid var(--bg-elevated)',
});

// ── PPT-style connection handles ─────────────────────────────
// Handles live INSIDE .pfd-node-body (position:relative) so that
// percentage-based left/top are anchored to the body element, not
// the outer flex wrapper. This fixes the snap-to-handle issue.
//
// Layout: 2 per side = 8 total
//   SOURCE (pipe starts here) → Right (a=25%, b=75%), Bottom (a=30%, b=70%)
//   TARGET (pipe ends here)   → Left  (a=25%, b=75%), Top   (a=30%, b=70%)

interface BodyWithHandlesProps {
  bodyStyle?: React.CSSProperties;
  bodyClass?: string;
  color?: string;
  visible: boolean;
  children: React.ReactNode;
}

function BodyWithHandles({ bodyStyle, bodyClass = 'pfd-node-body', color = '#60a5fa', visible, children }: BodyWithHandlesProps) {
  // Gate handle visibility AND interactivity on editMode.
  // Hover state (visible) still drives the animation, but handles are
  // invisible and non-interactive when not in edit mode.
  const inEditMode = editModeRef.current;
  const show = visible && inEditMode;

  const handleBase: React.CSSProperties = {
    width: 12, height: 12,
    borderRadius: '50%',
    border: `2.5px solid #0a0e1a`,
    boxShadow: show ? `0 0 8px ${color}cc, 0 0 2px #fff4` : 'none',
    opacity: show ? 1 : 0,
    transition: 'opacity 0.12s, box-shadow 0.12s',
    cursor: show ? 'crosshair' : 'default',
    pointerEvents: show ? 'all' : 'none',   // non-interactive in view mode
    zIndex: 50,
    background: color,
  };

  // All handles are type="source" so any handle can start OR end a connection.
  // ConnectionMode.Loose (set on ReactFlow) allows source→source connections,
  // making every handle fully bidirectional without src/tgt distinction.
  return (
    <div className={bodyClass} style={{ ...bodyStyle, position: 'relative', overflow: 'visible' }}>
      {children}

      <Handle type="source" position={Position.Right}  id="src-r1" style={{ ...handleBase, top: '25%',  right: '-6px' }} />
      <Handle type="source" position={Position.Right}  id="src-r2" style={{ ...handleBase, top: '75%',  right: '-6px' }} />
      <Handle type="source" position={Position.Bottom} id="src-b1" style={{ ...handleBase, left: '30%', bottom: '-6px' }} />
      <Handle type="source" position={Position.Bottom} id="src-b2" style={{ ...handleBase, left: '70%', bottom: '-6px' }} />
      <Handle type="source" position={Position.Left}   id="tgt-l1" style={{ ...handleBase, top: '25%',  left: '-6px' }} />
      <Handle type="source" position={Position.Left}   id="tgt-l2" style={{ ...handleBase, top: '75%',  left: '-6px' }} />
      <Handle type="source" position={Position.Top}    id="tgt-t1" style={{ ...handleBase, left: '30%', top: '-6px' }} />
      <Handle type="source" position={Position.Top}    id="tgt-t2" style={{ ...handleBase, left: '70%', top: '-6px' }} />
    </div>
  );
}


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 스트림 라벨 + 호버 툴팁 (핵심 컴포넌트)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export function StreamLabelNode({ data }: NodeProps) {
  const [hovered, setHovered] = useState(false);
  const { balance } = useBalanceStore();
  const stream = balance.streams.find(s => s.id === data.streamId);

  const phaseColor = data.phase === 'G'   ? '#a78bfa'
    : data.phase === 'L/G' ? '#fbbf24'
    : '#4ade80';

  return (
    <div style={{ position: 'relative' }}>
      {/* All handles are type=source for bidirectional connection (ConnectionMode.Loose) */}
      <Handle type="source" position={Position.Right}  id="src-r1" style={{ opacity: 0, width: 4, height: 4, top: '25%'  }} />
      <Handle type="source" position={Position.Right}  id="src-r2" style={{ opacity: 0, width: 4, height: 4, top: '75%'  }} />
      <Handle type="source" position={Position.Bottom} id="src-b1" style={{ opacity: 0, width: 4, height: 4, left: '30%' }} />
      <Handle type="source" position={Position.Bottom} id="src-b2" style={{ opacity: 0, width: 4, height: 4, left: '70%' }} />
      <Handle type="source" position={Position.Left}   id="tgt-l1" style={{ opacity: 0, width: 4, height: 4, top: '25%'  }} />
      <Handle type="source" position={Position.Left}   id="tgt-l2" style={{ opacity: 0, width: 4, height: 4, top: '75%'  }} />
      <Handle type="source" position={Position.Top}    id="tgt-t1" style={{ opacity: 0, width: 4, height: 4, left: '30%' }} />
      <Handle type="source" position={Position.Top}    id="tgt-t2" style={{ opacity: 0, width: 4, height: 4, left: '70%' }} />

      {/* 스트림 번호 배지 */}
      <div
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        style={{
          background: hovered ? 'var(--bg-hover)' : 'var(--bg-card)',
          border: `1px solid ${hovered ? phaseColor : `${phaseColor}55`}`,
          borderRadius: 4,
          padding: '3px 8px',
          cursor: 'crosshair',
          minWidth: 40,
          textAlign: 'center',
          transition: 'all 0.15s ease',
          boxShadow: hovered ? `0 0 12px ${phaseColor}40` : 'none',
        }}
      >
        <div style={{
          fontSize: 11, fontWeight: 700,
          fontFamily: 'JetBrains Mono, monospace',
          color: hovered ? phaseColor : 'var(--text-primary)',
          letterSpacing: '0.3px',
        }}>
          [{data.streamId}]
        </div>
        {data.flowKgh !== undefined && (
          <div style={{
            fontSize: 9, color: 'var(--accent-primary)',
            fontFamily: 'JetBrains Mono, monospace',
          }}>
            {Number(data.flowKgh).toLocaleString('ko-KR', { maximumFractionDigits: 0 })} kg/h
          </div>
        )}
        {/* 상 표시 */}
        <div style={{
          fontSize: 8, color: phaseColor, opacity: 0.8,
          fontFamily: 'JetBrains Mono',
        }}>
          {data.phase || 'L'}
        </div>
      </div>

      {/* 호버 툴팁 */}
      {hovered && stream && (
        <StreamTooltip stream={stream} phaseColor={phaseColor} />
      )}
    </div>
  );
}

// ── 리치 툴팁 컴포넌트 ──────────────────────────────────────
function StreamTooltip({ stream, phaseColor }: { stream: StreamData; phaseColor: string }) {
  const comps = Object.entries(stream.components)
    .filter(([, v]) => v && v > 0)
    .sort(([, a], [, b]) => (b || 0) - (a || 0));

  const total = stream.total_kgh;

  const compLabels: Record<string, string> = {
    NaCl: 'NaCl', H2O: 'H₂O', NaOH: 'NaOH', Cl2: 'Cl₂',
    H2: 'H₂', HCl: 'HCl', O2: 'O₂', H2SO4: 'H₂SO₄',
    BaCl2: 'BaCl₂', Na2SO3: 'Na₂SO₃',
  };

  const compColors: Record<string, string> = {
    NaCl: '#4ade80', H2O: '#94a3b8', NaOH: '#f97316', Cl2: '#60a5fa',
    H2: '#a78bfa', HCl: '#fde68a', O2: '#fb923c', H2SO4: '#fbbf24',
    BaCl2: '#86efac', Na2SO3: '#c4b5fd',
  };

  const fmtN = (v: number | undefined, dec = 0) => {
    if (!v) return '—';
    return v.toLocaleString('ko-KR', { maximumFractionDigits: dec, minimumFractionDigits: 0 });
  };

  return (
    <div style={{
      position: 'absolute',
      left: '110%',
      top: '50%',
      transform: 'translateY(-50%)',
      zIndex: 9999,
      width: 280,
      background: 'rgba(10,16,30,0.97)',
      border: `1px solid ${phaseColor}55`,
      borderRadius: 8,
      boxShadow: `0 8px 32px rgba(0,0,0,0.8), 0 0 0 1px ${phaseColor}22`,
      backdropFilter: 'blur(12px)',
      overflow: 'hidden',
      pointerEvents: 'none',
    }}>
      {/* 헤더 */}
      <div style={{
        background: `linear-gradient(90deg, ${phaseColor}20, transparent)`,
        borderBottom: `1px solid ${phaseColor}30`,
        padding: '8px 12px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div>
          <span style={{
            fontSize: 13, fontWeight: 700, color: phaseColor,
            fontFamily: 'JetBrains Mono', letterSpacing: '0.5px',
          }}>
            [{stream.id}]
          </span>
          <span style={{
            fontSize: 10, color: 'var(--text-muted)', marginLeft: 8,
          }}>
            {stream.section} Sec
          </span>
        </div>
        <span style={{
          fontSize: 9, padding: '2px 6px',
          background: `${phaseColor}25`,
          border: `1px solid ${phaseColor}44`,
          borderRadius: 10, color: phaseColor, fontWeight: 700,
          fontFamily: 'JetBrains Mono',
        }}>
          {stream.phase || 'L'}
        </span>
      </div>

      {/* 스트림 이름 */}
      <div style={{ padding: '6px 12px', borderBottom: '1px solid var(--border-subtle)' }}>
        <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{stream.name}</div>
        {stream.description && (
          <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 2 }}>
            {stream.description}
          </div>
        )}
      </div>

      {/* 유량 조성 */}
      <div style={{ padding: '8px 12px' }}>
        <div style={{ fontSize: 9, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 6 }}>
          유량 조성
        </div>
        {comps.map(([key, val]) => {
          const pct = total > 0 ? ((val || 0) / total * 100) : 0;
          return (
            <div key={key} style={{ marginBottom: 5 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
                <span style={{
                  fontSize: 11, fontWeight: 600,
                  color: compColors[key] || 'var(--text-primary)',
                  fontFamily: 'JetBrains Mono',
                }}>
                  {compLabels[key] || key}
                </span>
                <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                  <span style={{ fontSize: 11, color: 'var(--text-secondary)', fontFamily: 'JetBrains Mono' }}>
                    {fmtN(val, 1)} kg/h
                  </span>
                  <span style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'JetBrains Mono', width: 38, textAlign: 'right' }}>
                    {pct.toFixed(1)}%
                  </span>
                </div>
              </div>
              {/* 조성 바 */}
              <div style={{ height: 3, background: 'var(--bg-elevated)', borderRadius: 2, overflow: 'hidden' }}>
                <div style={{
                  height: '100%', width: `${Math.min(100, pct)}%`,
                  background: compColors[key] || phaseColor,
                  borderRadius: 2,
                  transition: 'width 0.3s ease',
                }} />
              </div>
            </div>
          );
        })}
        {/* 합계 */}
        <div style={{
          display: 'flex', justifyContent: 'space-between',
          paddingTop: 6, marginTop: 2,
          borderTop: '1px solid var(--border-subtle)',
        }}>
          <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-primary)' }}>합  계</span>
          <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--accent-primary)', fontFamily: 'JetBrains Mono' }}>
            {fmtN(total, 0)} kg/h
          </span>
        </div>
      </div>

      {/* 운전 조건 */}
      <div style={{
        padding: '6px 12px 8px',
        background: 'rgba(255,255,255,0.02)',
        borderTop: '1px solid var(--border-subtle)',
      }}>
        <div style={{ fontSize: 9, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 5 }}>
          운전 조건
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '3px 16px' }}>
          {[
            { label: '온도', value: stream.temperature_C, unit: '°C' },
            { label: '압력', value: stream.pressure_kgcm2g, unit: 'kg/cm².G' },
            { label: '밀도', value: stream.density_kgm3, unit: 'kg/m³', dec: 2 },
            { label: '농도', value: stream.concentration, unit: 'wt%', dec: 1 },
          ].filter(r => r.value !== undefined && r.value !== null).map(row => (
            <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', gap: 4 }}>
              <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>{row.label}</span>
              <span style={{ fontSize: 10, color: 'var(--text-secondary)', fontFamily: 'JetBrains Mono' }}>
                {fmtN(row.value, row.dec ?? 0)} {row.unit}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 전해조 (Electrolyzer)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export function ElectrolyzerNode({ data }: NodeProps) {
  const [hov, setHov] = useState(false);
  return (
    <div className="pfd-node" onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}>
      <BodyWithHandles
        color="rgba(0,212,255,0.9)" visible={hov}
        bodyStyle={{ width: 100, height: 70, borderColor: `rgba(0,212,255,${hov ? '0.7' : '0.45'})`, boxShadow: hov ? '0 0 24px rgba(0,212,255,0.25)' : '0 0 18px rgba(0,212,255,0.15)', transition: 'all 0.15s' }}
      >
        <svg width="86" height="54" viewBox="0 0 86 54">
          <rect x="2" y="2" width="82" height="50" rx="3" fill="rgba(0,212,255,0.04)" stroke="rgba(0,212,255,0.5)" strokeWidth="1.5"/>
          <line x1="43" y1="2" x2="43" y2="52" stroke="#60a5fa" strokeWidth="1.8" strokeDasharray="4 3"/>
          <text x="16" y="30" fontSize="8" fill="#4ade80" fontFamily="JetBrains Mono" textAnchor="middle">AN</text>
          <text x="68" y="30" fontSize="8" fill="#f97316" fontFamily="JetBrains Mono" textAnchor="middle">CA</text>
          <path d="M18 24 L18 10 M14 14 L18 10 L22 14" stroke="#60a5fa" strokeWidth="1.2" fill="none"/>
          <path d="M68 24 L68 10 M64 14 L68 10 L72 14" stroke="#a78bfa" strokeWidth="1.2" fill="none"/>
          <text x="16" y="44" fontSize="7" fill="#4ade80" textAnchor="middle">＋</text>
          <text x="68" y="44" fontSize="7" fill="#f97316" textAnchor="middle">－</text>
        </svg>
      </BodyWithHandles>
      <div className="pfd-node-tag" style={{ whiteSpace: 'pre-line', textAlign: 'center' }}>{data.tag}</div>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 탱크 / 용기
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export function TankNode({ data }: NodeProps) {
  const [hov, setHov] = useState(false);
  const color = data.color || 'rgba(100,180,255,0.6)';
  return (
    <div className="pfd-node" onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}>
      <BodyWithHandles color={color} visible={hov} bodyStyle={{ width: 54, height: 66, borderColor: `${color}${hov ? '99' : '55'}`, padding: 4, transition: 'border-color 0.15s' }}>
        <svg width="40" height="56" viewBox="0 0 40 56">
          <ellipse cx="20" cy="8"  rx="16" ry="6" fill="none" stroke={color} strokeWidth="1.5"/>
          <ellipse cx="20" cy="48" rx="16" ry="6" fill="none" stroke={color} strokeWidth="1.5"/>
          <line x1="4"  y1="8"  x2="4"  y2="48" stroke={color} strokeWidth="1.5"/>
          <line x1="36" y1="8"  x2="36" y2="48" stroke={color} strokeWidth="1.5"/>
          <line x1="4"  y1="36" x2="36" y2="36" stroke={color} strokeWidth="0.8" strokeDasharray="3 2" opacity="0.5"/>
        </svg>
      </BodyWithHandles>
      <div className="pfd-node-tag" style={{ whiteSpace: 'pre-line', textAlign: 'center' }}>{data.tag}</div>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 펌프
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export function PumpNode({ data }: NodeProps) {
  const [hov, setHov] = useState(false);
  const color = data.color || 'rgba(150,200,255,0.7)';
  return (
    <div className="pfd-node" onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}>
      <BodyWithHandles color={color} visible={hov} bodyStyle={{ width: 36, height: 36, borderRadius: '50%', padding: 4, borderColor: `${color}${hov ? '99' : '66'}`, transition: 'border-color 0.15s' }}>
        <svg width="28" height="28" viewBox="0 0 28 28">
          <circle cx="14" cy="14" r="11" fill="none" stroke={color} strokeWidth="1.5"/>
          <path d="M14 4 L14 14 L22 9" stroke={color} strokeWidth="1.5" fill="none" strokeLinecap="round"/>
          <path d="M14 14 L6 19" stroke={color} strokeWidth="1.5" fill="none" strokeLinecap="round"/>
        </svg>
      </BodyWithHandles>
      <div className="pfd-node-tag" style={{ fontSize: '8px', whiteSpace: 'pre-line', textAlign: 'center' }}>{data.tag}</div>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 기액 분리기
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export function SeparatorNode({ data }: NodeProps) {
  const [hov, setHov] = useState(false);
  const color = data.color || 'rgba(100,180,255,0.6)';
  return (
    <div className="pfd-node" onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}>
      <BodyWithHandles color={color} visible={hov} bodyStyle={{ width: 44, height: 76, borderColor: `${color}${hov ? '88' : '55'}`, padding: 4, transition: 'border-color 0.15s' }}>
        <svg width="32" height="66" viewBox="0 0 32 66">
          <ellipse cx="16" cy="9"  rx="13" ry="7" fill="none" stroke={color} strokeWidth="1.5"/>
          <ellipse cx="16" cy="57" rx="13" ry="7" fill="none" stroke={color} strokeWidth="1.5"/>
          <line x1="3"  y1="9"  x2="3"  y2="57" stroke={color} strokeWidth="1.5"/>
          <line x1="29" y1="9"  x2="29" y2="57" stroke={color} strokeWidth="1.5"/>
          <line x1="3"  y1="36" x2="29" y2="36" stroke={color} strokeWidth="1" strokeDasharray="2 2" opacity="0.6"/>
          <text x="16" y="27" fontSize="7" fill="rgba(167,139,250,0.9)" textAnchor="middle">G</text>
          <text x="16" y="50" fontSize="7" fill={color} textAnchor="middle">L</text>
        </svg>
      </BodyWithHandles>
      <div className="pfd-node-tag" style={{ whiteSpace: 'pre-line', textAlign: 'center' }}>{data.tag}</div>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 열교환기
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export function HeatExchangerNode({ data }: NodeProps) {
  const [hov, setHov] = useState(false);
  return (
    <div className="pfd-node" onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}>
      <BodyWithHandles color="rgba(255,160,100,0.9)" visible={hov} bodyStyle={{ width: 60, height: 48, borderColor: `rgba(255,160,100,${hov ? '0.6' : '0.4'})`, padding: 5, transition: 'border-color 0.15s' }}>
        <svg width="48" height="36" viewBox="0 0 48 36">
          <rect x="2" y="2" width="44" height="32" rx="3" fill="none" stroke="rgba(255,160,100,0.5)" strokeWidth="1.5"/>
          <polyline points="8,12 14,24 20,12 26,24 32,12 38,24" fill="none" stroke="rgba(255,160,100,0.8)" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
      </BodyWithHandles>
      <div className="pfd-node-tag" style={{ fontSize: '8px', whiteSpace: 'pre-line', textAlign: 'center' }}>{data.tag}</div>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 탑 / 흡수탑 / 건조탑
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export function TowerNode({ data }: NodeProps) {
  const [hov, setHov] = useState(false);
  const color = data.color || 'rgba(96,165,250,0.6)';
  return (
    <div className="pfd-node" onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}>
      <BodyWithHandles color={color} visible={hov} bodyStyle={{ width: 38, height: 90, borderColor: `${color}${hov ? '88' : '55'}`, padding: 4, transition: 'border-color 0.15s' }}>
        <svg width="26" height="78" viewBox="0 0 26 78">
          <ellipse cx="13" cy="8"  rx="11" ry="6" fill="none" stroke={color} strokeWidth="1.5"/>
          <ellipse cx="13" cy="70" rx="11" ry="6" fill="none" stroke={color} strokeWidth="1.5"/>
          <line x1="2"  y1="8"  x2="2"  y2="70" stroke={color} strokeWidth="1.5"/>
          <line x1="24" y1="8"  x2="24" y2="70" stroke={color} strokeWidth="1.5"/>
          {[22, 34, 46, 58].map(y => (
            <line key={y} x1="4" y1={y} x2="22" y2={y} stroke={color} strokeWidth="0.8" strokeDasharray="2 2" opacity="0.5"/>
          ))}
        </svg>
      </BodyWithHandles>
      <div className="pfd-node-tag" style={{ fontSize: '8px', whiteSpace: 'pre-line', textAlign: 'center' }}>{data.tag}</div>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 압축기
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export function CompressorNode({ data }: NodeProps) {
  const [hov, setHov] = useState(false);
  const color = data.color || 'rgba(96,165,250,0.7)';
  return (
    <div className="pfd-node" onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}>
      <BodyWithHandles color={color} visible={hov} bodyStyle={{ width: 46, height: 46, borderRadius: '50%', padding: 6, borderColor: `${color}${hov ? '99' : '66'}`, transition: 'border-color 0.15s' }}>
        <svg width="34" height="34" viewBox="0 0 34 34">
          <circle cx="17" cy="17" r="14" fill="none" stroke={color} strokeWidth="1.5"/>
          <path d="M17 4 L17 17 M13 8 L17 4 L21 8" stroke={color} strokeWidth="1.5" fill="none" strokeLinecap="round"/>
          <path d="M17 17 L27 23 M24 19 L27 23 L23 25" stroke={color} strokeWidth="1.5" fill="none" strokeLinecap="round"/>
          <circle cx="17" cy="17" r="2" fill={color}/>
        </svg>
      </BodyWithHandles>
      <div className="pfd-node-tag" style={{ fontSize: '8px', whiteSpace: 'pre-line', textAlign: 'center' }}>{data.tag}</div>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 여과기 / 이온교환탑
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export function FilterNode({ data }: NodeProps) {
  const [hov, setHov] = useState(false);
  const color = data.color || 'rgba(74,222,128,0.7)';
  return (
    <div className="pfd-node" onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}>
      <BodyWithHandles color={color} visible={hov} bodyStyle={{ width: 52, height: 60, borderColor: `${color}${hov ? '88' : '55'}`, padding: 4, transition: 'border-color 0.15s' }}>
        <svg width="40" height="48" viewBox="0 0 40 48">
          <ellipse cx="20" cy="7"  rx="16" ry="5" fill="none" stroke={color} strokeWidth="1.5"/>
          <ellipse cx="20" cy="41" rx="16" ry="5" fill="none" stroke={color} strokeWidth="1.5"/>
          <line x1="4"  y1="7"  x2="4"  y2="41" stroke={color} strokeWidth="1.5"/>
          <line x1="36" y1="7"  x2="36" y2="41" stroke={color} strokeWidth="1.5"/>
          {[14, 20, 26].map(y => (
            <line key={y} x1="6" y1={y} x2="34" y2={y} stroke={color} strokeWidth="0.8" opacity="0.6"/>
          ))}
          {[11, 17, 23, 29].map(x => (
            <line key={x} x1={x} y1="12" x2={x} y2="30" stroke={color} strokeWidth="0.8" opacity="0.6"/>
          ))}
        </svg>
      </BodyWithHandles>
      <div className="pfd-node-tag" style={{ fontSize: '8px', whiteSpace: 'pre-line', textAlign: 'center' }}>{data.tag}</div>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 컨트롤 밸브
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export function ValveNode({ data }: NodeProps) {
  const [hov, setHov] = useState(false);
  const color = data.color || 'rgba(150,180,220,0.8)';
  return (
    <div className="pfd-node" onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}>
      <BodyWithHandles color={color} visible={hov} bodyStyle={{ width: 28, height: 28, padding: 3, borderColor: `${color}${hov ? '99' : '66'}`, transition: 'border-color 0.15s' }}>
        <svg width="22" height="22" viewBox="0 0 22 22">
          <line x1="0" y1="11" x2="22" y2="11" stroke={color} strokeWidth="1.5"/>
          <polygon points="5,5 17,11 5,17" fill={`${color}60`} stroke={color} strokeWidth="1"/>
          <line x1="11" y1="2" x2="11" y2="8" stroke={color} strokeWidth="1.2"/>
          <rect x="8" y="0" width="6" height="3" fill={color} rx="1"/>
        </svg>
      </BodyWithHandles>
      <div className="pfd-node-tag" style={{ fontSize: '7px' }}>{data.tag}</div>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 섹션 헤더 라벨
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export function SectionLabelNode({ data }: NodeProps) {
  return (
    <div style={{
      background: `linear-gradient(90deg, ${data.color}15, transparent)`,
      border: `1px solid ${data.color}28`,
      borderLeft: `3px solid ${data.color}`,
      borderRadius: '0 6px 6px 0',
      padding: '4px 20px 4px 10px',
      pointerEvents: 'none',
      userSelect: 'none',
      whiteSpace: 'nowrap',
    }}>
      <span style={{
        fontSize: 11, fontWeight: 700, color: data.color,
        fontFamily: 'JetBrains Mono, monospace',
        letterSpacing: '0.5px',
      }}>
        {data.label}
      </span>
    </div>
  );
}
