'use client';
import { FC, useState, useCallback } from 'react';
import {
  EdgeProps,
  getSmoothStepPath,
  EdgeLabelRenderer,
  BaseEdge,
} from 'reactflow';
import { usePFDStore } from '@/lib/stores/pfdStore';
import { useBalanceStore } from '@/lib/stores/balanceStore';

// ── Tooltip row helper ─────────────────────────────────────────────────────
function TRow({ label, value, unit, color }: {
  label: string; value: string | number | undefined; unit?: string; color?: string;
}) {
  if (value == null || value === '') return null;
  return (
    <tr>
      <td style={{ color: '#64748b', paddingRight: 10, fontSize: 10, whiteSpace: 'nowrap', paddingBottom: 2 }}>
        {label}
      </td>
      <td style={{ color: color ?? '#e2e8f0', fontWeight: 600, fontSize: 10, whiteSpace: 'nowrap' }}>
        {typeof value === 'number' ? value.toLocaleString('en', { maximumFractionDigits: 1 }) : value}
        {unit && <span style={{ color: '#64748b', fontWeight: 400, marginLeft: 3 }}>{unit}</span>}
      </td>
    </tr>
  );
}

/**
 * StreamEdge -- custom ReactFlow edge
 *
 * - Renders the pipe path + a stream-number badge in the middle
 * - Double-click (EDIT MODE ONLY) to edit the stream number
 * - Hover shows a rich styled tooltip with stream data
 */
const StreamEdge: FC<EdgeProps> = ({
  id,
  sourceX, sourceY,
  targetX, targetY,
  sourcePosition, targetPosition,
  style,
  markerEnd,
  data,
}) => {
  const [editing, setEditing] = useState(false);
  const [draft,   setDraft]   = useState('');
  const [hovered, setHovered] = useState(false);

  const { edgeStreamMap, setEdgeStream, editMode } = usePFDStore();
  const balance = useBalanceStore(s => s.balance);
  const streams = balance?.streams ?? [];

  // Override in store wins over the initial data.streamId
  const streamId: string = edgeStreamMap[id] ?? data?.streamId ?? '';
  const stream = streamId ? streams.find(s => s.id === streamId) : undefined;

  const [edgePath, labelX, labelY] = getSmoothStepPath({
    sourceX, sourceY, sourcePosition,
    targetX, targetY, targetPosition,
    borderRadius: 8,
  });

  // ── Edit: only allowed in edit mode ───────────────────────────────────
  const startEdit = useCallback((evt: React.MouseEvent) => {
    evt.stopPropagation();
    if (!editMode) return;   // VIEW MODE: no editing
    setDraft(streamId);
    setEditing(true);
  }, [streamId, editMode]);

  const commitEdit = useCallback(() => {
    const v = draft.trim();
    setEdgeStream(id, v);   // empty string = clear
    setEditing(false);
  }, [draft, id, setEdgeStream]);

  const edgeColor = (style?.stroke as string) ?? data?.color ?? '#94a3b8';

  // ── Format flow rate ───────────────────────────────────────────────────
  const flowLabel = stream?.total_kgh != null
    ? stream.total_kgh >= 1000
      ? `${(stream.total_kgh / 1000).toFixed(1)} t/h`
      : `${stream.total_kgh.toFixed(0)} kg/h`
    : null;

  // ── Components summary ─────────────────────────────────────────────────
  const compLines = stream?.components
    ? Object.entries(stream.components)
        .filter(([, v]) => v != null && (v as number) > 0)
        .map(([k, v]) => `${k}: ${(v as number).toFixed(1)} kg/h`)
    : [];

  return (
    <>
      <BaseEdge path={edgePath} markerEnd={markerEnd} style={style} />

      <EdgeLabelRenderer>
        <div
          style={{
            position: 'absolute',
            transform: `translate(-50%,-50%) translate(${labelX}px,${labelY}px)`,
            pointerEvents: 'all',
            zIndex: 20,
          }}
          className="nodrag nopan"
        >
          {editing ? (
            /* ── Edit input ────────────────────────────────────────── */
            <input
              autoFocus
              value={draft}
              onChange={e => setDraft(e.target.value)}
              onBlur={commitEdit}
              onKeyDown={e => {
                if (e.key === 'Enter')  commitEdit();
                if (e.key === 'Escape') setEditing(false);
              }}
              onClick={e => e.stopPropagation()}
              placeholder="e.g. 201"
              style={{
                width: 72,
                fontSize: 11,
                padding: '2px 6px',
                border: `1.5px solid ${edgeColor}`,
                borderRadius: 4,
                background: '#0f172a',
                color: '#f1f5f9',
                outline: 'none',
                fontFamily: 'monospace',
              }}
            />
          ) : streamId ? (
            /* ── Stream badge + rich hover tooltip ─────────────────── */
            <div style={{ position: 'relative', display: 'inline-block' }}>
              {/* Badge */}
              <div
                onMouseEnter={() => setHovered(true)}
                onMouseLeave={() => setHovered(false)}
                onDoubleClick={startEdit}
                style={{
                  background: edgeColor + '1a',
                  border: `1px solid ${edgeColor}70`,
                  borderRadius: 4,
                  padding: '1px 6px',
                  fontSize: 10,
                  fontWeight: 700,
                  color: edgeColor,
                  cursor: editMode ? 'pointer' : 'default',
                  userSelect: 'none',
                  whiteSpace: 'nowrap',
                  lineHeight: 1.6,
                  backdropFilter: 'blur(3px)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 4,
                }}
              >
                <span>[{streamId}]</span>
                {flowLabel && (
                  <span style={{ opacity: 0.65, fontWeight: 400 }}>{flowLabel}</span>
                )}
              </div>

              {/* Rich tooltip */}
              {hovered && (
                <div
                  style={{
                    position: 'absolute',
                    bottom: '100%',
                    left: '50%',
                    transform: 'translateX(-50%)',
                    marginBottom: 8,
                    background: 'rgba(10,14,26,0.97)',
                    border: `1px solid ${edgeColor}44`,
                    borderRadius: 10,
                    padding: '10px 14px',
                    minWidth: 200,
                    zIndex: 9999,
                    boxShadow: `0 8px 32px rgba(0,0,0,0.6), 0 0 0 1px ${edgeColor}22`,
                    backdropFilter: 'blur(12px)',
                    pointerEvents: 'none',
                    fontFamily: "'Inter', system-ui, sans-serif",
                  }}
                >
                  {/* Header */}
                  <div style={{
                    display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8,
                    paddingBottom: 8, borderBottom: `1px solid ${edgeColor}30`,
                  }}>
                    <div style={{
                      width: 8, height: 8, borderRadius: '50%',
                      background: edgeColor,
                      boxShadow: `0 0 6px ${edgeColor}`,
                    }}/>
                    <span style={{ fontSize: 12, fontWeight: 800, color: '#f1f5f9', letterSpacing: '0.02em' }}>
                      Stream [{streamId}]
                    </span>
                    {stream?.phase && (
                      <span style={{
                        marginLeft: 'auto',
                        fontSize: 9, fontWeight: 700,
                        color: edgeColor,
                        background: edgeColor + '22',
                        border: `1px solid ${edgeColor}44`,
                        borderRadius: 3, padding: '1px 5px',
                      }}>
                        {stream.phase}
                      </span>
                    )}
                  </div>

                  {stream ? (
                    <table style={{ borderCollapse: 'collapse', width: '100%' }}>
                      <tbody>
                        <TRow label="Total Flow" value={stream.total_kgh?.toFixed(1)}  unit="kg/h"      color={edgeColor} />
                        <TRow label="Mass Flow"  value={stream.total_kgh != null ? (stream.total_kgh * 24 / 1000).toFixed(2) : undefined} unit="t/day" />
                        <TRow label="Temp"       value={stream.temperature_C}          unit="°C"        />
                        <TRow label="Pressure"   value={stream.pressure_kgcm2g}        unit="kg/cm²G"   />
                        <TRow label="Density"    value={stream.density_kgm3}           unit="kg/m³"     />
                        {stream.concentration != null && (
                          <TRow label="Conc."    value={stream.concentration.toFixed(1)} unit="wt%"     />
                        )}
                        {compLines.length > 0 && (
                          <tr><td colSpan={2} style={{ paddingTop: 6, paddingBottom: 2 }}>
                            <div style={{ fontSize: 9, color: '#475569', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 3 }}>Components</div>
                            {compLines.slice(0, 4).map(l => (
                              <div key={l} style={{ fontSize: 9, color: '#94a3b8', lineHeight: 1.6 }}>{l}</div>
                            ))}
                          </td></tr>
                        )}
                      </tbody>
                    </table>
                  ) : (
                    <div style={{ fontSize: 10, color: '#ef4444', marginTop: 4 }}>
                      Stream data not found
                    </div>
                  )}

                  {editMode && (
                    <div style={{
                      marginTop: 8, paddingTop: 7,
                      borderTop: `1px solid rgba(255,255,255,0.06)`,
                      fontSize: 9, color: '#475569',
                    }}>
                      Double-click to edit stream number
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : editMode ? (
            /* ── Edit mode, no stream yet: show dot hint ────────────── */
            <div
              onDoubleClick={startEdit}
              title="Double-click to assign stream number"
              style={{
                width: 10, height: 10,
                borderRadius: '50%',
                border: '1px dashed #475569',
                cursor: 'pointer',
                background: 'transparent',
              }}
            />
          ) : null}
        </div>
      </EdgeLabelRenderer>
    </>
  );
};

export default StreamEdge;
