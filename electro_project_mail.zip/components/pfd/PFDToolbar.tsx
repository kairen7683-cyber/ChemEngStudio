'use client';
import React, { useCallback, useRef, useState, useEffect } from 'react';
import { usePFDStore } from '@/lib/stores/pfdStore';

/* ── Icon helpers ─────────────────────────────────────────── */
const PencilIcon = () => (
  <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4z"/>
  </svg>
);
const CheckIcon = () => (
  <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 6 9 17 4 12"/>
  </svg>
);
const EyeIcon = ({ open }: { open: boolean }) => open ? (
  <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
  </svg>
) : (
  <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19M1 1l22 22"/>
  </svg>
);
const GridIcon = () => (
  <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
    <rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
  </svg>
);
const PlusIcon = () => (
  <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
    <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
  </svg>
);
const ResetIcon = () => (
  <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <polyline points="3 6 5 6 21 6"/>
    <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
    <path d="M10 11v6M14 11v6M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
  </svg>
);
const ExportIcon = () => (
  <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
    <polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
  </svg>
);
const UndoIcon = () => (
  <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
    <polyline points="9 14 4 9 9 4"/>
    <path d="M20 20v-7a4 4 0 0 0-4-4H4"/>
  </svg>
);
const RedoIcon = () => (
  <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
    <polyline points="15 14 20 9 15 4"/>
    <path d="M4 20v-7a4 4 0 0 1 4-4h12"/>
  </svg>
);
const ImportIcon = () => (
  <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
    <polyline points="17 8 12 3 7 8"/>
    <line x1="12" y1="3" x2="12" y2="15"/>
  </svg>
);

/* ── Button ───────────────────────────────────────────────── */
function Btn({ children, color = '#8892a4', isActive, activeColor, title, onClick }: {
  children: React.ReactNode; color?: string; isActive?: boolean;
  activeColor?: string; title?: string; onClick?: () => void;
}) {
  const [hov, setHov] = React.useState(false);
  return (
    <button
      title={title} onClick={onClick}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{
        height: 30, padding: '0 10px', borderRadius: 6,
        fontSize: 11, fontWeight: 600, cursor: 'pointer',
        background: hov ? 'rgba(255,255,255,0.07)' : 'transparent',
        color: isActive && activeColor ? activeColor : color,
        border: 'none',
        display: 'flex', alignItems: 'center', gap: 5,
        transition: 'background 0.15s, color 0.15s',
        whiteSpace: 'nowrap',
      }}
    >{children}</button>
  );
}

const Sep = () => (
  <div style={{ width: 1, height: 20, background: 'rgba(255,255,255,0.1)', flexShrink: 0 }} />
);

/* ── Auto-save indicator ──────────────────────────────────── */
function AutoSaveIndicator() {
  const [savedAt, setSavedAt] = useState('');

  function now() {
    return new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  // Watch for store changes — zustand persist saves automatically.
  // We just show a "saved N seconds ago" indicator.
  useEffect(() => {
    // Show "방금 저장됨" on mount
    setSavedAt(now());
    // Pulse on any store change
    const unsub = usePFDStore.subscribe(() => {
      setSavedAt(now());
    });
    return unsub;
  }, []);

  if (!savedAt) return null;

  return (
    <span style={{
      fontSize: 10, color: '#4ade80', padding: '2px 7px',
      background: 'rgba(74,222,128,0.08)',
      border: '1px solid rgba(74,222,128,0.2)',
      borderRadius: 4,
      display: 'flex', alignItems: 'center', gap: 4,
    }}>
      <span style={{ fontSize: 9 }}>●</span>
      자동저장됨 {savedAt}
    </span>
  );
}

/* ── Import helper ────────────────────────────────────────── */
function importJSON(file: File): Promise<void> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const text = ev.target?.result as string;
        const payload = JSON.parse(text);

        // Basic validation
        if (!payload || typeof payload !== 'object') {
          throw new Error('유효하지 않은 백업 파일입니다.');
        }
        if (payload.version === undefined) {
          throw new Error('PFD 백업 파일이 아닙니다 (version 필드 없음).');
        }

        const savedAt = payload.savedAt
          ? new Date(payload.savedAt).toLocaleString('ko-KR')
          : '알 수 없음';

        const ok = window.confirm(
          `백업 파일을 불러오겠습니까?\n\n저장 시각: ${savedAt}\n\n현재 편집 내용은 덮어씌워집니다.`
        );
        if (!ok) { resolve(); return; }

        // Apply all persisted fields from the backup
        usePFDStore.setState({
          nodePositions:   payload.nodePositions   ?? {},
          edgeStreamMap:   payload.edgeStreamMap   ?? {},
          userNodes:       payload.userNodes        ?? [],
          userEdges:       payload.userEdges        ?? [],
          deletedNodeIds:  payload.deletedNodeIds   ?? [],
          deletedEdgeIds:  payload.deletedEdgeIds   ?? [],
          nodeTagOverrides: payload.nodeTagOverrides ?? {},
        });

        // Force a page reload so ReactFlow re-initialises with fresh data
        window.location.reload();
        resolve();
      } catch (err) {
        alert(`불러오기 실패: ${(err as Error).message}`);
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('파일 읽기 오류'));
    reader.readAsText(file);
  });
}

function exportJSON() {
  const s = usePFDStore.getState();
  const payload = {
    version: 1, savedAt: new Date().toISOString(),
    nodePositions: s.nodePositions,
    edgeStreamMap: s.edgeStreamMap,
    userNodes: s.userNodes,
    userEdges: s.userEdges,
    deletedNodeIds: s.deletedNodeIds,
    deletedEdgeIds: s.deletedEdgeIds,
    nodeTagOverrides: s.nodeTagOverrides,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `pfd_backup_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

/* ── Import button wrapper (hidden <input> + visible Btn) ─── */
function ImportBtnWrapper() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [hov, setHov] = React.useState(false);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) importJSON(file);
    // Reset so same file can be picked again
    e.target.value = '';
  }, []);

  return (
    <>
      <input
        ref={inputRef}
        type="file"
        accept=".json"
        style={{ display: 'none' }}
        onChange={handleFileChange}
      />
      <button
        title="백업 파일(JSON)을 불러와서 복원"
        onClick={() => inputRef.current?.click()}
        onMouseEnter={() => setHov(true)}
        onMouseLeave={() => setHov(false)}
        style={{
          height: 30, padding: '0 10px', borderRadius: 6,
          fontSize: 11, fontWeight: 600, cursor: 'pointer',
          background: hov ? 'rgba(167,139,250,0.12)' : 'transparent',
          color: '#a78bfa',
          border: 'none',
          display: 'flex', alignItems: 'center', gap: 5,
          transition: 'background 0.15s, color 0.15s',
          whiteSpace: 'nowrap',
        }}
      >
        <ImportIcon /> 불러오기
      </button>
    </>
  );
}

/* ── Main component ───────────────────────────────────────── */
interface PFDToolbarProps {
  onOpenIconManager: () => void;
  onOpenAddPanel: () => void;
  canUndo?: boolean;
  canRedo?: boolean;
  onUndo?: () => void;
  onRedo?: () => void;
}

export function PFDToolbar({ onOpenIconManager, onOpenAddPanel, canUndo, canRedo, onUndo, onRedo }: PFDToolbarProps) {
  const editMode       = usePFDStore(s => s.editMode);
  const showCrossEdges = usePFDStore(s => s.showCrossEdges);
  const setEditMode    = usePFDStore(s => s.setEditMode);
  const toggleCross    = usePFDStore(s => s.toggleCrossEdges);

  const handleReset = useCallback(() => {
    if (window.confirm(
      '모든 편집 내용(장치 삽입/삭제/위치/배관)을 초기 상태로 되돌리겠습니까?\n이 작업은 되돌릴 수 없습니다.'
    )) {
      usePFDStore.setState({
        nodePositions: {},
        userNodes: [], userEdges: [],
        deletedNodeIds: [], deletedEdgeIds: [],
        nodeTagOverrides: {}, edgeStreamMap: {},
      });
    }
  }, []);

  // Ctrl+Z / Ctrl+Y keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
        e.preventDefault();
        onUndo?.();
      }
      if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || (e.key === 'z' && e.shiftKey))) {
        e.preventDefault();
        onRedo?.();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onUndo, onRedo]);

  return (
    <div style={{
      position: 'absolute', top: 12, left: 12, zIndex: 20,
      display: 'flex', flexDirection: 'column',
      borderRadius: 10, overflow: 'hidden',
      background: 'rgba(10,14,26,0.92)',
      backdropFilter: 'blur(14px)',
      border: '1px solid rgba(255,255,255,0.1)',
    }}>
      {/* ── Button row ─────────────────────────────────────── */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '5px 8px' }}>

        {/* Edit / View toggle */}
        <Btn
          isActive={editMode} activeColor="#f97316"
          title={editMode ? '보기 모드로 전환' : '편집 모드로 전환'}
          onClick={() => setEditMode(!editMode)}
        >
          {editMode ? <CheckIcon /> : <PencilIcon />}
          {editMode ? '보기 모드' : '편집 모드'}
        </Btn>

        <Sep />

        {/* Cross-section edge toggle */}
        <Btn
          isActive={showCrossEdges} activeColor="#22d3ee"
          title={showCrossEdges ? '섹션 연결선 숨기기' : '섹션 연결선 표시'}
          onClick={toggleCross}
        >
          <EyeIcon open={showCrossEdges} />
          섹션연결
        </Btn>

        <Sep />

        {/* Icon manager */}
        <Btn color="#a78bfa" title="커스텀 아이콘 관리" onClick={onOpenIconManager}>
          <GridIcon /> 아이콘
        </Btn>

        <Sep />

        {/* Auto-save indicator */}
        <AutoSaveIndicator />

        <Sep />

        {/* Backup export / import — for sharing/backup only */}
        <Btn color="#60a5fa" title="현재 상태를 JSON 파일로 백업" onClick={exportJSON}>
          <ExportIcon /> 백업
        </Btn>
        <ImportBtnWrapper />

        {/* Edit-mode-only buttons */}
        {editMode && (
          <>
            <Sep />
            {/* Undo / Redo */}
            <Btn
              color={canUndo ? '#e2e8f0' : '#3a4050'}
              title="실행 취소 (Ctrl+Z)"
              onClick={onUndo}
            >
              <UndoIcon /> 되돌리기
            </Btn>
            <Btn
              color={canRedo ? '#e2e8f0' : '#3a4050'}
              title="다시 실행 (Ctrl+Y)"
              onClick={onRedo}
            >
              <RedoIcon /> 다시하기
            </Btn>
            <Sep />
            <Btn color="#4ade80" title="새 장치 삽입" onClick={onOpenAddPanel}>
              <PlusIcon /> 장치 삽입
            </Btn>
            <Sep />
            <Btn color="#f87171" title="모든 편집 초기화" onClick={handleReset}>
              <ResetIcon /> 초기화
            </Btn>
          </>
        )}
      </div>

      {/* ── Edit mode banner ───────────────────────────────── */}
      {editMode && (
        <div style={{
          padding: '4px 10px', fontSize: 10, fontWeight: 500,
          color: '#f97316', background: 'rgba(249,115,22,0.08)',
          borderTop: '1px solid rgba(249,115,22,0.2)',
          borderLeft: '3px solid #f97316',
          lineHeight: 1.6,
        }}>
          ✏️ 편집 모드 — 장치 이동/삭제 | 배관 끝 드래그: 재연결 | 핸들→드래그: 신규 배관 | Delete키: 삭제
          &nbsp;&nbsp;|&nbsp;&nbsp;
          <span style={{ color: '#60a5fa' }}>Ctrl+Z: 되돌리기 &nbsp; Ctrl+Y: 다시하기</span>
          &nbsp;&nbsp;|&nbsp;&nbsp;
          <span style={{ color: '#4ade80' }}>변경사항은 자동으로 브라우저에 저장됩니다</span>
        </div>
      )}
    </div>
  );
}

export default PFDToolbar;
