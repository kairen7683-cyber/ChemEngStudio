'use client';
import React, { useState, useCallback } from 'react';
import { usePFDStore, UserEquipmentNode } from '@/lib/stores/pfdStore';

// ── Equipment type catalog ─────────────────────────────────────────────────
const CATALOG = [
  { type: 'tank',          label: '드럼 / 탱크',       color: '#4ade80' },
  { type: 'pump',          label: '펌프',               color: '#60a5fa' },
  { type: 'heatExchanger', label: '열교환기',            color: '#94a3b8' },
  { type: 'tower',         label: '컬럼 / 탑',           color: '#60a5fa' },
  { type: 'compressor',    label: '압축기',              color: '#a78bfa' },
  { type: 'filter',        label: '여과기',              color: '#4ade80' },
  { type: 'separator',     label: '기액분리기',           color: '#f97316' },
  { type: 'valve',         label: '밸브',               color: '#94a3b8' },
  { type: 'electrolyzer',  label: '이온교환막 전해조',    color: '#00d4ff' },
] as const;

const SECTIONS = ['100', '200', '300', '400', '600'] as const;

const COLOR_SWATCHES = [
  '#4ade80', '#60a5fa', '#f97316', '#a78bfa',
  '#fbbf24', '#38bdf8', '#6b7280', '#00d4ff',
];

// ── Inline SVG icons per equipment type ───────────────────────────────────
function EquipIcon({ type, color }: { type: string; color: string }) {
  const s = { stroke: color, fill: 'none', strokeWidth: 2, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const };
  const icons: Record<string, React.ReactNode> = {
    tank: <><rect x="6" y="10" width="28" height="24" rx="3" {...s}/><ellipse cx="20" cy="10" rx="14" ry="4" {...s}/></>,
    pump: <><circle cx="20" cy="20" r="13" {...s}/><path d="M13 20h14M20 13v14" {...s}/></>,
    heatExchanger: <><rect x="4" y="10" width="32" height="20" rx="2" {...s}/><path d="M4 17h32M4 23h32" {...{ ...s, strokeWidth: 1.5 }}/><path d="M12 10v20M20 10v20M28 10v20" {...{ ...s, strokeWidth: 1.5 }}/></>,
    tower: <><rect x="14" y="3" width="12" height="34" rx="3" {...s}/><line x1="12" y1="13" x2="28" y2="13" {...{ ...s, strokeWidth: 1.5 }}/><line x1="12" y1="22" x2="28" y2="22" {...{ ...s, strokeWidth: 1.5 }}/></>,
    compressor: <><ellipse cx="20" cy="20" rx="13" ry="13" {...s}/><path d="M12 28l8-16 8 16" {...s}/></>,
    filter: <><rect x="5" y="5" width="30" height="30" rx="2" {...s}/><path d="M10 14h20M10 20h20M10 26h20" {...{ ...s, strokeWidth: 1.5 }}/></>,
    separator: <><rect x="6" y="8" width="28" height="26" rx="3" {...s}/><line x1="6" y1="22" x2="34" y2="22" {...{ ...s, strokeDasharray: '4 2' }}/></>,
    valve: <><path d="M8 20l12-10 12 10" {...s}/><path d="M8 20l12 10 12-10" {...s}/><line x1="20" y1="10" x2="20" y2="30" {...s}/></>,
    electrolyzer: <><rect x="4" y="8" width="32" height="24" rx="2" {...s}/><line x1="12" y1="8" x2="12" y2="32" {...{ ...s, strokeWidth: 1.5 }}/><line x1="20" y1="8" x2="20" y2="32" {...{ ...s, strokeWidth: 1.5 }}/><line x1="28" y1="8" x2="28" y2="32" {...{ ...s, strokeWidth: 1.5 }}/></>,
  };
  return (
    <svg width="40" height="40" viewBox="0 0 40 40">
      {icons[type] ?? icons['tank']}
    </svg>
  );
}

// ── Main Panel ─────────────────────────────────────────────────────────────
interface Props {
  onClose: () => void;
  onNodeAdded?: (node: import('reactflow').Node) => void;
}

export function AddEquipmentPanel({ onClose, onNodeAdded }: Props) {
  const addUserNode    = usePFDStore(s => s.addUserNode);
  const removeUserNode = usePFDStore(s => s.removeUserNode);
  const userNodes      = usePFDStore(s => s.userNodes);

  const [selType,    setSelType]    = useState<string>('tank');
  const [tag,        setTag]        = useState('');
  const [name,       setName]       = useState('');
  const [section,    setSection]    = useState<string>('100');
  const [selColor,   setSelColor]   = useState('#4ade80');

  const handleAdd = useCallback(() => {
    const trimTag  = tag.trim();
    const trimName = name.trim();
    if (!trimTag || !trimName) {
      alert('Tag와 용도/이름을 입력하세요.');
      return;
    }
    const id = `user_${Date.now()}_${Math.random().toString(36).slice(2,6)}`;
    const node: UserEquipmentNode = {
      id, tag: trimTag, name: trimName,
      type: selType, section, color: selColor,
      position: { x: 100 + Math.random() * 200, y: 100 + Math.random() * 120 },
    };
    addUserNode(node);
    // Notify parent so rfNodes can be updated immediately
    if (onNodeAdded) {
      onNodeAdded({
        id,
        type: selType,
        position: node.position,
        data: { tag: trimTag, name: trimName, color: selColor },
      });
    }
    setTag('');
    setName('');
  }, [tag, name, selType, section, selColor, addUserNode, onNodeAdded]);

  const catalogEntry = CATALOG.find(c => c.type === selType);
  const activeColor  = selColor || catalogEntry?.color || '#4ade80';

  return (
    <div style={{
      position: 'absolute', top: 0, right: 0, width: 300, height: '100%',
      background: 'rgba(10,14,26,0.96)',
      borderLeft: '1px solid rgba(255,255,255,0.1)',
      backdropFilter: 'blur(16px)',
      zIndex: 50,
      display: 'flex', flexDirection: 'column',
      fontFamily: "'Inter', system-ui, sans-serif",
      overflowY: 'auto',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '14px 16px 10px',
        borderBottom: '1px solid rgba(255,255,255,0.08)',
        flexShrink: 0,
      }}>
        <span style={{ fontSize: 13, fontWeight: 700, color: '#f1f5f9', letterSpacing: '0.02em' }}>
          ＋ 장치 삽입
        </span>
        <button onClick={onClose} style={{
          background: 'none', border: 'none', color: '#64748b',
          cursor: 'pointer', fontSize: 18, lineHeight: 1, padding: '2px 4px',
        }}>✕</button>
      </div>

      <div style={{ padding: '12px 14px', flex: 1 }}>

        {/* ─ Equipment Type selector ─ */}
        <Label>장치 종류 선택</Label>
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6, marginBottom: 14,
        }}>
          {CATALOG.map(({ type, label, color }) => {
            const active = selType === type;
            return (
              <button key={type} onClick={() => { setSelType(type); setSelColor(color); }}
                style={{
                  background: active ? color + '22' : 'rgba(255,255,255,0.04)',
                  border: active ? `1.5px solid ${color}` : '1.5px solid rgba(255,255,255,0.08)',
                  borderRadius: 8, padding: '6px 4px', cursor: 'pointer',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
                  transition: 'all 0.15s',
                }}>
                <EquipIcon type={type} color={active ? color : '#64748b'} />
                <span style={{ fontSize: 9, color: active ? color : '#64748b', fontWeight: 600, textAlign: 'center', lineHeight: 1.3 }}>
                  {label}
                </span>
              </button>
            );
          })}
        </div>

        {/* ─ Tag ─ */}
        <Label>Tag 번호 *</Label>
        <input
          value={tag} onChange={e => setTag(e.target.value)}
          placeholder="예: D-010, P-044A/B"
          style={inputStyle}
        />

        {/* ─ Name/Purpose ─ */}
        <Label>용도 / 이름 *</Label>
        <input
          value={name} onChange={e => setName(e.target.value)}
          placeholder="예: 포화조, Brine Saturation Tank"
          style={inputStyle}
        />

        {/* ─ Section ─ */}
        <Label>섹션</Label>
        <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
          {SECTIONS.map(sec => (
            <button key={sec} onClick={() => setSection(sec)} style={{
              flex: 1, height: 28, borderRadius: 5, fontSize: 11, fontWeight: 700,
              cursor: 'pointer',
              background: section === sec ? activeColor + '22' : 'rgba(255,255,255,0.05)',
              border: section === sec ? `1.5px solid ${activeColor}` : '1.5px solid rgba(255,255,255,0.1)',
              color: section === sec ? activeColor : '#64748b',
              transition: 'all 0.15s',
            }}>{sec}</button>
          ))}
        </div>

        {/* ─ Color ─ */}
        <Label>색상</Label>
        <div style={{ display: 'flex', gap: 6, marginBottom: 18, flexWrap: 'wrap' }}>
          {COLOR_SWATCHES.map(c => (
            <button key={c} onClick={() => setSelColor(c)} style={{
              width: 24, height: 24, borderRadius: 5, background: c,
              border: selColor === c ? '2px solid #fff' : '2px solid transparent',
              cursor: 'pointer', transition: 'border 0.1s',
              boxShadow: selColor === c ? '0 0 0 1px rgba(255,255,255,0.4)' : 'none',
            }}/>
          ))}
        </div>

        {/* ─ Add button ─ */}
        <button onClick={handleAdd} style={{
          width: '100%', height: 38, borderRadius: 8, fontSize: 13, fontWeight: 700,
          background: `linear-gradient(135deg, ${activeColor}dd, ${activeColor}88)`,
          border: 'none', color: '#fff', cursor: 'pointer',
          boxShadow: `0 2px 12px ${activeColor}44`,
          transition: 'opacity 0.15s', letterSpacing: '0.02em',
          marginBottom: 16,
        }}>
          ＋ 캔버스에 삽입
        </button>

        {/* ─ Added nodes list ─ */}
        {userNodes.length > 0 && (
          <>
            <div style={{
              fontSize: 10, fontWeight: 600, color: '#475569', letterSpacing: '0.06em',
              textTransform: 'uppercase', marginBottom: 8,
            }}>삽입된 장치 ({userNodes.length})</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
              {userNodes.map(n => (
                <div key={n.id} style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  background: 'rgba(255,255,255,0.04)',
                  border: '1px solid rgba(255,255,255,0.07)',
                  borderRadius: 6, padding: '5px 8px',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                    <div style={{ width: 8, height: 8, borderRadius: 2, background: n.color || '#4ade80', flexShrink: 0 }}/>
                    <div>
                      <div style={{ fontSize: 11, fontWeight: 700, color: '#e2e8f0' }}>{n.tag}</div>
                      <div style={{ fontSize: 9, color: '#64748b' }}>{n.name} · {n.section}Sec</div>
                    </div>
                  </div>
                  <button onClick={() => removeUserNode(n.id)} style={{
                    background: 'none', border: 'none', color: '#ef4444',
                    cursor: 'pointer', fontSize: 14, padding: '1px 4px', lineHeight: 1,
                  }}>✕</button>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ── Tiny helpers ────────────────────────────────────────────────────────────
function Label({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ fontSize: 10, fontWeight: 600, color: '#64748b', marginBottom: 5, letterSpacing: '0.04em', textTransform: 'uppercase' }}>
      {children}
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  width: '100%', height: 32, marginBottom: 12,
  background: 'rgba(255,255,255,0.06)',
  border: '1px solid rgba(255,255,255,0.1)',
  borderRadius: 6, color: '#e2e8f0', fontSize: 12,
  padding: '0 10px', outline: 'none', boxSizing: 'border-box',
  fontFamily: 'inherit',
};

export default AddEquipmentPanel;
