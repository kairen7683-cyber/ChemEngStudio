'use client';
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Node, Edge } from 'reactflow';
import { usePFDStore } from '@/lib/stores/pfdStore';
import { useBalanceStore } from '@/lib/stores/balanceStore';
import { FLUID_PRESETS, colorFromFluidKey, fluidKeyFromStream } from '@/lib/pfdFluidColors';

interface Props {
  selectedNodes: Node[];
  selectedEdges: Edge[];
  allNodes: Node[];
  onDeleteNode: (id: string) => void;
  onDeleteEdge: (id: string) => void;
  onNodeUpdate?: (id: string, data: { tag: string; name: string }) => void;
  onEdgeUpdate?: (id: string, streamId: string, color?: string) => void;
}

// ── Helper: get a node's display tag ────────────────────────────────────────
function getNodeTag(nodeId: string, allNodes: Node[]): string {
  const n = allNodes.find(x => x.id === nodeId);
  return n?.data?.tag ?? nodeId.split('_').slice(1).join('_') ?? nodeId;
}

export default function SelectionPanel({
  selectedNodes, selectedEdges, allNodes,
  onDeleteNode, onDeleteEdge, onNodeUpdate, onEdgeUpdate,
}: Props) {
  const {
    setNodeTagOverride, setEdgeStream, edgeStreamMap, nodeTagOverrides,
    edgeFluidMap, setEdgeAppearance,
  } = usePFDStore();
  const balance = useBalanceStore(s => s.balance);
  const streams = balance?.streams ?? [];

  // safe fallback for hydration timing
  const safeEdgeFluidMap = edgeFluidMap ?? {};

  // ── Node editing state ──────────────────────────────────────────────────
  const [nodeTag,  setNodeTag]  = useState('');
  const [nodeName, setNodeName] = useState('');

  // ── Edge editing state ──────────────────────────────────────────────────
  const [edgeStream,   setEdgeStreamLocal] = useState('');
  const [edgeColor,    setEdgeColor]       = useState('#4ade80');
  const [fluidType,    setFluidType]       = useState('Brine');

  const selNode = selectedNodes.length === 1 ? selectedNodes[0] : null;
  const selEdge = selectedEdges.length === 1 ? selectedEdges[0] : null;

  // Sync inputs when selection changes
  useEffect(() => {
    if (selNode) {
      const ov = nodeTagOverrides[selNode.id];
      setNodeTag(ov?.tag   ?? selNode.data?.tag  ?? '');
      setNodeName(ov?.name ?? selNode.data?.name ?? '');
    }
  }, [selNode?.id]);

  useEffect(() => {
    if (selEdge) {
      const sid = edgeStreamMap[selEdge.id] ?? selEdge.data?.streamId ?? '';
      const savedColor = (selEdge.style?.stroke as string) ?? selEdge.data?.color ?? '#4ade80';
      const savedFluid = safeEdgeFluidMap[selEdge.id] ?? selEdge.data?.fluidType ?? '';

      setEdgeStreamLocal(sid);

      if (savedFluid) {
        // 저장된 유체 종류가 있으면 우선 사용
        setFluidType(savedFluid);
        setEdgeColor(savedFluid === 'custom' ? savedColor : colorFromFluidKey(savedFluid));
      } else if (sid) {
        // 스트림 데이터에서 자동 감지
        const matched = streams.find(s => s.id === sid);
        if (matched) {
          const fk = fluidKeyFromStream(matched);
          setFluidType(fk);
          setEdgeColor(colorFromFluidKey(fk));
        } else {
          setEdgeColor(savedColor);
          setFluidType('custom');
        }
      } else {
        setEdgeColor(savedColor);
        setFluidType('custom');
      }
    }
  }, [selEdge?.id]);  // eslint-disable-line react-hooks/exhaustive-deps

  if (!selNode && !selEdge) return null;
  if (selectedNodes.length > 1 || selectedEdges.length > 1) {
    return (
      <PanelShell>
        <div style={{ fontSize: 11, color: '#64748b', padding: '8px 0' }}>
          {selectedNodes.length + selectedEdges.length}개 선택됨
        </div>
      </PanelShell>
    );
  }

  // ── NODE PANEL ──────────────────────────────────────────────────────────
  if (selNode) {
    const typeLabel: Record<string, string> = {
      tank: '드럼/탱크', pump: '펌프', heatExchanger: '열교환기',
      tower: '컬럼/탑', compressor: '압축기', filter: '여과기',
      separator: '기액분리기', valve: '밸브', electrolyzer: '이온교환막 전해조',
      sectionGroup: '섹션 그룹', streamLabel: '스트림 라벨',
    };

    const handleSaveNode = () => {
      const trimTag  = nodeTag.trim();
      const trimName = nodeName.trim();
      // 1. persist to store (survives reload)
      setNodeTagOverride(selNode.id, trimTag, trimName);
      // 2. immediately update rfNodes.data (canvas label changes now)
      onNodeUpdate?.(selNode.id, { tag: trimTag, name: trimName });
    };

    return (
      <PanelShell>
        <PanelHeader icon="⬡" title="장치 속성" subtitle={nodeTag || selNode.data?.tag} color="#4ade80" />

        <Field label="Tag 번호">
          <input value={nodeTag} onChange={e => setNodeTag(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSaveNode()}
            style={inputStyle} placeholder="e.g. D-010" />
        </Field>

        <Field label="용도 / 이름">
          <input value={nodeName} onChange={e => setNodeName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSaveNode()}
            style={inputStyle} placeholder="e.g. 포화조" />
        </Field>

        <Field label="장치 종류">
          <span style={{ fontSize: 11, color: '#94a3b8' }}>
            {typeLabel[selNode.type ?? ''] ?? selNode.type}
          </span>
        </Field>

        <Field label="노드 ID">
          <span style={{ fontSize: 10, color: '#475569', fontFamily: 'monospace' }}>
            {selNode.id}
          </span>
        </Field>

        <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
          <button onClick={handleSaveNode} style={btnStyle('#4ade80')}>
            ✓ 저장
          </button>
          <button
            onClick={() => { if (confirm(`"${nodeTag || selNode.id}" 장치를 삭제하시겠습니까?`)) onDeleteNode(selNode.id); }}
            style={btnStyle('#ef4444')}
          >
            🗑 삭제
          </button>
        </div>
      </PanelShell>
    );
  }

  // ── EDGE PANEL ──────────────────────────────────────────────────────────
  if (selEdge) {
    const srcTag = getNodeTag(selEdge.source, allNodes);
    const tgtTag = getNodeTag(selEdge.target, allNodes);

    const handleSaveEdge = () => {
      const sid = edgeStream.trim();
      setEdgeStream(selEdge.id, sid);
      // 1. 스토어에 색상+유체 저장 (리로드 후 복원될)
      setEdgeAppearance(selEdge.id, edgeColor, fluidType);
      // 2. 캔버스 즉시 반영
      onEdgeUpdate?.(selEdge.id, sid, edgeColor);
    };

    // 유체 종류 변경 → 색상 자동 적용 + 라이브 프리뷰
    const handleFluidChange = (key: string) => {
      setFluidType(key);
      if (key !== 'custom') {
        const c = colorFromFluidKey(key);
        setEdgeColor(c);
        onEdgeUpdate?.(selEdge.id, edgeStream.trim(), c);
      }
    };

    // 색상 피커 직접 변경 (기타 모드)
    const handleColorChange = (color: string) => {
      setEdgeColor(color);
      onEdgeUpdate?.(selEdge.id, edgeStream.trim(), color);
    };

    // 스트림 번호 입력 → 유체 자동 감지
    const handleStreamInput = (val: string) => {
      setEdgeStreamLocal(val);
      const matched = streams.find(s => s.id === val.trim());
      if (matched) {
        const fk = fluidKeyFromStream(matched);
        setFluidType(fk);
        const c = colorFromFluidKey(fk);
        setEdgeColor(c);
        onEdgeUpdate?.(selEdge.id, val.trim(), c);
      }
    };

    // Look up matched stream data for preview
    const matchedStream = edgeStream ? streams.find(s => s.id === edgeStream) : undefined;

    return (
      <PanelShell>
        <PanelHeader icon="⟶" title="배관 속성" subtitle={edgeStream ? `[${edgeStream}]` : '번호 없음'} color={edgeColor} />

        <Field label="스트림 번호">
          <input value={edgeStream} onChange={e => handleStreamInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSaveEdge()}
            style={inputStyle} placeholder="e.g. 104 (입력시 자동 색상적용)" />
        </Field>

        {/* ── Stream data preview ─────────────────────────────── */}
        {edgeStream && (
          <div style={{
            marginBottom: 10, padding: '8px 10px',
            background: matchedStream ? 'rgba(74,222,128,0.06)' : 'rgba(248,113,113,0.06)',
            border: `1px solid ${matchedStream ? 'rgba(74,222,128,0.2)' : 'rgba(248,113,113,0.2)'}`,
            borderRadius: 6, fontSize: 10,
          }}>
            {matchedStream ? (
              <>
                <div style={{ color: '#4ade80', fontWeight: 700, marginBottom: 5, fontSize: 10 }}>
                  ✓ {matchedStream.name}
                </div>
                <table style={{ borderCollapse: 'collapse', width: '100%' }}>
                  <tbody>
                    {matchedStream.total_kgh != null && (
                      <tr>
                        <td style={{ color: '#64748b', paddingRight: 8, paddingBottom: 3, fontSize: 10 }}>총 유량</td>
                        <td style={{ color: '#e2e8f0', fontWeight: 600, fontSize: 10 }}>
                          {matchedStream.total_kgh >= 1000
                            ? `${(matchedStream.total_kgh / 1000).toFixed(2)} t/h`
                            : `${matchedStream.total_kgh.toFixed(1)} kg/h`}
                        </td>
                      </tr>
                    )}
                    {matchedStream.temperature_C != null && (
                      <tr>
                        <td style={{ color: '#64748b', paddingRight: 8, paddingBottom: 3, fontSize: 10 }}>온도</td>
                        <td style={{ color: '#e2e8f0', fontWeight: 600, fontSize: 10 }}>{matchedStream.temperature_C} °C</td>
                      </tr>
                    )}
                    {matchedStream.pressure_kgcm2g != null && (
                      <tr>
                        <td style={{ color: '#64748b', paddingRight: 8, paddingBottom: 3, fontSize: 10 }}>압력</td>
                        <td style={{ color: '#e2e8f0', fontWeight: 600, fontSize: 10 }}>{matchedStream.pressure_kgcm2g} kg/cm²G</td>
                      </tr>
                    )}
                    {matchedStream.phase && (
                      <tr>
                        <td style={{ color: '#64748b', paddingRight: 8, paddingBottom: 3, fontSize: 10 }}>상태</td>
                        <td style={{ color: '#fbbf24', fontWeight: 700, fontSize: 10 }}>{matchedStream.phase}</td>
                      </tr>
                    )}
                    {matchedStream.concentration != null && (
                      <tr>
                        <td style={{ color: '#64748b', paddingRight: 8, paddingBottom: 3, fontSize: 10 }}>농도</td>
                        <td style={{ color: '#e2e8f0', fontWeight: 600, fontSize: 10 }}>{matchedStream.concentration.toFixed(1)} wt%</td>
                      </tr>
                    )}
                  </tbody>
                </table>
                {/* Main components */}
                {matchedStream.components && (
                  <div style={{ marginTop: 5, paddingTop: 5, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                    {Object.entries(matchedStream.components)
                      .filter(([, v]) => v != null && (v as number) > 0)
                      .slice(0, 4)
                      .map(([k, v]) => (
                        <div key={k} style={{ fontSize: 9, color: '#64748b', lineHeight: 1.6 }}>
                          {k}: <span style={{ color: '#94a3b8' }}>{(v as number).toFixed(1)} kg/h</span>
                        </div>
                      ))}
                  </div>
                )}
              </>
            ) : (
              <div style={{ color: '#f87171', fontSize: 10 }}>
                ✗ 스트림 [{edgeStream}] 없음 — 번호 확인 필요
              </div>
            )}
          </div>
        )}

        <Field label="유체 종류">
          {/* 드롭다운 선택 */}
          <select
            value={fluidType}
            onChange={e => handleFluidChange(e.target.value)}
            style={{
              ...inputStyle,
              height: 32,
              cursor: 'pointer',
              paddingRight: 4,
              background: '#1e293b',   // 다크 배경
              color: '#e2e8f0',        // 밝은 글자
              border: '1px solid rgba(255,255,255,0.15)',
              borderRadius: 5,
              fontSize: 11,
            }}
          >
            {FLUID_PRESETS.map(p => (
              <option
                key={p.key}
                value={p.key}
                style={{ background: '#1e293b', color: '#e2e8f0' }}
              >
                {p.label}
              </option>
            ))}
          </select>

          {/* 선택된 유체 색상 프리븷 */}
          {fluidType !== 'custom' && (
            <div style={{
              marginTop: 6, display: 'flex', alignItems: 'center', gap: 8,
            }}>
              <div style={{
                width: 16, height: 16, borderRadius: 3,
                background: edgeColor,
                boxShadow: `0 0 6px ${edgeColor}88`,
                flexShrink: 0,
              }} />
              <div style={{
                flex: 1, height: 3, borderRadius: 2,
                background: edgeColor,
                boxShadow: `0 0 6px ${edgeColor}88`,
              }} />
              <span style={{ fontSize: 9, color: '#475569', fontFamily: 'monospace' }}>{edgeColor}</span>
            </div>
          )}

          {/* 기타 선택 시 색상 피커 표시 */}
          {fluidType === 'custom' && (
            <div style={{ marginTop: 6, display: 'flex', alignItems: 'center', gap: 8 }}>
              <input
                type="color"
                value={edgeColor}
                onChange={e => handleColorChange(e.target.value)}
                style={{ width: 32, height: 28, padding: 0, border: 'none', borderRadius: 4, cursor: 'pointer', background: 'transparent' }}
                title="커스텀 색상"
              />
              <div style={{
                flex: 1, height: 3, borderRadius: 2,
                background: edgeColor,
                boxShadow: `0 0 6px ${edgeColor}88`,
              }} />
              <span style={{ fontSize: 9, color: '#475569', fontFamily: 'monospace' }}>{edgeColor}</span>
            </div>
          )}
        </Field>


        <Field label="출발지 (From)">
          <span style={{ fontSize: 11, color: '#94a3b8', fontFamily: 'monospace' }}>
            {srcTag}
          </span>
        </Field>

        <Field label="목적지 (To)">
          <span style={{ fontSize: 11, color: '#94a3b8', fontFamily: 'monospace' }}>
            {tgtTag}
          </span>
        </Field>

        <div style={{
          marginTop: 8, padding: '8px 10px',
          background: 'rgba(96,165,250,0.06)',
          border: '1px solid rgba(96,165,250,0.15)',
          borderRadius: 6, fontSize: 10, color: '#64748b', lineHeight: 1.6,
        }}>
          💡 배관 끝단을 드래그하면 연결 장치를 변경할 수 있습니다.
          새 배관은 장치 핸들(●)에서 드래그하여 그립니다.
        </div>

        <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
          <button onClick={handleSaveEdge} style={btnStyle('#60a5fa')}>
            ✓ 적용
          </button>
          <button
            onClick={() => { if (confirm('이 배관을 삭제하시겠습니까?')) onDeleteEdge(selEdge.id); }}
            style={btnStyle('#ef4444')}
          >
            🗑 삭제
          </button>
        </div>
      </PanelShell>
    );
  }

  return null;
}

// ── Sub-components ──────────────────────────────────────────────────────────
function PanelShell({ children }: { children: React.ReactNode }) {
  // Drag state: null = use default CSS position, otherwise absolute pixel coords
  const [pos, setPos] = useState<{ x: number; y: number } | null>(null);
  const dragging = useRef(false);
  const dragOffset = useRef({ x: 0, y: 0 });
  const panelRef = useRef<HTMLDivElement>(null);

  const onMouseDown = useCallback((e: React.MouseEvent) => {
    // Only drag on the grip area (data-drag="true")
    if (!(e.target as HTMLElement).closest('[data-drag]')) return;
    e.preventDefault();
    dragging.current = true;
    const rect = panelRef.current?.getBoundingClientRect();
    if (rect) {
      dragOffset.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    }
  }, []);

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      if (!dragging.current) return;
      setPos({
        x: e.clientX - dragOffset.current.x,
        y: e.clientY - dragOffset.current.y,
      });
    };
    const onUp = () => { dragging.current = false; };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
  }, []);

  // Dragged position uses left/top; default position uses right/top
  const posStyle: React.CSSProperties = pos
    ? { position: 'fixed', left: pos.x, top: pos.y, right: 'auto' }
    : { position: 'absolute', top: 130, right: 12 };

  return (
    <div
      ref={panelRef}
      onMouseDown={onMouseDown}
      style={{
        ...posStyle,
        width: 250, zIndex: 30,
        background: 'rgba(10,14,26,0.96)',
        border: '1px solid rgba(255,255,255,0.1)',
        borderRadius: 10, padding: '0 0 12px',
        backdropFilter: 'blur(16px)',
        boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
        fontFamily: "'Inter', system-ui, sans-serif",
        userSelect: 'none',
      }}
    >
      {/* Drag handle bar at the top */}
      <div
        data-drag="true"
        style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          height: 20, borderRadius: '10px 10px 0 0',
          background: 'rgba(255,255,255,0.04)',
          borderBottom: '1px solid rgba(255,255,255,0.07)',
          cursor: 'grab',
          userSelect: 'none',
        }}
        title="드래그하여 이동"
      >
        <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.2)', letterSpacing: 3 }}>⠿⠿⠿</span>
      </div>
      <div style={{ padding: '10px 14px 0' }}>
        {children}
      </div>
    </div>
  );
}

function PanelHeader({ icon, title, subtitle, color }: {
  icon: string; title: string; subtitle?: string; color: string;
}) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12,
      paddingBottom: 10, borderBottom: '1px solid rgba(255,255,255,0.08)',
    }}>
      <span style={{ fontSize: 16, color }}>{icon}</span>
      <div>
        <div style={{ fontSize: 11, fontWeight: 700, color: '#f1f5f9' }}>{title}</div>
        {subtitle && <div style={{ fontSize: 10, color, fontFamily: 'monospace' }}>{subtitle}</div>}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ fontSize: 9, fontWeight: 600, color: '#475569', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 4 }}>
        {label}
      </div>
      {children}
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  width: '100%', height: 28,
  background: 'rgba(255,255,255,0.06)',
  border: '1px solid rgba(255,255,255,0.1)',
  borderRadius: 5, color: '#e2e8f0', fontSize: 11,
  padding: '0 8px', outline: 'none', boxSizing: 'border-box',
  fontFamily: 'monospace',
};

const btnStyle = (color: string): React.CSSProperties => ({
  flex: 1, height: 30, borderRadius: 5, fontSize: 11, fontWeight: 600,
  border: `1px solid ${color}44`,
  background: `${color}18`,
  color, cursor: 'pointer',
  transition: 'background 0.15s',
});
