'use client';
import React, { useMemo, useState, useCallback } from 'react';
import { usePFDStore } from '@/lib/stores/pfdStore';
import { useBalanceStore } from '@/lib/stores/balanceStore';

// ── EPC Equipment List standard columns ───────────────────────────────────
export interface EquipmentItem {
  tag: string;           // Tag No. e.g. D-010
  name: string;          // Equipment Name
  type: string;          // Type (Tank, Pump, HX, Column...)
  section: string;       // Process section
  fluid: string;         // Process fluid
  qty: number;           // Quantity
  operTemp: string;      // Operating Temperature
  operPress: string;     // Operating Pressure
  designTemp: string;    // Design Temperature
  designPress: string;   // Design Pressure
  material: string;      // Shell / Lining material
  capacity: string;      // Volume / Flow / Duty
  motor: string;         // Motor (kW)
  remarks: string;       // Remarks / Notes
  nodeId?: string;       // Linked PFD node id
}

// ── Built-in equipment from PFD sections ──────────────────────────────────
const BUILTIN_EQUIPMENT: EquipmentItem[] = [
  // ── 100 SEC ─────────────────────────────────────────────────────────────
  { tag:'D-010', name:'포화조',         type:'Tank',   section:'100', fluid:'Sat. Brine', qty:1, operTemp:'70', operPress:'Atm', designTemp:'90', designPress:'FV', material:'FRP',           capacity:'~290 m³',  motor:'-',        remarks:'Salt dissolving tank. RT 90 min', nodeId:'s100_D010' },
  { tag:'D-013', name:'브라인 완충조',   type:'Tank',   section:'100', fluid:'Sat. Brine', qty:1, operTemp:'70', operPress:'Atm', designTemp:'90', designPress:'FV', material:'FRP',           capacity:'~50 m³',   motor:'-',        remarks:'Buffer tank before P-014. RT 20 min', nodeId:'s100_D013' },
  { tag:'P-014', name:'브라인 이송펌프', type:'Pump',   section:'100', fluid:'Sat. Brine', qty:2, operTemp:'70', operPress:'3.5', designTemp:'90', designPress:'6',  material:'316L SS',       capacity:'~210 m³/h',motor:'37 kW',   remarks:'A/B standby', nodeId:'s100_P014' },
  { tag:'D-020', name:'반응조',          type:'Tank',   section:'100', fluid:'Brine+Chem', qty:1, operTemp:'70', operPress:'Atm', designTemp:'90', designPress:'FV', material:'FRP',           capacity:'~210 m³',  motor:'22 kW',   remarks:'Chemical treatment. RT 60 min', nodeId:'s100_D020' },
  { tag:'P-033', name:'반응 후 이송펌프',type:'Pump',   section:'100', fluid:'Brine',      qty:2, operTemp:'70', operPress:'3.5', designTemp:'90', designPress:'6',  material:'316L SS',       capacity:'~210 m³/h',motor:'37 kW',   remarks:'A/B standby' },
  { tag:'T-030', name:'침전조',          type:'Settler',section:'100', fluid:'Brine Slurry',qty:1,operTemp:'65', operPress:'Atm', designTemp:'80', designPress:'FV', material:'CS+Epoxy',      capacity:'D=23 m',   motor:'-',        remarks:'Gravity thickener. SLR 0.5 m³/m²h', nodeId:'s100_T030' },
  { tag:'P-154', name:'침전 후 이송펌프',type:'Pump',   section:'100', fluid:'Brine',      qty:2, operTemp:'65', operPress:'2.5', designTemp:'80', designPress:'5',  material:'316L SS',       capacity:'~210 m³/h',motor:'37 kW',   remarks:'A/B standby', nodeId:'s100_P154' },
  { tag:'D-040', name:'여과 전 완충조',  type:'Tank',   section:'100', fluid:'Brine',      qty:1, operTemp:'65', operPress:'Atm', designTemp:'80', designPress:'FV', material:'FRP',           capacity:'~140 m³',  motor:'-',        remarks:'Pre-filter buffer. RT 40 min', nodeId:'s100_D040' },
  { tag:'P-044', name:'여과 전 이송펌프',type:'Pump',   section:'100', fluid:'Brine',      qty:2, operTemp:'65', operPress:'2.5', designTemp:'80', designPress:'5',  material:'316L SS',       capacity:'~210 m³/h',motor:'37 kW',   remarks:'A/B standby', nodeId:'s100_P044' },
  { tag:'F-150', name:'카본 필터',       type:'Filter', section:'100', fluid:'Brine',      qty:3, operTemp:'65', operPress:'4.0', designTemp:'80', designPress:'8',  material:'CS+Epoxy',      capacity:'D=3.3 m',  motor:'-',        remarks:'GAC filter. LV 8 m/h. 2+1 standby', nodeId:'s100_F150' },
  { tag:'D-150', name:'2차 브라인 완충조',type:'Tank',  section:'100', fluid:'Brine',      qty:1, operTemp:'65', operPress:'Atm', designTemp:'80', designPress:'FV', material:'FRP',           capacity:'~100 m³',  motor:'-',        remarks:'Pre IX buffer. RT 30 min', nodeId:'s100_D150' },
  { tag:'T-160', name:'이온교환수지탑',  type:'Column', section:'100', fluid:'Brine',      qty:2, operTemp:'65', operPress:'4.0', designTemp:'80', designPress:'8',  material:'FRP',           capacity:'D=2.1 m, H=4.2 m',motor:'-', remarks:'Chelating resin. SV 15 BV/h. 1+1', nodeId:'s100_T160' },
  { tag:'D-170', name:'정제 브라인 완충조',type:'Tank', section:'100', fluid:'Pure Brine', qty:1, operTemp:'65', operPress:'Atm', designTemp:'80', designPress:'FV', material:'FRP',           capacity:'~100 m³',  motor:'-',        remarks:'Post IX buffer. RT 30 min', nodeId:'s100_D170' },
  { tag:'P-084', name:'정제 브라인 이송펌프',type:'Pump',section:'100',fluid:'Pure Brine', qty:2, operTemp:'65', operPress:'4.5', designTemp:'80', designPress:'8',  material:'316L SS',       capacity:'~215 m³/h',motor:'55 kW',   remarks:'Feed to electrolyzer. A/B', nodeId:'s100_P084' },
  { tag:'D-080', name:'묽은 브라인 수령조',type:'Tank', section:'100', fluid:'Depleted Brine',qty:1,operTemp:'90',operPress:'Atm',designTemp:'95','designPress':'FV',material:'FRP',           capacity:'~120 m³',  motor:'-',        remarks:'Anolyte return receiver', nodeId:'s100_D080' },
  // ── 200 SEC ─────────────────────────────────────────────────────────────
  { tag:'ELEC-201~250', name:'이온교환막 전해조', type:'Electrolyzer', section:'200', fluid:'Brine/NaOH/Cl2/H2', qty:5, operTemp:'90', operPress:'0.45', designTemp:'95', designPress:'1.0', material:'Ti (anode), Ni (cathode)', capacity:'190 cells/unit, KA 16.2', motor:'-', remarks:'Asahi Kasei BiTAC membrane', nodeId:'s200_ELEC' },
  { tag:'D-210', name:'브라인 헤더 탱크',  type:'Tank',  section:'200', fluid:'Pure Brine', qty:1, operTemp:'65', operPress:'3.5', designTemp:'80', designPress:'6',  material:'FRP',           capacity:'~80 m³',   motor:'-',        remarks:'Anolyte feed header' },
  { tag:'D-220', name:'NaOH 순환조',       type:'Tank',  section:'200', fluid:'32% NaOH',   qty:1, operTemp:'85', operPress:'Atm', designTemp:'95', designPress:'FV', material:'CS+Ni lining',  capacity:'~120 m³',  motor:'-',        remarks:'Catholyte circulation tank', nodeId:'s200_D220' },
  { tag:'P-284', name:'NaOH 순환 펌프',    type:'Pump',  section:'200', fluid:'32% NaOH',   qty:2, operTemp:'85', operPress:'4.0', designTemp:'95', designPress:'7',  material:'316L SS',       capacity:'~250 m³/h',motor:'75 kW',   remarks:'A/B standby', nodeId:'s200_P284' },
  { tag:'P-374', name:'묽은 브라인 이송펌프',type:'Pump', section:'200', fluid:'Depleted Brine',qty:2,operTemp:'90',operPress:'4.0',designTemp:'95','designPress':'7', material:'316L SS',      capacity:'~200 m³/h',motor:'55 kW',   remarks:'A/B standby', nodeId:'s200_P374' },
  // ── 300 SEC ─────────────────────────────────────────────────────────────
  { tag:'E-320', name:'1차 NaOH 증발기',   type:'Evaporator',section:'300',fluid:'NaOH→50%',qty:1, operTemp:'165', operPress:'-0.8', designTemp:'175', designPress:'3.0', material:'Ni+SS', capacity:'Duty ~25 MW',  motor:'-', remarks:'Falling film, triple effect', nodeId:'s300_E320' },
  { tag:'E-330', name:'2차 NaOH 증발기',   type:'Evaporator',section:'300',fluid:'NaOH 42%',qty:1, operTemp:'109', operPress:'-0.9', designTemp:'120', designPress:'2.0', material:'Ni+SS', capacity:'',             motor:'-', remarks:'Falling film', nodeId:'s300_E330' },
  { tag:'E-340', name:'3차 NaOH 증발기',   type:'Evaporator',section:'300',fluid:'NaOH 32%',qty:1, operTemp:'68',  operPress:'-0.95',designTemp:'80',  designPress:'2.0', material:'Ni+SS', capacity:'',             motor:'-', remarks:'Falling film', nodeId:'s300_E340' },
  { tag:'D-350', name:'50% NaOH 완충조',   type:'Tank',      section:'300',fluid:'50% NaOH',qty:1, operTemp:'42',  operPress:'Atm',  designTemp:'60',  designPress:'FV',  material:'CS',    capacity:'~50 m³',       motor:'-', remarks:'Product storage buffer' },
  // ── 400 SEC ─────────────────────────────────────────────────────────────
  { tag:'T-410', name:'Cl2 세정탑',        type:'Column', section:'400', fluid:'Wet Cl2',     qty:1, operTemp:'45',  operPress:'0.27', designTemp:'95',  designPress:'0.5',  material:'FRP+PVDF lining', capacity:'D=2.5 m, Z=3 m',  motor:'-', remarks:'Cl2 wash tower. PVDF packing', nodeId:'s400_T410' },
  { tag:'E-413', name:'Cl2 냉각기',        type:'HX',     section:'400', fluid:'Wet Cl2',     qty:1, operTemp:'15',  operPress:'0.27', designTemp:'50',  designPress:'0.5',  material:'Hast. C-276', capacity:'Duty ~2 MW',        motor:'-', remarks:'Cl2 cooler. CW/Chilled water', nodeId:'s400_E413' },
  { tag:'T-420', name:'Cl2 건조탑 1단',    type:'Column', section:'400', fluid:'Dry Cl2',     qty:1, operTemp:'25',  operPress:'0.22', designTemp:'50',  designPress:'0.5',  material:'FRP+PP lining',   capacity:'D=2.5 m, Z=3 m',  motor:'-', remarks:'H2SO4 drying 75-88%. Circ. cooler req.', nodeId:'s400_T420' },
  { tag:'T-430', name:'Cl2 건조탑 2단',    type:'Column', section:'400', fluid:'Dry Cl2',     qty:1, operTemp:'25',  operPress:'0.20', designTemp:'50',  designPress:'0.5',  material:'FRP+PP lining',   capacity:'D=2.0 m, Z=2 m',  motor:'-', remarks:'H2SO4 drying 93-98%', nodeId:'s400_T430' },
  { tag:'C-450', name:'Cl2 압축기',        type:'Compressor',section:'400',fluid:'Dry Cl2',   qty:2, operTemp:'40',  operPress:'3.0',  designTemp:'60',  designPress:'4.0',  material:'Hast. C-276',     capacity:'~6,900 m³/h',    motor:'400 kW',remarks:'Reciprocating. Oil-free. A/B', nodeId:'s400_C450' },
  { tag:'D-484', name:'Cl2 액화기',        type:'HX',     section:'400', fluid:'Liq. Cl2',    qty:1, operTemp:'-25', operPress:'3.0',  designTemp:'40',  designPress:'5.0',  material:'CS (dry Cl2)',    capacity:'~19,500 kg/h',   motor:'-', remarks:'Refrigerated condenser', nodeId:'s400_D484' },
  { tag:'D-495', name:'액체 Cl2 저장탱크', type:'Tank',   section:'400', fluid:'Liq. Cl2',    qty:2, operTemp:'-17', operPress:'3.0',  designTemp:'40',  designPress:'5.0',  material:'CS',              capacity:'~1,000 m³ each', motor:'-', remarks:'2-day storage. PRV to scrubber' },
  // ── 600 SEC ─────────────────────────────────────────────────────────────
  { tag:'D-610', name:'H2 기액분리기',     type:'Separator',section:'600',fluid:'H2 Gas',     qty:1, operTemp:'90',  operPress:'0.45', designTemp:'95',  designPress:'1.0',  material:'CS',              capacity:'~400 kg/h H2',   motor:'-', remarks:'Catholyte separator', nodeId:'s600_D610' },
  { tag:'E-620', name:'H2 냉각기',         type:'HX',     section:'600', fluid:'H2 Gas',      qty:2, operTemp:'10',  operPress:'0.20', designTemp:'50',  designPress:'0.5',  material:'SS 316L',         capacity:'Duty ~1.2 MW',   motor:'-', remarks:'1st+2nd cooling. CW+Chilled', nodeId:'s600_E620' },
  { tag:'C-650', name:'H2 압축기',         type:'Compressor',section:'600',fluid:'H2 Gas',    qty:2, operTemp:'80',  operPress:'23.0', designTemp:'100', designPress:'28.0', material:'SS 316L',         capacity:'~550 kg/h H2',   motor:'55 kW', remarks:'Reciprocating. A/B standby', nodeId:'s600_C650' },
  { tag:'D-690', name:'H2 건조기',         type:'Filter', section:'600', fluid:'H2 Gas',      qty:1, operTemp:'10',  operPress:'23.0', designTemp:'40',  designPress:'28.0', material:'SS 316L',         capacity:'',               motor:'-', remarks:'Molecular sieve drying', nodeId:'s600_D690' },
];

const SECTIONS = ['ALL','100','200','300','400','600'] as const;
type SectionFilter = typeof SECTIONS[number];

const TYPE_COLORS: Record<string, string> = {
  Tank: '#4ade80', Pump: '#60a5fa', HX: '#f97316', Column: '#a78bfa',
  Evaporator: '#fbbf24', Filter: '#34d399', Compressor: '#f472b6',
  Separator: '#38bdf8', Electrolyzer: '#00d4ff', Settler: '#94a3b8',
};

function typeBadge(type: string) {
  const color = TYPE_COLORS[type] ?? '#94a3b8';
  return (
    <span style={{
      fontSize: 9, fontWeight: 700, padding: '1px 5px',
      borderRadius: 3, border: `1px solid ${color}44`,
      background: `${color}18`, color, whiteSpace: 'nowrap',
    }}>{type}</span>
  );
}

export default function EquipmentList() {
  const { userNodes, nodeTagOverrides } = usePFDStore();
  const [sectionFilter, setSectionFilter] = useState<SectionFilter>('ALL');
  const [search, setSearch] = useState('');
  const [editRow, setEditRow] = useState<string | null>(null);
  const [editData, setEditData] = useState<Partial<EquipmentItem>>({});

  // Merge user-added nodes into equipment list
  const allEquipment = useMemo<EquipmentItem[]>(() => {
    const typeMap: Record<string, string> = {
      tank: 'Tank', pump: 'Pump', heatExchanger: 'HX', tower: 'Column',
      compressor: 'Compressor', filter: 'Filter', separator: 'Separator',
      valve: 'Valve', electrolyzer: 'Electrolyzer',
    };
    const userItems: EquipmentItem[] = userNodes.map(un => ({
      tag: un.tag, name: un.name,
      type: typeMap[un.type] ?? un.type,
      section: un.section, fluid: '',
      qty: 1,
      operTemp: '', operPress: '',
      designTemp: '', designPress: '',
      material: '', capacity: '', motor: '', remarks: '사용자 삽입',
      nodeId: `s${un.section}_${un.id}`,
    }));

    // Apply tag overrides to built-in items
    const builtinWithOv = BUILTIN_EQUIPMENT.map(eq => {
      if (!eq.nodeId) return eq;
      const ov = nodeTagOverrides[eq.nodeId];
      return ov ? { ...eq, tag: ov.tag, name: ov.name } : eq;
    });

    return [...builtinWithOv, ...userItems];
  }, [userNodes, nodeTagOverrides]);

  const filtered = useMemo(() => allEquipment.filter(eq => {
    if (sectionFilter !== 'ALL' && eq.section !== sectionFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      return eq.tag.toLowerCase().includes(q) ||
             eq.name.toLowerCase().includes(q) ||
             eq.type.toLowerCase().includes(q) ||
             eq.remarks.toLowerCase().includes(q);
    }
    return true;
  }), [allEquipment, sectionFilter, search]);

  const startEdit = (eq: EquipmentItem) => {
    setEditRow(eq.tag);
    setEditData({ ...eq });
  };

  const saveEdit = () => {
    // In a full implementation, this would update pfdStore
    // For now we just close the editor
    setEditRow(null);
    setEditData({});
  };

  const exportCSV = useCallback(() => {
    const headers = ['Tag No.','Name','Type','Section','Process Fluid','Qty','Oper.Temp (°C)','Oper.Press (kg/cm²G)','Design Temp (°C)','Design Press (kg/cm²G)','Material','Capacity/Size','Motor (kW)','Remarks'];
    const rows = filtered.map(eq => [
      eq.tag, eq.name, eq.type, eq.section, eq.fluid, eq.qty,
      eq.operTemp, eq.operPress, eq.designTemp, eq.designPress,
      eq.material, eq.capacity, eq.motor, eq.remarks,
    ]);
    const csv = [headers, ...rows].map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'equipment_list.csv'; a.click();
    URL.revokeObjectURL(url);
  }, [filtered]);

  const COL_W = { tag:90, name:160, type:90, sec:50, fluid:110, qty:35, ot:65, op:70, dt:65, dp:70, mat:130, cap:140, mot:70, rem:200 };

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* ── Header ──────────────────────────────────────────── */}
      <div style={{
        padding: '10px 16px', background: 'var(--bg-surface)',
        borderBottom: '1px solid var(--border-subtle)',
        display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0,
      }}>
        <span style={{ fontSize: 13, fontWeight: 700, color: '#f1f5f9' }}>
          📋 Equipment List
        </span>
        <span style={{ fontSize: 10, color: '#475569' }}>(EPC 표준 양식)</span>

        {/* Section filter */}
        <div style={{ display: 'flex', gap: 4 }}>
          {SECTIONS.map(s => (
            <button key={s} onClick={() => setSectionFilter(s)} style={{
              height: 26, padding: '0 10px', borderRadius: 5,
              fontSize: 10, fontWeight: 600, cursor: 'pointer',
              border: `1px solid ${sectionFilter === s ? '#60a5fa44' : 'rgba(255,255,255,0.08)'}`,
              background: sectionFilter === s ? 'rgba(96,165,250,0.15)' : 'transparent',
              color: sectionFilter === s ? '#60a5fa' : '#64748b',
            }}>{s}</button>
          ))}
        </div>

        {/* Search */}
        <input
          value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Tag / Name 검색..."
          style={{
            height: 28, padding: '0 10px', borderRadius: 6,
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(255,255,255,0.1)',
            color: '#e2e8f0', fontSize: 11, outline: 'none', width: 160,
          }}
        />

        <div style={{ flex: 1 }} />
        <span style={{ fontSize: 10, color: '#475569' }}>{filtered.length}개 장치</span>

        <button onClick={exportCSV} style={{
          height: 28, padding: '0 12px', borderRadius: 6,
          background: 'rgba(74,222,128,0.12)', border: '1px solid rgba(74,222,128,0.3)',
          color: '#4ade80', fontSize: 11, fontWeight: 600, cursor: 'pointer',
        }}>
          📥 CSV 내보내기
        </button>
      </div>

      {/* ── Table ───────────────────────────────────────────── */}
      <div style={{ flex: 1, overflow: 'auto' }}>
        <table style={{
          borderCollapse: 'collapse', width: '100%',
          fontSize: 11, fontFamily: "'Inter', system-ui, sans-serif",
        }}>
          <thead>
            <tr style={{
              position: 'sticky', top: 0, zIndex: 2,
              background: 'rgba(15,23,42,0.98)',
              borderBottom: '1px solid rgba(255,255,255,0.1)',
            }}>
              {[
                ['Tag No.', COL_W.tag], ['장치명', COL_W.name], ['형식', COL_W.type],
                ['SEC', COL_W.sec], ['공정유체', COL_W.fluid], ['수량', COL_W.qty],
                ['운전온도 °C', COL_W.ot], ['운전압력 kg/cm²G', COL_W.op],
                ['설계온도 °C', COL_W.dt], ['설계압력 kg/cm²G', COL_W.dp],
                ['재질', COL_W.mat], ['용량/크기', COL_W.cap],
                ['모터 kW', COL_W.mot], ['비고', COL_W.rem], ['', 40],
              ].map(([label, w]) => (
                <th key={label as string} style={{
                  padding: '8px 8px', textAlign: 'left', fontWeight: 600,
                  fontSize: 9, color: '#64748b', letterSpacing: '0.05em',
                  textTransform: 'uppercase', minWidth: w as number,
                  borderRight: '1px solid rgba(255,255,255,0.04)',
                }}>{label}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((eq, i) => {
              const isEdit = editRow === eq.tag;
              const bg = i % 2 === 0 ? 'rgba(255,255,255,0.01)' : 'transparent';
              return (
                <tr key={`${eq.tag}-${i}`} style={{
                  background: bg, borderBottom: '1px solid rgba(255,255,255,0.03)',
                  transition: 'background 0.12s',
                }}>
                  {/* Tag */}
                  <td style={tdS}><span style={{
                    fontFamily: 'monospace', fontWeight: 700,
                    color: '#60a5fa', fontSize: 11,
                  }}>{eq.tag}</span></td>
                  {/* Name */}
                  <td style={tdS}>{isEdit
                    ? <EditInput value={editData.name ?? ''} onChange={v => setEditData(d => ({ ...d, name: v }))} />
                    : <span style={{ color: '#e2e8f0' }}>{eq.name}</span>
                  }</td>
                  {/* Type */}
                  <td style={tdS}>{typeBadge(eq.type)}</td>
                  {/* Section */}
                  <td style={{ ...tdS, textAlign: 'center' }}>
                    <span style={{ fontSize: 10, color: '#94a3b8' }}>{eq.section}</span>
                  </td>
                  {/* Fluid */}
                  <td style={tdS}>{isEdit
                    ? <EditInput value={editData.fluid ?? ''} onChange={v => setEditData(d => ({ ...d, fluid: v }))} />
                    : <span style={{ color: '#94a3b8', fontSize: 10 }}>{eq.fluid}</span>
                  }</td>
                  {/* Qty */}
                  <td style={{ ...tdS, textAlign: 'center', color: '#f1f5f9' }}>{eq.qty}</td>
                  {/* Oper Temp */}
                  <td style={{ ...tdS, textAlign: 'right' }}>{isEdit
                    ? <EditInput value={editData.operTemp ?? ''} onChange={v => setEditData(d => ({ ...d, operTemp: v }))} width={55} />
                    : <NumVal>{eq.operTemp}</NumVal>
                  }</td>
                  {/* Oper Press */}
                  <td style={{ ...tdS, textAlign: 'right' }}>{isEdit
                    ? <EditInput value={editData.operPress ?? ''} onChange={v => setEditData(d => ({ ...d, operPress: v }))} width={55} />
                    : <NumVal>{eq.operPress}</NumVal>
                  }</td>
                  {/* Design Temp */}
                  <td style={{ ...tdS, textAlign: 'right' }}>{isEdit
                    ? <EditInput value={editData.designTemp ?? ''} onChange={v => setEditData(d => ({ ...d, designTemp: v }))} width={55} />
                    : <NumVal>{eq.designTemp}</NumVal>
                  }</td>
                  {/* Design Press */}
                  <td style={{ ...tdS, textAlign: 'right' }}>{isEdit
                    ? <EditInput value={editData.designPress ?? ''} onChange={v => setEditData(d => ({ ...d, designPress: v }))} width={55} />
                    : <NumVal>{eq.designPress}</NumVal>
                  }</td>
                  {/* Material */}
                  <td style={tdS}>{isEdit
                    ? <EditInput value={editData.material ?? ''} onChange={v => setEditData(d => ({ ...d, material: v }))} />
                    : <span style={{ color: '#94a3b8', fontSize: 10 }}>{eq.material}</span>
                  }</td>
                  {/* Capacity */}
                  <td style={tdS}>{isEdit
                    ? <EditInput value={editData.capacity ?? ''} onChange={v => setEditData(d => ({ ...d, capacity: v }))} />
                    : <span style={{ color: '#f1f5f9', fontSize: 10 }}>{eq.capacity}</span>
                  }</td>
                  {/* Motor */}
                  <td style={{ ...tdS, textAlign: 'right' }}>{isEdit
                    ? <EditInput value={editData.motor ?? ''} onChange={v => setEditData(d => ({ ...d, motor: v }))} width={55} />
                    : <span style={{ color: '#fbbf24', fontSize: 10 }}>{eq.motor}</span>
                  }</td>
                  {/* Remarks */}
                  <td style={tdS}>{isEdit
                    ? <EditInput value={editData.remarks ?? ''} onChange={v => setEditData(d => ({ ...d, remarks: v }))} width={180} />
                    : <span style={{ color: '#64748b', fontSize: 10 }}>{eq.remarks}</span>
                  }</td>
                  {/* Edit button */}
                  <td style={{ ...tdS, textAlign: 'center' }}>
                    {isEdit ? (
                      <button onClick={saveEdit} style={actionBtn('#4ade80')}>✓</button>
                    ) : (
                      <button onClick={() => startEdit(eq)} style={actionBtn('#60a5fa')}>✏</button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* ── Footer summary ───────────────────────────────────── */}
      <div style={{
        padding: '6px 16px', background: 'var(--bg-surface)',
        borderTop: '1px solid var(--border-subtle)',
        display: 'flex', gap: 24, flexShrink: 0,
      }}>
        {Object.entries(
          filtered.reduce<Record<string, number>>((acc, eq) => {
            acc[eq.type] = (acc[eq.type] ?? 0) + eq.qty;
            return acc;
          }, {})
        ).map(([type, count]) => (
          <span key={type} style={{ fontSize: 10, color: '#475569' }}>
            <span style={{ color: TYPE_COLORS[type] ?? '#94a3b8', fontWeight: 700 }}>{type}</span> × {count}
          </span>
        ))}
      </div>
    </div>
  );
}

// ── Mini helpers ──────────────────────────────────────────────────────────
const tdS: React.CSSProperties = {
  padding: '6px 8px',
  borderRight: '1px solid rgba(255,255,255,0.03)',
  verticalAlign: 'middle',
};

const NumVal = ({ children }: { children: React.ReactNode }) => (
  <span style={{ fontFamily: 'monospace', fontSize: 10, color: '#94a3b8' }}>{children}</span>
);

function EditInput({ value, onChange, width = 100 }: { value: string; onChange: (v: string) => void; width?: number }) {
  return (
    <input
      value={value}
      onChange={e => onChange(e.target.value)}
      style={{
        width, height: 22, padding: '0 6px',
        background: 'rgba(255,255,255,0.07)',
        border: '1px solid rgba(96,165,250,0.4)',
        borderRadius: 3, color: '#e2e8f0', fontSize: 10, outline: 'none',
        fontFamily: 'monospace',
      }}
    />
  );
}

const actionBtn = (color: string): React.CSSProperties => ({
  width: 22, height: 22, borderRadius: 4,
  background: `${color}18`, border: `1px solid ${color}44`,
  color, fontSize: 11, cursor: 'pointer',
  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
});
