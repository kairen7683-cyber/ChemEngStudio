'use client';
import React, { useState } from 'react';
import {
  LIQUID_FLUIDS, GAS_FLUIDS,
  densityAtT, viscosityAtT, gasDensity,
} from '@/lib/physicalProperties';
import { PACKING_DB, calcPackingTower, PackingTowerInputs, TowerMode } from '@/lib/packingCalc';
import { useEquipmentList } from '@/lib/hooks/useEquipmentList';
import { exportTowerDatasheet } from '@/lib/excel/datasheetExport';

const card: React.CSSProperties = {
  background: 'rgba(255,255,255,0.03)',
  border: '1px solid rgba(255,255,255,0.08)',
  borderRadius: 10, padding: '16px 20px', marginBottom: 16,
};
const inp: React.CSSProperties = {
  width: '100%', height: 32, background: '#1e293b',
  border: '1px solid rgba(255,255,255,0.12)', borderRadius: 6,
  color: '#e2e8f0', fontSize: 12, padding: '0 10px',
  outline: 'none', boxSizing: 'border-box',
};
const sel: React.CSSProperties = { ...inp, cursor: 'pointer' };
const labelSt: React.CSSProperties = {
  fontSize: 10, fontWeight: 600, color: '#475569',
  letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 4, display: 'block',
};
const btn = (c: string): React.CSSProperties => ({
  padding: '8px 20px', borderRadius: 6, fontSize: 12, fontWeight: 700,
  border: `1px solid ${c}44`, background: `${c}18`,
  color: c, cursor: 'pointer', fontFamily: "'Inter', system-ui, sans-serif",
  transition: 'all 0.15s',
});
const sectionTitle: React.CSSProperties = {
  fontSize: 12, fontWeight: 700, color: '#94a3b8', marginBottom: 12,
  paddingBottom: 8, borderBottom: '1px solid rgba(255,255,255,0.06)',
  display: 'flex', alignItems: 'center', gap: 6,
};
const grid2: React.CSSProperties = { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 };
const grid3: React.CSSProperties = { display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 };

const n2 = (v: number | undefined, u = '') => v == null || isNaN(v) ? '—' : `${v.toFixed(2)} ${u}`.trim();

type FluidMode = 'preset' | 'manual';

export default function PackingTower() {
  const towers = useEquipmentList('tower');

  const [selectedTag, setSelectedTag]   = useState<string>('');
  const [mode, setMode]                 = useState<TowerMode>('absorption');
  const [temp, setTemp]                 = useState(25);
  const [pressure, setPressure]         = useState(101.325);
  const [packingKey, setPackingKey]     = useState('pall_50');
  const [floodFrac, setFloodFrac]       = useState(0.70);
  const [hetpCorr, setHetpCorr]         = useState(1.0);

  const [gasMode, setGasMode]                     = useState<FluidMode>('preset');
  const [gasFluidKey, setGasFluidKey]             = useState('cl2_gas');
  const [gasFlow, setGasFlow]                     = useState(1000);
  const [gasDensityManual, setGasDensityManual]   = useState(2.9);
  const [gasViscManual, setGasViscManual]          = useState(0.013);

  const [liqMode, setLiqMode]                     = useState<FluidMode>('preset');
  const [liqFluidKey, setLiqFluidKey]             = useState('process_water');
  const [liqFlow, setLiqFlow]                     = useState(5000);
  const [liqDensityManual, setLiqDensityManual]   = useState(998);
  const [liqViscManual, setLiqViscManual]          = useState(1.0);
  const [liqSigmaManual, setLiqSigmaManual]        = useState(72);

  const [separationMode, setSeparationMode] = useState<'stages' | 'kremser'>('stages');
  const [stages, setStages]   = useState(5);
  const [yIn, setYIn]         = useState(0.01);
  const [yOut, setYOut]       = useState(0.0001);
  const [absA, setAbsA]       = useState(1.5);

  const [results, setResults]   = useState<ReturnType<typeof calcPackingTower> | null>(null);
  const [error, setError]       = useState('');

  const gasFluid = GAS_FLUIDS.find(f => f.key === gasFluidKey);
  const liqFluid = LIQUID_FLUIDS.find(f => f.key === liqFluidKey);

  const getGasDensity = () => {
    if (gasMode === 'manual') return gasDensityManual;
    if (!gasFluid) return 2.9;
    if (gasFluid.MW) return gasDensity(gasFluid.MW, temp, pressure);
    return densityAtT(gasFluid, temp);
  };
  const getGasVisc    = () => gasMode === 'manual' ? gasViscManual : (gasFluid ? viscosityAtT(gasFluid, temp) : 0.013);
  const getLiqDensity = () => liqMode === 'manual' ? liqDensityManual : (liqFluid ? densityAtT(liqFluid, temp) : 998);
  const getLiqVisc    = () => liqMode === 'manual' ? liqViscManual : (liqFluid ? viscosityAtT(liqFluid, temp) : 1.0);
  const getLiqSigma   = () => liqMode === 'manual' ? liqSigmaManual : (liqFluid?.surfaceTension ?? 72);

  const handleTagSelect = (tag: string) => {
    setSelectedTag(tag);
    if (!tag) return;
    const eq = towers.find(t => t.tag === tag);
    if (!eq) return;
    if (eq.fluidKey) {
      const gasMatch = GAS_FLUIDS.find(f => f.key === eq.fluidKey);
      if (gasMatch) { setGasMode('preset'); setGasFluidKey(gasMatch.key); }
      const liqMatch = LIQUID_FLUIDS.find(f => f.key === eq.fluidKey);
      if (liqMatch) { setLiqMode('preset'); setLiqFluidKey(liqMatch.key); }
    }
  };

  const calculate = () => {
    try {
      setError('');
      const inputs: PackingTowerInputs = {
        mode,
        temperature_C: temp,
        pressure_kPa: pressure,
        gasFlow_kgh: gasFlow,
        gasDensity_kgm3: getGasDensity(),
        gasViscosity_mPas: getGasVisc(),
        liquidFlow_kgh: liqFlow,
        liquidDensity_kgm3: getLiqDensity(),
        liquidViscosity_mPas: getLiqVisc(),
        surfaceTension_mNm: getLiqSigma(),
        packingKey,
        floodingFraction: floodFrac,
        HETP_correction: hetpCorr,
        ...(separationMode === 'stages'
          ? { theoreticalStages: stages }
          : { y_in: yIn, y_out: yOut, absorptionFactor: absA }),
      };
      setResults(calcPackingTower(inputs));
    } catch (e: unknown) { setError(String(e)); }
  };

  const exportExcel = async () => {
    if (!results) return;
    const packing = PACKING_DB.find(p => p.key === packingKey);
    const eq = selectedTag ? towers.find(t => t.tag === selectedTag) : null;
    const modeKo: Record<TowerMode, string> = {
      absorption: '흡수 (Absorption)',
      stripping:  '탈거/스트리핑 (Stripping)',
      scrubbing:  '세정 (Scrubbing)',
    };

    await exportTowerDatasheet({
      tag:              eq?.tag ?? selectedTag ?? 'COL',
      service:          eq?.name ?? `${modeKo[mode]} 패킹타워`,
      mode:             modeKo[mode],
      temperature_C:    temp,
      pressure_kPa:     pressure,
      packingName:      packing?.name ?? packingKey,
      packingAp:        packing?.ap ?? 0,
      packingVoid:      packing?.voidFraction ?? 0,
      packingFp:        packing?.packingFactor ?? 0,
      packingHETP_ref:  packing?.HETP_ref ?? 0,
      floodingFraction: floodFrac,
      gasFluidName:     gasMode === 'preset'
                          ? (GAS_FLUIDS.find(f => f.key === gasFluidKey)?.nameKo ?? gasFluidKey)
                          : '직접 입력',
      gasFlow_kgh:      gasFlow,
      gasDensity_kgm3:  getGasDensity(),
      gasViscosity_mPas: getGasVisc(),
      liqFluidName:     liqMode === 'preset'
                          ? (LIQUID_FLUIDS.find(f => f.key === liqFluidKey)?.nameKo ?? liqFluidKey)
                          : '직접 입력',
      liqFlow_kgh:      liqFlow,
      liqDensity_kgm3:  getLiqDensity(),
      liqViscosity_mPas: getLiqVisc(),
      surfaceTension_mNm: getLiqSigma(),
      theoreticalStages: stages,
      separationMode:   separationMode,
      yIn:              separationMode === 'kremser' ? yIn : undefined,
      yOut:             separationMode === 'kremser' ? yOut : undefined,
      absorptionFactor: separationMode === 'kremser' ? absA : undefined,
      hetpCorrection:   hetpCorr,
      results,
    });
  };

  const modeLabel: Record<TowerMode, string> = {
    absorption: '흡수 (Absorption)',
    stripping:  '탈거/스트리핑 (Stripping)',
    scrubbing:  '세정 (Scrubbing)',
  };

  const selectedEquip = towers.find(t => t.tag === selectedTag);

  return (
    <div style={{ maxWidth: 1100 }}>

      {/* ── 장치 선택 배너 ─────────────────────────────────────── */}
      <div style={{
        ...card,
        background: 'rgba(167,139,250,0.06)',
        borderColor: 'rgba(167,139,250,0.2)',
        display: 'flex', alignItems: 'center', gap: 16,
      }}>
        <span style={{ fontSize: 18 }}>🏗</span>
        <div style={{ flex: 1 }}>
          <label style={{ ...labelSt, color: '#a78bfa', marginBottom: 6 }}>
            PFD 장치 태그 선택 (선택 시 유체 자동 적용)
          </label>
          <select
            value={selectedTag}
            onChange={e => handleTagSelect(e.target.value)}
            style={{ ...sel, maxWidth: 420 }}
          >
            <option value="" style={{ background: '#1e293b' }}>— 장치 선택 안 함 (수동 입력) —</option>
            {(['100', '200', '300', '400', '600'] as const).map(sec => {
              const secTowers = towers.filter(t => t.section === sec);
              if (!secTowers.length) return null;
              return (
                <optgroup key={sec} label={`${sec} Sec`} style={{ background: '#0f172a' }}>
                  {secTowers.map(t => (
                    <option key={t.id} value={t.tag} style={{ background: '#1e293b' }}>
                      {t.tag}{'  '}{t.name}
                    </option>
                  ))}
                </optgroup>
              );
            })}
          </select>
        </div>
        {selectedEquip && (
          <div style={{ fontSize: 11, color: '#94a3b8', minWidth: 160 }}>
            <div style={{ color: '#a78bfa', fontWeight: 700, marginBottom: 2 }}>{selectedEquip.tag}</div>
            <div>{selectedEquip.name}</div>
            <div style={{ color: '#475569', marginTop: 2 }}>Sec. {selectedEquip.section}</div>
            {selectedEquip.streamIds.length > 0 && (
              <div style={{ color: '#fbbf24', marginTop: 2 }}>
                스트림: [{selectedEquip.streamIds.join(', ')}]
              </div>
            )}
          </div>
        )}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {/* ── 왼쪽 입력 ─────────────────────────────────────────── */}
        <div>
          {/* 운전 조건 */}
          <div style={card}>
            <div style={sectionTitle}>🏗 운전 조건</div>
            <div style={{ marginBottom: 12 }}>
              <label style={labelSt}>운전 유형</label>
              <select value={mode} onChange={e => setMode(e.target.value as TowerMode)} style={sel}>
                {(Object.entries(modeLabel) as [TowerMode, string][]).map(([k, v]) => (
                  <option key={k} value={k} style={{ background: '#1e293b' }}>{v}</option>
                ))}
              </select>
            </div>
            <div style={grid2}>
              <div>
                <label style={labelSt}>온도 (°C)</label>
                <input type="number" value={temp} onChange={e => setTemp(+e.target.value)} style={inp} />
              </div>
              <div>
                <label style={labelSt}>압력 (kPa abs)</label>
                <input type="number" value={pressure} step={5} onChange={e => setPressure(+e.target.value)} style={inp} />
              </div>
            </div>
          </div>

          {/* 기체 스트림 */}
          <div style={card}>
            <div style={sectionTitle}>
              💨 기체 스트림 (Gas)
              {selectedTag && <span style={{ fontSize: 9, color: '#a78bfa', marginLeft: 6 }}>(장치 연동 — 변경 가능)</span>}
            </div>
            <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
              {(['preset', 'manual'] as FluidMode[]).map(m => (
                <button key={m} onClick={() => setGasMode(m)}
                  style={{ ...btn(m === gasMode ? '#60a5fa' : '#475569'), padding: '4px 14px', fontSize: 11 }}>
                  {m === 'preset' ? '유체 선택' : '직접 입력'}
                </button>
              ))}
            </div>
            {gasMode === 'preset' ? (
              <div style={{ marginBottom: 10 }}>
                <label style={labelSt}>기체 유체</label>
                <select value={gasFluidKey} onChange={e => setGasFluidKey(e.target.value)} style={sel}>
                  {GAS_FLUIDS.map(f => (
                    <option key={f.key} value={f.key} style={{ background: '#1e293b' }}>{f.nameKo} ({f.name})</option>
                  ))}
                </select>
                <div style={{ marginTop: 6, fontSize: 10, color: '#64748b' }}>
                  밀도: {getGasDensity().toFixed(3)} kg/m³ | 점도: {getGasVisc().toFixed(4)} mPa·s
                </div>
              </div>
            ) : (
              <div style={grid2}>
                <div>
                  <label style={labelSt}>밀도 (kg/m³)</label>
                  <input type="number" value={gasDensityManual} step={0.01}
                    onChange={e => setGasDensityManual(+e.target.value)} style={inp} />
                </div>
                <div>
                  <label style={labelSt}>점도 (mPa·s)</label>
                  <input type="number" value={gasViscManual} step={0.001}
                    onChange={e => setGasViscManual(+e.target.value)} style={inp} />
                </div>
              </div>
            )}
            <div>
              <label style={labelSt}>기체 유량 (kg/h)</label>
              <input type="number" value={gasFlow} step={100}
                onChange={e => setGasFlow(+e.target.value)} style={inp} />
            </div>
          </div>

          {/* 액체 스트림 */}
          <div style={card}>
            <div style={sectionTitle}>
              💧 액체 스트림 (Liquid)
              {selectedTag && <span style={{ fontSize: 9, color: '#a78bfa', marginLeft: 6 }}>(장치 연동 — 변경 가능)</span>}
            </div>
            <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
              {(['preset', 'manual'] as FluidMode[]).map(m => (
                <button key={m} onClick={() => setLiqMode(m)}
                  style={{ ...btn(m === liqMode ? '#60a5fa' : '#475569'), padding: '4px 14px', fontSize: 11 }}>
                  {m === 'preset' ? '유체 선택' : '직접 입력'}
                </button>
              ))}
            </div>
            {liqMode === 'preset' ? (
              <div style={{ marginBottom: 10 }}>
                <label style={labelSt}>액체 유체</label>
                <select value={liqFluidKey} onChange={e => setLiqFluidKey(e.target.value)} style={sel}>
                  {LIQUID_FLUIDS.map(f => (
                    <option key={f.key} value={f.key} style={{ background: '#1e293b' }}>{f.nameKo}</option>
                  ))}
                </select>
                <div style={{ marginTop: 6, fontSize: 10, color: '#64748b' }}>
                  밀도: {getLiqDensity().toFixed(1)} kg/m³ | 점도: {getLiqVisc().toFixed(3)} mPa·s | σ: {getLiqSigma()} mN/m
                </div>
              </div>
            ) : (
              <div style={grid3}>
                <div>
                  <label style={labelSt}>밀도 (kg/m³)</label>
                  <input type="number" value={liqDensityManual}
                    onChange={e => setLiqDensityManual(+e.target.value)} style={inp} />
                </div>
                <div>
                  <label style={labelSt}>점도 (mPa·s)</label>
                  <input type="number" value={liqViscManual} step={0.1}
                    onChange={e => setLiqViscManual(+e.target.value)} style={inp} />
                </div>
                <div>
                  <label style={labelSt}>표면장력 (mN/m)</label>
                  <input type="number" value={liqSigmaManual}
                    onChange={e => setLiqSigmaManual(+e.target.value)} style={inp} />
                </div>
              </div>
            )}
            <div>
              <label style={labelSt}>액체 유량 (kg/h)</label>
              <input type="number" value={liqFlow} step={100}
                onChange={e => setLiqFlow(+e.target.value)} style={inp} />
            </div>
          </div>
        </div>

        {/* ── 오른쪽 입력 ───────────────────────────────────────── */}
        <div>
          {/* 패킹 선택 */}
          <div style={card}>
            <div style={sectionTitle}>📦 패킹 선택</div>
            <div style={{ marginBottom: 12 }}>
              <label style={labelSt}>패킹 종류</label>
              <select value={packingKey} onChange={e => setPackingKey(e.target.value)} style={sel}>
                {PACKING_DB.map(p => (
                  <option key={p.key} value={p.key} style={{ background: '#1e293b' }}>
                    {p.name} (HETP≈{p.HETP_ref}m)
                  </option>
                ))}
              </select>
              {(() => {
                const pk = PACKING_DB.find(p => p.key === packingKey);
                if (!pk) return null;
                return (
                  <div style={{ marginTop: 6, fontSize: 10, color: '#64748b', display: 'flex', gap: 16 }}>
                    <span>ap: {pk.ap} m²/m³</span>
                    <span>ε: {pk.voidFraction}</span>
                    <span>Fp: {pk.packingFactor} ft⁻¹</span>
                    <span>HETP ref: {pk.HETP_ref} m</span>
                  </div>
                );
              })()}
            </div>
            <div style={grid2}>
              <div>
                <label style={labelSt}>홍수점 비율 ({(floodFrac * 100).toFixed(0)}%)</label>
                <input type="range" min={0.60} max={0.85} step={0.01} value={floodFrac}
                  onChange={e => setFloodFrac(+e.target.value)}
                  style={{ width: '100%', accentColor: '#60a5fa' }} />
                <div style={{ fontSize: 10, color: '#64748b', marginTop: 2 }}>권장: 65~75% (표준 70%)</div>
              </div>
              <div>
                <label style={labelSt}>HETP 보정 계수</label>
                <input type="number" value={hetpCorr} step={0.05} min={0.5} max={2.0}
                  onChange={e => setHetpCorr(+e.target.value)} style={inp} />
              </div>
            </div>
          </div>

          {/* 분리 요구사항 */}
          <div style={card}>
            <div style={sectionTitle}>🎯 분리 요구사항</div>
            <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
              {[
                { key: 'stages', label: '이론단수 직접 입력' },
                { key: 'kremser', label: 'Kremser 방정식 계산' },
              ].map(({ key, label }) => (
                <button key={key} onClick={() => setSeparationMode(key as 'stages' | 'kremser')}
                  style={{ ...btn(separationMode === key ? '#a78bfa' : '#475569'), padding: '4px 14px', fontSize: 11 }}>
                  {label}
                </button>
              ))}
            </div>
            {separationMode === 'stages' ? (
              <div>
                <label style={labelSt}>이론단수 (Theoretical Stages)</label>
                <input type="number" value={stages} min={1} max={30}
                  onChange={e => setStages(+e.target.value)} style={{ ...inp, width: 120 }} />
              </div>
            ) : (
              <div style={grid3}>
                <div>
                  <label style={labelSt}>y_in (mol frac)</label>
                  <input type="number" value={yIn} step={0.001}
                    onChange={e => setYIn(+e.target.value)} style={inp} />
                </div>
                <div>
                  <label style={labelSt}>y_out (mol frac)</label>
                  <input type="number" value={yOut} step={0.0001}
                    onChange={e => setYOut(+e.target.value)} style={inp} />
                </div>
                <div>
                  <label style={labelSt}>흡수 인자 A</label>
                  <input type="number" value={absA} step={0.1}
                    onChange={e => setAbsA(+e.target.value)} style={inp} />
                </div>
              </div>
            )}
          </div>

          {/* 계산 버튼 */}
          <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
            <button onClick={calculate} style={{ ...btn('#a78bfa'), padding: '10px 32px', fontSize: 14 }}>
              🟣 계산 실행
            </button>
            {results && (
              <button onClick={exportExcel} style={{ ...btn('#4ade80'), padding: '10px 24px', fontSize: 13 }}>
                📥 Excel 다운로드
              </button>
            )}
          </div>
          {error && <div style={{ color: '#ef4444', fontSize: 12 }}>⚠ {error}</div>}
        </div>
      </div>

      {/* ── 결과 ──────────────────────────────────────────────── */}
      {results && (
        <div style={{ ...card, border: '1px solid rgba(167,139,250,0.2)', background: 'rgba(167,139,250,0.04)', marginTop: 4 }}>
          <div style={{ ...sectionTitle, color: '#a78bfa' }}>📋 공정 데이터시트 — 패킹타워 설계 결과</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 20 }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#94a3b8', marginBottom: 8 }}>타워 치수</div>
              {[
                ['타워 직경 (계산)', `${results.tower_diameter_mm.toFixed(1)} mm`],
                ['타워 직경 (표준)', `${results.tower_diameter_std_mm} mm`],
                ['패킹 높이', `${results.packingHeight_m.toFixed(2)} m`],
                ['총 타워 높이', `${results.totalHeight_m.toFixed(2)} m`],
              ].map(([k, v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5, fontSize: 11 }}>
                  <span style={{ color: '#64748b' }}>{k}</span>
                  <span style={{ color: ['타워 직경 (표준)', '총 타워 높이'].includes(k) ? '#a78bfa' : '#e2e8f0', fontWeight: ['타워 직경 (표준)', '총 타워 높이'].includes(k) ? 700 : 500 }}>{v}</span>
                </div>
              ))}
            </div>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#94a3b8', marginBottom: 8 }}>물질전달</div>
              {[
                ['L/G 비율', n2(results.L_G_ratio)],
                ['이론단수', `${results.theoreticalStages} 단`],
                ['NTU', n2(results.NTU)],
                ['HETP', `${results.HETP_m.toFixed(3)} m`],
              ].map(([k, v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5, fontSize: 11 }}>
                  <span style={{ color: '#64748b' }}>{k}</span>
                  <span style={{ color: '#e2e8f0' }}>{v}</span>
                </div>
              ))}
            </div>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#94a3b8', marginBottom: 8 }}>유체역학</div>
              {[
                ['홍수점 속도', `${results.u_flood_ms.toFixed(3)} m/s`],
                ['운전 속도', `${results.u_operating_ms.toFixed(3)} m/s`],
                ['패킹 ΔP', `${results.dP_total_kPa.toFixed(3)} kPa`],
                ['액체 비유량', `${results.liquidFlux_m3m2h.toFixed(2)} m³/m²·h`],
              ].map(([k, v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5, fontSize: 11 }}>
                  <span style={{ color: '#64748b' }}>{k}</span>
                  <span style={{ color: '#e2e8f0' }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
