'use client';
import { useState, useMemo, useRef, useCallback } from 'react';
import { useBalanceStore } from '@/lib/stores/balanceStore';
import { StreamData } from '@/lib/calculations/streams';

// ── 섹션 메타 ──────────────────────────────────────────────────────────────
const SECTION_META: Record<string, { label: string; color: string; bg: string }> = {
  '100': { label: '100 Sec — Brine Purification',  color: '#4ade80', bg: 'rgba(74,222,128,0.06)' },
  '200': { label: '200 Sec — Electrolysis',        color: '#60a5fa', bg: 'rgba(96,165,250,0.06)' },
  '300': { label: '300 Sec — NaOH Evaporation',   color: '#f97316', bg: 'rgba(249,115,22,0.06)'  },
  '400': { label: '400 Sec — Cl₂ Processing',     color: '#00d4ff', bg: 'rgba(0,212,255,0.06)'   },
  '600': { label: '600 Sec — H₂ Processing',      color: '#a78bfa', bg: 'rgba(167,139,250,0.06)' },
};

const COMP_LABELS: Record<string, string> = {
  NaCl: 'NaCl', H2O: 'H₂O', NaOH: 'NaOH',
  Cl2: 'Cl₂', H2: 'H₂', HCl: 'HCl',
  O2: 'O₂', H2SO4: 'H₂SO₄', BaCl2: 'BaCl₂', Na2SO3: 'Na₂SO₃',
};

const ALL_COMPS = ['NaCl', 'H2O', 'NaOH', 'Cl2', 'H2', 'HCl', 'O2', 'H2SO4', 'BaCl2', 'Na2SO3'];

const PHASE_COLOR: Record<string, string> = {
  L: '#4ade80', G: '#a78bfa', 'L/G': '#fbbf24',
};

function fmt(v: number | undefined, dec = 0): string {
  if (v === undefined || v === null) return '—';
  return v.toLocaleString('ko-KR', { minimumFractionDigits: dec, maximumFractionDigits: dec });
}
function fmtFlow(v: number | undefined): string {
  if (v === undefined || v === null) return '—';
  if (v >= 1000) return `${(v / 1000).toLocaleString('ko-KR', { maximumFractionDigits: 2 })} t/h`;
  return `${v.toLocaleString('ko-KR', { maximumFractionDigits: 1 })} kg/h`;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// VIEW A : 카드/섹션별 보기 (기존)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function StreamRow({ s, color }: { s: StreamData; color: string }) {
  const [expanded, setExpanded] = useState(false);
  const comps = Object.entries(s.components ?? {})
    .filter(([, v]) => v && (v as number) > 0)
    .sort(([, a], [, b]) => (b as number) - (a as number));
  const total = s.total_kgh ?? 0;

  return (
    <>
      <tr
        onClick={() => setExpanded(x => !x)}
        style={{ cursor: 'pointer', transition: 'background 0.1s' }}
        onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.04)')}
        onMouseLeave={e => (e.currentTarget.style.background = '')}
      >
        <td style={{ padding: '7px 12px', whiteSpace: 'nowrap' }}>
          <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12, fontWeight: 700, color, letterSpacing: 0.5 }}>[{s.id}]</span>
        </td>
        <td style={{ padding: '7px 8px', fontSize: 11, color: 'var(--text-primary)', maxWidth: 200 }}>
          <div style={{ fontWeight: 500 }}>{s.name}</div>
          {s.description && <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 1 }}>{s.description}</div>}
        </td>
        <td style={{ padding: '7px 8px', textAlign: 'right', fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: 'var(--text-primary)', whiteSpace: 'nowrap' }}>{fmtFlow(total)}</td>
        <td style={{ padding: '7px 8px', textAlign: 'right', fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: '#fbbf24', whiteSpace: 'nowrap' }}>
          {s.temperature_C !== undefined ? `${fmt(s.temperature_C, 1)} °C` : '—'}
        </td>
        <td style={{ padding: '7px 8px', textAlign: 'right', fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: '#94a3b8', whiteSpace: 'nowrap' }}>
          {s.pressure_kgcm2g !== undefined ? `${fmt(s.pressure_kgcm2g, 2)}` : '—'}
        </td>
        <td style={{ padding: '7px 8px', textAlign: 'right', fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: '#94a3b8', whiteSpace: 'nowrap' }}>
          {s.density_kgm3 !== undefined ? `${fmt(s.density_kgm3, 0)}` : '—'}
        </td>
        <td style={{ padding: '7px 8px', textAlign: 'center' }}>
          <span style={{ fontSize: 10, fontWeight: 700, color: PHASE_COLOR[s.phase ?? 'L'] ?? '#94a3b8', background: `${PHASE_COLOR[s.phase ?? 'L'] ?? '#94a3b8'}18`, border: `1px solid ${PHASE_COLOR[s.phase ?? 'L'] ?? '#94a3b8'}44`, borderRadius: 4, padding: '1px 6px', fontFamily: 'JetBrains Mono, monospace' }}>
            {s.phase ?? 'L'}
          </span>
        </td>
        <td style={{ padding: '7px 8px', fontSize: 10 }}>
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            {comps.slice(0, 3).map(([k, v]) => (
              <span key={k} style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 3, padding: '1px 5px', color: 'var(--text-secondary)', fontFamily: 'JetBrains Mono, monospace', whiteSpace: 'nowrap' }}>
                {COMP_LABELS[k] ?? k}: {fmtFlow(v as number)}
              </span>
            ))}
            {comps.length > 3 && <span style={{ color: 'var(--text-muted)', fontSize: 10 }}>+{comps.length - 3}종</span>}
          </div>
        </td>
        <td style={{ padding: '7px 8px', textAlign: 'center', color: 'var(--text-muted)', fontSize: 12 }}>{expanded ? '▲' : '▼'}</td>
      </tr>
      {expanded && (
        <tr>
          <td />
          <td colSpan={8} style={{ padding: '0 8px 10px 8px' }}>
            <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 6, padding: '10px 14px', display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '6px 20px' }}>
              {comps.map(([k, v]) => {
                const pct = total > 0 ? ((v as number) / total) * 100 : 0;
                return (
                  <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontSize: 10, color: 'var(--text-muted)', minWidth: 52, fontFamily: 'JetBrains Mono, monospace' }}>{COMP_LABELS[k] ?? k}</span>
                    <div style={{ flex: 1, height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 2, overflow: 'hidden' }}>
                      <div style={{ width: `${Math.min(pct, 100)}%`, height: '100%', background: color, borderRadius: 2 }} />
                    </div>
                    <span style={{ fontSize: 10, color: 'var(--text-primary)', fontFamily: 'JetBrains Mono, monospace', minWidth: 80, textAlign: 'right', whiteSpace: 'nowrap' }}>{fmtFlow(v as number)}</span>
                    <span style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'JetBrains Mono, monospace', minWidth: 42, textAlign: 'right' }}>{fmt(pct, 1)}%</span>
                  </div>
                );
              })}
              <div style={{ gridColumn: '1 / -1', marginTop: 6, paddingTop: 6, borderTop: '1px solid rgba(255,255,255,0.06)', display: 'flex', gap: 24, flexWrap: 'wrap', fontSize: 10 }}>
                {[
                  { k: '총 유량', v: fmtFlow(s.total_kgh) },
                  { k: '온도', v: s.temperature_C !== undefined ? `${fmt(s.temperature_C, 1)} °C` : undefined },
                  { k: '압력', v: s.pressure_kgcm2g !== undefined ? `${fmt(s.pressure_kgcm2g, 2)} kg/cm²G` : undefined },
                  { k: '밀도', v: s.density_kgm3 !== undefined ? `${fmt(s.density_kgm3, 0)} kg/m³` : undefined },
                  { k: '농도', v: s.concentration !== undefined ? `${fmt(s.concentration, 1)} wt%` : undefined },
                  { k: '상', v: s.phase },
                ].filter(r => r.v).map(r => (
                  <div key={r.k} style={{ display: 'flex', gap: 4 }}>
                    <span style={{ color: 'var(--text-muted)' }}>{r.k}:</span>
                    <span style={{ color: 'var(--text-primary)', fontFamily: 'JetBrains Mono, monospace', fontWeight: 600 }}>{r.v}</span>
                  </div>
                ))}
              </div>
            </div>
          </td>
        </tr>
      )}
    </>
  );
}

function SectionBlock({ section, streams }: { section: string; streams: StreamData[] }) {
  const meta = SECTION_META[section] ?? { label: section, color: '#94a3b8', bg: 'rgba(255,255,255,0.03)' };
  const [collapsed, setCollapsed] = useState(false);
  return (
    <div style={{ marginBottom: 24 }}>
      <div onClick={() => setCollapsed(x => !x)} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 14px', cursor: 'pointer', background: meta.bg, border: `1px solid ${meta.color}22`, borderRadius: collapsed ? 8 : '8px 8px 0 0', borderBottom: collapsed ? undefined : 'none', userSelect: 'none' }}>
        <div style={{ width: 8, height: 8, borderRadius: '50%', background: meta.color, boxShadow: `0 0 8px ${meta.color}` }} />
        <span style={{ fontSize: 12, fontWeight: 700, color: meta.color, flex: 1 }}>{meta.label}</span>
        <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>{streams.length}개 스트림</span>
        <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{collapsed ? '▶' : '▼'}</span>
      </div>
      {!collapsed && (
        <div style={{ border: `1px solid ${meta.color}22`, borderTop: 'none', borderRadius: '0 0 8px 8px', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'rgba(255,255,255,0.03)', borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
                {['스트림 No.','스트림명','총 유량','온도','압력 (kg/cm²G)','밀도 (kg/m³)','상','조성 (주요)',''].map((h, i) => (
                  <th key={i} style={{ padding: '6px 8px', textAlign: i >= 2 && i <= 5 ? 'right' : i === 6 ? 'center' : 'left', fontSize: 9, fontWeight: 700, color: 'var(--text-muted)', letterSpacing: '0.05em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {streams.map(s => <StreamRow key={s.id} s={s} color={meta.color} />)}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 드래그 스크롤 훅 (마우스로 잡아끌기)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function useDragScroll() {
  const ref = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);
  const startX    = useRef(0);
  const startY    = useRef(0);
  const scrollLeft = useRef(0);
  const scrollTop  = useRef(0);
  const moved      = useRef(false);

  const onMouseDown = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    // 텍스트 선택 방지, 버튼 클릭은 제외
    if ((e.target as HTMLElement).tagName === 'BUTTON') return;
    isDragging.current = true;
    moved.current      = false;
    startX.current     = e.clientX;
    startY.current     = e.clientY;
    scrollLeft.current = ref.current?.scrollLeft ?? 0;
    scrollTop.current  = ref.current?.scrollTop  ?? 0;
    if (ref.current) ref.current.style.cursor = 'grabbing';
    e.preventDefault();
  }, []);

  const onMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging.current || !ref.current) return;
    const dx = e.clientX - startX.current;
    const dy = e.clientY - startY.current;
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) moved.current = true;
    ref.current.scrollLeft = scrollLeft.current - dx;
    ref.current.scrollTop  = scrollTop.current  - dy;
  }, []);

  const onMouseUp = useCallback(() => {
    isDragging.current = false;
    if (ref.current) ref.current.style.cursor = 'grab';
  }, []);

  const onMouseLeave = useCallback(() => {
    isDragging.current = false;
    if (ref.current) ref.current.style.cursor = 'grab';
  }, []);

  return { ref, onMouseDown, onMouseMove, onMouseUp, onMouseLeave };
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// VIEW B : PFD 양식 (스트림=열, 물성=행) — 엑셀 스트림 테이블 형식
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function PFDSheetView({ streams }: { streams: StreamData[] }) {
  // 섹션별로 묶어서 순서대로 표시
  const SECTION_ORDER = ['100', '200', '300', '400', '600'];
  const bySection = useMemo(() => {
    const map: Record<string, StreamData[]> = {};
    SECTION_ORDER.forEach(s => { map[s] = []; });
    streams.forEach(s => {
      const sec = s.section ?? 'etc';
      if (!map[sec]) map[sec] = [];
      map[sec].push(s);
    });
    SECTION_ORDER.forEach(sec => {
      map[sec].sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true }));
    });
    return map;
  }, [streams]);

  // 어떤 성분이 실제로 데이터에 존재하는지 확인
  const activeComps = useMemo(() =>
    ALL_COMPS.filter(c => streams.some(s => (s.components?.[c as keyof typeof s.components] ?? 0) > 0)),
    [streams]
  );

  // 고정 헤더 컬럼 너비 (스티키용)
  const LABEL_W = 180;
  const UNIT_W  = 90;
  const COL_W   = 88;

  const thBase: React.CSSProperties = {
    padding: '0 6px',
    fontFamily: 'JetBrains Mono, monospace',
    fontWeight: 700, fontSize: 10,
    whiteSpace: 'nowrap',
    position: 'sticky', top: 0, zIndex: 3,
    background: 'var(--bg-surface)',
    borderBottom: '2px solid rgba(255,255,255,0.12)',
  };

  const tdLabel: React.CSSProperties = {
    position: 'sticky', left: 0, zIndex: 2,
    background: 'var(--bg-elevated)',
    borderRight: '1px solid rgba(255,255,255,0.08)',
    padding: '5px 10px',
    fontSize: 10, fontWeight: 600,
    color: 'var(--text-secondary)',
    whiteSpace: 'nowrap',
    minWidth: LABEL_W,
  };

  const tdUnit: React.CSSProperties = {
    position: 'sticky', left: LABEL_W, zIndex: 2,
    background: 'var(--bg-elevated)',
    borderRight: '2px solid rgba(255,255,255,0.12)',
    padding: '5px 8px',
    fontSize: 9, color: 'var(--text-muted)',
    textAlign: 'right' as const,
    whiteSpace: 'nowrap',
    minWidth: UNIT_W,
  };

  const tdVal = (color?: string): React.CSSProperties => ({
    padding: '5px 8px',
    textAlign: 'right' as const,
    fontFamily: 'JetBrains Mono, monospace',
    fontSize: 10,
    color: color ?? 'var(--text-primary)',
    whiteSpace: 'nowrap',
    borderRight: '1px solid rgba(255,255,255,0.04)',
    minWidth: COL_W,
  });

  const rowStripe = (i: number): React.CSSProperties =>
    i % 2 === 0 ? {} : { background: 'rgba(255,255,255,0.02)' };

  // 섹션 구분선 행
  const SectionDivider = ({ section }: { section: string }) => {
    const meta = SECTION_META[section] ?? { label: section, color: '#94a3b8', bg: '' };
    const count = bySection[section]?.length ?? 0;
    if (count === 0) return null;
    return (
      <tr>
        <td colSpan={999} style={{
          padding: '6px 10px',
          background: meta.bg,
          borderTop: `2px solid ${meta.color}44`,
          borderBottom: `1px solid ${meta.color}22`,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 7, height: 7, borderRadius: '50%', background: meta.color, boxShadow: `0 0 6px ${meta.color}` }} />
            <span style={{ fontSize: 11, fontWeight: 700, color: meta.color }}>{meta.label}</span>
            <span style={{ fontSize: 9, color: 'var(--text-muted)' }}>({count}개 스트림)</span>
          </div>
        </td>
      </tr>
    );
  };

  // 모든 행에 걸쳐 공통으로 쓸 섹션+스트림 순서
  const orderedStreams = SECTION_ORDER.flatMap(sec => bySection[sec] ?? []);

  // 각 섹션의 첫 스트림 인덱스 (컬럼 구분선용)
  const sectionStartIdx: Record<string, number> = {};
  let idx = 0;
  SECTION_ORDER.forEach(sec => {
    sectionStartIdx[sec] = idx;
    idx += bySection[sec]?.length ?? 0;
  });

  const drag = useDragScroll();

  return (
    <div
      ref={drag.ref}
      onMouseDown={drag.onMouseDown}
      onMouseMove={drag.onMouseMove}
      onMouseUp={drag.onMouseUp}
      onMouseLeave={drag.onMouseLeave}
      style={{
        flex: 1,
        overflow: 'auto',
        position: 'relative',
        cursor: 'grab',
        userSelect: 'none',
      }}
    >
      <table style={{ borderCollapse: 'collapse', minWidth: '100%', tableLayout: 'fixed' }}>
        {/* ── 헤더 ── */}
        <thead>
          {/* 섹션 헤더 행 */}
          <tr>
            <th style={{ ...thBase, position: 'sticky', left: 0, zIndex: 4, width: LABEL_W, textAlign: 'left', padding: '8px 10px', color: 'var(--text-muted)', borderRight: '1px solid rgba(255,255,255,0.08)' }}>물성 / 항목</th>
            <th style={{ ...thBase, position: 'sticky', left: LABEL_W, zIndex: 4, width: UNIT_W, textAlign: 'right', padding: '8px 8px', color: 'var(--text-muted)', borderRight: '2px solid rgba(255,255,255,0.12)' }}>단위</th>
            {SECTION_ORDER.map(sec => {
              const sStreams = bySection[sec] ?? [];
              if (sStreams.length === 0) return null;
              const meta = SECTION_META[sec] ?? { color: '#94a3b8', label: sec };
              return (
                <th
                  key={sec}
                  colSpan={sStreams.length}
                  style={{
                    ...thBase,
                    textAlign: 'center',
                    color: meta.color,
                    background: `${meta.color}12`,
                    borderLeft: `2px solid ${meta.color}44`,
                    borderRight: `2px solid ${meta.color}44`,
                    padding: '5px 6px',
                  }}
                >
                  {meta.label}
                </th>
              );
            })}
          </tr>
          {/* 스트림 번호 행 */}
          <tr>
            <th style={{ ...thBase, position: 'sticky', left: 0, zIndex: 4, width: LABEL_W, background: 'var(--bg-surface)', borderRight: '1px solid rgba(255,255,255,0.08)', height: 36 }} />
            <th style={{ ...thBase, position: 'sticky', left: LABEL_W, zIndex: 4, width: UNIT_W, background: 'var(--bg-surface)', borderRight: '2px solid rgba(255,255,255,0.12)', height: 36 }} />
            {orderedStreams.map((s, i) => {
              const meta = SECTION_META[s.section] ?? { color: '#94a3b8' };
              const isFirstInSec = Object.values(sectionStartIdx).includes(i);
              return (
                <th key={s.id} style={{
                  ...thBase,
                  textAlign: 'center',
                  color: meta.color,
                  width: COL_W,
                  borderLeft: isFirstInSec ? `2px solid ${meta.color}44` : '1px solid rgba(255,255,255,0.06)',
                  padding: '4px 4px',
                }}>
                  <div style={{ fontSize: 11, fontWeight: 800 }}>[{s.id}]</div>
                </th>
              );
            })}
          </tr>
          {/* 스트림명 행 */}
          <tr style={{ background: 'rgba(255,255,255,0.02)' }}>
            <td style={{ ...tdLabel, fontSize: 9, fontStyle: 'italic', color: 'var(--text-muted)' }}>Stream Name</td>
            <td style={tdUnit} />
            {orderedStreams.map((s, i) => {
              const meta = SECTION_META[s.section] ?? { color: '#94a3b8' };
              const isFirstInSec = Object.values(sectionStartIdx).includes(i);
              return (
                <td key={s.id} title={s.description} style={{
                  ...tdVal(),
                  textAlign: 'center',
                  fontSize: 9,
                  color: 'var(--text-muted)',
                  borderLeft: isFirstInSec ? `2px solid ${meta.color}33` : undefined,
                  maxWidth: COL_W,
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                }}>
                  {s.name}
                </td>
              );
            })}
          </tr>
        </thead>

        {/* ── 물성 행들 ── */}
        <tbody>
          {/* Phase */}
          {[
            {
              label: 'Phase', unit: '—', render: (s: StreamData) => (
                <span style={{ fontSize: 9, fontWeight: 700, color: PHASE_COLOR[s.phase ?? 'L'] ?? '#94a3b8', background: `${PHASE_COLOR[s.phase ?? 'L'] ?? '#94a3b8'}18`, border: `1px solid ${PHASE_COLOR[s.phase ?? 'L'] ?? '#94a3b8'}44`, borderRadius: 3, padding: '1px 5px', fontFamily: 'JetBrains Mono, monospace' }}>
                  {s.phase ?? 'L'}
                </span>
              ),
              center: true,
            },
            { label: 'Temperature', unit: '°C', getVal: (s: StreamData) => fmt(s.temperature_C, 1), color: '#fbbf24' },
            { label: 'Pressure', unit: 'kg/cm²G', getVal: (s: StreamData) => fmt(s.pressure_kgcm2g, 2), color: '#94a3b8' },
            { label: 'Density', unit: 'kg/m³', getVal: (s: StreamData) => fmt(s.density_kgm3, 0), color: '#94a3b8' },
            { label: 'Concentration', unit: 'wt%', getVal: (s: StreamData) => s.concentration !== undefined ? fmt(s.concentration, 1) : '—', color: '#94a3b8' },
          ].map((row, ri) => (
            <tr key={row.label} style={rowStripe(ri)}>
              <td style={tdLabel}>{row.label}</td>
              <td style={tdUnit}>{row.unit}</td>
              {orderedStreams.map((s, i) => {
                const meta = SECTION_META[s.section] ?? { color: '#94a3b8' };
                const isFirstInSec = Object.values(sectionStartIdx).includes(i);
                return (
                  <td key={s.id} style={{
                    ...tdVal(row.color),
                    textAlign: row.center ? 'center' : 'right',
                    borderLeft: isFirstInSec ? `2px solid ${meta.color}33` : undefined,
                  }}>
                    {row.render ? row.render(s) : (row.getVal?.(s) ?? '—')}
                  </td>
                );
              })}
            </tr>
          ))}

          {/* ── 구분: 총 유량 ── */}
          <tr>
            <td colSpan={999} style={{ padding: '2px 10px', background: 'rgba(255,255,255,0.04)', borderTop: '1px solid rgba(255,255,255,0.1)', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
              <span style={{ fontSize: 9, fontWeight: 700, color: '#00d4ff', textTransform: 'uppercase', letterSpacing: '0.08em' }}>━ 유량 (Flow Rates)</span>
            </td>
          </tr>

          {/* Total Flow */}
          <tr style={rowStripe(0)}>
            <td style={{ ...tdLabel, fontWeight: 700, color: 'var(--text-primary)' }}>Total Flow</td>
            <td style={tdUnit}>kg/h</td>
            {orderedStreams.map((s, i) => {
              const meta = SECTION_META[s.section] ?? { color: '#94a3b8' };
              const isFirstInSec = Object.values(sectionStartIdx).includes(i);
              return (
                <td key={s.id} style={{ ...tdVal('#e2e8f0'), fontWeight: 700, borderLeft: isFirstInSec ? `2px solid ${meta.color}33` : undefined }}>
                  {s.total_kgh !== undefined ? fmt(s.total_kgh, 0) : '—'}
                </td>
              );
            })}
          </tr>

          {/* 성분별 유량 */}
          {activeComps.map((comp, ci) => (
            <tr key={comp} style={rowStripe(ci + 1)}>
              <td style={{ ...tdLabel, paddingLeft: 22, fontStyle: 'italic' }}>
                {COMP_LABELS[comp] ?? comp}
              </td>
              <td style={tdUnit}>kg/h</td>
              {orderedStreams.map((s, i) => {
                const meta = SECTION_META[s.section] ?? { color: '#94a3b8' };
                const isFirstInSec = Object.values(sectionStartIdx).includes(i);
                const val = s.components?.[comp as keyof typeof s.components];
                return (
                  <td key={s.id} style={{ ...tdVal(), color: val ? 'var(--text-secondary)' : 'rgba(255,255,255,0.12)', borderLeft: isFirstInSec ? `2px solid ${meta.color}33` : undefined }}>
                    {val ? fmt(val as number, 0) : '—'}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 메인 StreamTable 컴포넌트 (뷰 전환 포함)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
export default function StreamTable() {
  const balance  = useBalanceStore(s => s.balance);
  const streams  = balance?.streams ?? [];
  const summary  = balance?.summary;

  const [viewMode, setViewMode] = useState<'card' | 'pfd'>('pfd');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSection, setFilterSection] = useState<string>('all');
  const [filterPhase, setFilterPhase] = useState<string>('all');
  const [sortKey, setSortKey] = useState<'id' | 'total_kgh' | 'temperature_C'>('id');

  const filtered = useMemo(() => {
    let list = [...streams];
    if (filterSection !== 'all') list = list.filter(s => s.section === filterSection);
    if (filterPhase !== 'all')   list = list.filter(s => (s.phase ?? 'L') === filterPhase);
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(s =>
        s.id.toLowerCase().includes(q) ||
        s.name.toLowerCase().includes(q) ||
        (s.description ?? '').toLowerCase().includes(q) ||
        Object.keys(s.components ?? {}).some(k => k.toLowerCase().includes(q))
      );
    }
    list.sort((a, b) => {
      if (sortKey === 'id') return a.id.localeCompare(b.id, undefined, { numeric: true });
      if (sortKey === 'total_kgh') return (b.total_kgh ?? 0) - (a.total_kgh ?? 0);
      if (sortKey === 'temperature_C') return (b.temperature_C ?? 0) - (a.temperature_C ?? 0);
      return 0;
    });
    return list;
  }, [streams, filterSection, filterPhase, searchQuery, sortKey]);

  const grouped = useMemo(() => {
    const map: Record<string, StreamData[]> = {};
    filtered.forEach(s => {
      const sec = s.section ?? 'etc';
      if (!map[sec]) map[sec] = [];
      map[sec].push(s);
    });
    return map;
  }, [filtered]);
  const sections = Object.keys(grouped).sort();

  const totalCl2  = streams.find(s => s.id === '220')?.components?.Cl2 ?? 0;
  const totalH2   = streams.find(s => s.id === '221')?.components?.H2 ?? 0;

  const selectStyle: React.CSSProperties = {
    height: 30, padding: '0 8px',
    background: 'var(--bg-elevated)',
    border: '1px solid var(--border-default)',
    borderRadius: 6, color: 'var(--text-primary)', fontSize: 11, cursor: 'pointer',
  };

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Inter', system-ui, sans-serif", background: 'var(--bg-base)' }}>

      {/* ── 상단 바 ─────────────────────────────────────────────── */}
      <div style={{ display: 'flex', gap: 12, padding: '10px 16px', background: 'var(--bg-surface)', borderBottom: '1px solid var(--border-subtle)', flexShrink: 0, flexWrap: 'wrap', alignItems: 'center' }}>

        {/* 요약 카드 — 사이드바와 동일한 summary 소스 사용 */}
        {[
          { label: '전체 스트림 수', value: `${streams.length}개`, color: '#00d4ff' },
          { label: 'Cl₂ 생산량', value: totalCl2 ? `${(totalCl2 * 24 / 1000).toFixed(1)} t/day` : '—', color: '#60a5fa' },
          { label: 'NaOH 32% (용액)', value: summary ? `${summary.naoh32_tonDay.toFixed(1)} t/day` : '—', color: '#f97316' },
          { label: 'NaOH 50% (용액)', value: summary ? `${summary.naoh50_tonDay.toFixed(1)} t/day` : '—', color: '#fb923c' },
          { label: 'H₂ 생산량', value: totalH2 ? `${(totalH2 * 24 / 1000).toFixed(2)} t/day` : '—', color: '#a78bfa' },
        ].map(c => (
          <div key={c.label} style={{ background: `${c.color}0e`, border: `1px solid ${c.color}25`, borderRadius: 7, padding: '5px 14px', minWidth: 100 }}>
            <div style={{ fontSize: 9, color: c.color, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{c.label}</div>
            <div style={{ fontSize: 16, fontWeight: 800, color: c.color, fontFamily: 'JetBrains Mono, monospace' }}>{c.value}</div>
          </div>
        ))}

        <div style={{ flex: 1 }} />

        {/* 뷰 전환 토글 */}
        <div style={{ display: 'flex', background: 'var(--bg-elevated)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 7, overflow: 'hidden', flexShrink: 0 }}>
          {([
            { id: 'pfd',  icon: '📋', label: 'PFD 양식' },
            { id: 'card', icon: '🗂', label: '카드 보기' },
          ] as const).map(v => (
            <button
              key={v.id}
              onClick={() => setViewMode(v.id)}
              style={{
                height: 30, padding: '0 14px',
                background: viewMode === v.id ? 'rgba(0,212,255,0.15)' : 'transparent',
                border: 'none',
                borderRight: v.id === 'pfd' ? '1px solid rgba(255,255,255,0.1)' : 'none',
                color: viewMode === v.id ? '#00d4ff' : 'var(--text-muted)',
                fontSize: 11, fontWeight: viewMode === v.id ? 700 : 400,
                cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5,
                transition: 'all 0.15s',
              }}
            >
              <span>{v.icon}</span>
              <span>{v.label}</span>
            </button>
          ))}
        </div>

        {/* 필터 (카드 뷰에서만 의미있음, PFD 양식에서도 표시) */}
        <div style={{ position: 'relative', flexShrink: 0 }}>
          <span style={{ position: 'absolute', left: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 11, color: 'var(--text-muted)', pointerEvents: 'none' }}>🔍</span>
          <input
            placeholder="검색..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            style={{ ...selectStyle, padding: '0 10px 0 26px', width: 160, fontFamily: 'monospace', outline: 'none' }}
          />
        </div>
        <select value={filterSection} onChange={e => setFilterSection(e.target.value)} style={selectStyle}>
          <option value="all">전체 섹션</option>
          {['100','200','300','400','600'].map(s => <option key={s} value={s}>{s} Sec</option>)}
        </select>
        <select value={filterPhase} onChange={e => setFilterPhase(e.target.value)} style={selectStyle}>
          <option value="all">전체 상</option>
          <option value="L">액체 L</option>
          <option value="G">기체 G</option>
          <option value="L/G">기액 L/G</option>
        </select>
        {viewMode === 'card' && (
          <select value={sortKey} onChange={e => setSortKey(e.target.value as typeof sortKey)} style={selectStyle}>
            <option value="id">번호순</option>
            <option value="total_kgh">유량순</option>
            <option value="temperature_C">온도순</option>
          </select>
        )}
      </div>

      {/* ── 콘텐츠 ─────────────────────────────────────────────── */}
      {streams.length === 0 ? (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, color: 'var(--text-muted)' }}>
          <span style={{ fontSize: 36 }}>📊</span>
          <span style={{ fontSize: 13 }}>스트림 데이터가 없습니다</span>
          <span style={{ fontSize: 11 }}>전해조 입력값을 설정하면 자동 계산됩니다</span>
        </div>
      ) : viewMode === 'pfd' ? (
        <PFDSheetView streams={filtered} />
      ) : (
        <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px' }}>
          {filtered.length === 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '50%', gap: 8, color: 'var(--text-muted)' }}>
              <span style={{ fontSize: 24 }}>🔍</span>
              <span style={{ fontSize: 12 }}>검색 결과가 없습니다</span>
            </div>
          ) : sections.map(sec => <SectionBlock key={sec} section={sec} streams={grouped[sec]} />)}
        </div>
      )}
    </div>
  );
}
