'use client';
import React, { useState } from 'react';
import dynamic from 'next/dynamic';

const TABS = [
  { key: 'pump',      label: '펌프 설계',       icon: '⚙',  color: '#60a5fa' },
  { key: 'packing',   label: '패킹타워 설계',    icon: '🏗', color: '#a78bfa' },
  { key: 'pressure',  label: '차압 계산',        icon: '📊', color: '#38bdf8' },
  { key: 'equip',     label: 'Equipment List',  icon: '📋', color: '#4ade80' },
  { key: 'standards', label: '설계기준',         icon: '📏', color: '#fbbf24' },
];

// Lazy-load heavy components
const PumpDesign       = dynamic(() => import('@/components/equipment-design/PumpDesign'),       { ssr: false });
const PackingTower     = dynamic(() => import('@/components/equipment-design/PackingTower'),     { ssr: false });
const PressureDropCalc = dynamic(() => import('@/components/equipment-design/PressureDropCalc'), { ssr: false });
const EquipmentList    = dynamic(() => import('@/components/EquipmentList'),                     { ssr: false });
const DesignStandards  = dynamic(() => import('@/components/DesignStandards'),                   { ssr: false });

export default function EquipmentDesignPage() {
  const [activeTab, setActiveTab] = useState('pump');
  const active = TABS.find(t => t.key === activeTab) ?? TABS[0];

  // Equipment List / Design Standards get full-height layout (no padding/scroll wrapper)
  const isFullHeight = activeTab === 'equip' || activeTab === 'standards';

  return (
    <div style={{
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      background: 'linear-gradient(135deg, #0a0e1a 0%, #0f172a 50%, #0a1628 100%)',
      color: '#e2e8f0',
      fontFamily: "'Inter', system-ui, sans-serif",
      overflow: 'hidden',
    }}>
      {/* ── 헤더 + 탭 ──────────────────────────────────────────────── */}
      <div style={{
        padding: '16px 28px 0',
        borderBottom: '1px solid rgba(255,255,255,0.06)',
        background: 'rgba(255,255,255,0.02)',
        flexShrink: 0,
      }}>
        {/* Title */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
          <span style={{ fontSize: 20 }}>🔧</span>
          <div>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#f1f5f9' }}>장치 설계</div>
            <div style={{ fontSize: 10, color: '#64748b' }}>Equipment Process Design</div>
          </div>
        </div>

        {/* Tab navigation */}
        <div style={{ display: 'flex', gap: 2 }}>
          {TABS.map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              style={{
                padding: '8px 18px',
                borderRadius: '6px 6px 0 0',
                border: 'none',
                cursor: 'pointer',
                fontSize: 12,
                fontWeight: activeTab === tab.key ? 700 : 500,
                fontFamily: "'Inter', system-ui, sans-serif",
                background: activeTab === tab.key
                  ? `${tab.color}14`
                  : 'transparent',
                color: activeTab === tab.key ? tab.color : '#64748b',
                borderBottom: activeTab === tab.key
                  ? `2px solid ${tab.color}`
                  : '2px solid transparent',
                transition: 'all 0.15s',
                display: 'flex', alignItems: 'center', gap: 6,
              }}
            >
              <span>{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── 콘텐츠 영역 ─────────────────────────────────────────────── */}
      {isFullHeight ? (
        // Equipment List / 설계기준: 뷰포트 기반 full-height 패널 (header ~105px)
        <div style={{ height: 'calc(100vh - 105px)', minHeight: 400, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          {activeTab === 'equip'     && <EquipmentList />}
          {activeTab === 'standards' && <DesignStandards />}
        </div>
      ) : (
        // 설계 계산 탭: 스크롤 가능한 패딩 영역
        <div style={{ flex: 1, overflow: 'auto', minHeight: 0, padding: '20px 28px' }}>
          <React.Suspense fallback={
            <div style={{ textAlign: 'center', padding: 60, color: '#475569' }}>
              <div style={{ fontSize: 32, marginBottom: 12 }}>⚙</div>
              <div>로딩 중...</div>
            </div>
          }>
            {activeTab === 'pump'     && <PumpDesign />}
            {activeTab === 'packing'  && <PackingTower />}
            {activeTab === 'pressure' && <PressureDropCalc />}
          </React.Suspense>
        </div>
      )}
    </div>
  );
}
