'use client';

import { useState, useRef, useEffect } from 'react';
import dynamic from 'next/dynamic';

const PFDCanvas = dynamic(() => import('@/components/pfd/PFDCanvas'), {
  ssr: false,
  loading: () => (
    <div style={{
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      width: '100%', height: '100%', gap: 16,
      color: 'var(--text-muted)',
    }}>
      <div style={{
        width: 36, height: 36, borderRadius: '50%',
        border: '3px solid var(--border-default)',
        borderTopColor: 'var(--accent-primary)',
        animation: 'spin 0.8s linear infinite',
      }} />
      <span style={{ fontSize: 12 }}>Loading PFD...</span>
    </div>
  ),
});

const StreamTable     = dynamic(() => import('@/components/StreamTable'),        { ssr: false });

// ── PFD section tabs ──────────────────────────────────────────────────────
type Section = '100' | '200' | '300' | '400' | '600' | 'all';
const PFD_TABS: { id: Section; label: string; color: string }[] = [
  { id: 'all', label: 'All Sections',      color: '#00d4ff' },
  { id: '100', label: '100 Brine',         color: '#4ade80' },
  { id: '200', label: '200 Electrolysis',  color: '#60a5fa' },
  { id: '300', label: '300 NaOH',          color: '#f97316' },
  { id: '400', label: '400 Cl₂',           color: '#60a5fa' },
  { id: '600', label: '600 H₂',            color: '#a78bfa' },
];

// ── Top-level module tabs ────────────────────────────────────────────────────────────
type Module = 'pfd' | 'streams';
const MODULE_TABS: { id: Module; label: string; icon: string; color: string }[] = [
  { id: 'pfd',     label: '공정도 (PFD)',       icon: '🗂',  color: '#00d4ff' },
  { id: 'streams', label: '스트림 데이터표',     icon: '📊',  color: '#4ade80' },
];

// ── Shared tab button ─────────────────────────────────────────────────────
function TabBtn({
  label, color, isActive, onClick,
  icon, dot,
}: {
  label: string; color: string; isActive: boolean;
  onClick: () => void; icon?: string; dot?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        height: 32, padding: '0 14px',
        borderRadius: '6px 6px 0 0',
        border: `1px solid ${isActive ? `${color}44` : 'transparent'}`,
        borderBottom: isActive ? '1px solid var(--bg-base)' : '1px solid transparent',
        background: isActive ? 'var(--bg-base)' : 'transparent',
        color: isActive ? color : 'var(--text-muted)',
        fontSize: 11, fontWeight: 600, cursor: 'pointer',
        display: 'flex', alignItems: 'center', gap: 5,
        transition: 'all 0.15s',
        whiteSpace: 'nowrap',
      }}
    >
      {icon && <span>{icon}</span>}
      {dot && (
        <span style={{
          width: 5, height: 5, borderRadius: '50%',
          background: isActive ? color : 'var(--text-muted)',
          boxShadow: isActive ? `0 0 5px ${color}` : 'none',
          flexShrink: 0,
        }} />
      )}
      {label}
    </button>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────
export default function MaterialBalancePage() {
  const [module, setModule]         = useState<Module>('pfd');
  const [pfdSection, setPfdSection] = useState<Section>('all');
  const pfdRef = useRef<HTMLDivElement>(null);
  const [canvasHeight, setCanvasHeight] = useState(500);

  useEffect(() => {
    if (module !== 'pfd') return;
    const measure = () => {
      if (pfdRef.current) setCanvasHeight(pfdRef.current.clientHeight);
    };
    measure();
    const ro = new ResizeObserver(measure);
    if (pfdRef.current) ro.observe(pfdRef.current);
    return () => ro.disconnect();
  }, [module]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>

      {/* ── Top bar: Module tabs + PFD section tabs ──────────────────────── */}
      <div style={{
        display: 'flex', alignItems: 'flex-end',
        padding: '0 12px',
        background: 'var(--bg-surface)',
        borderBottom: '1px solid var(--border-subtle)',
        flexShrink: 0, minHeight: 40, gap: 2,
      }}>
        {/* Module tabs */}
        {MODULE_TABS.map(t => (
          <TabBtn
            key={t.id} label={t.label} color={t.color} icon={t.icon}
            isActive={module === t.id}
            onClick={() => setModule(t.id)}
          />
        ))}

        {/* Separator */}
        {module === 'pfd' && (
          <>
            <div style={{
              width: 1, height: 20, background: 'rgba(255,255,255,0.1)',
              margin: '0 8px', alignSelf: 'center', flexShrink: 0,
            }} />

            {/* PFD section sub-tabs */}
            {PFD_TABS.map(tab => (
              <TabBtn
                key={tab.id} label={tab.label} color={tab.color} dot
                isActive={pfdSection === tab.id}
                onClick={() => setPfdSection(tab.id)}
              />
            ))}
          </>
        )}

        <div style={{ flex: 1 }} />

        {/* Hint text (PFD only) */}
        {module === 'pfd' && (
          <span style={{
            fontSize: 10, color: 'var(--text-muted)',
            paddingBottom: 6, paddingRight: 4,
            display: 'flex', alignItems: 'center', gap: 6,
          }}>
            <span>Pan: drag</span>
            <span style={{ opacity: 0.4 }}>·</span>
            <span>Zoom: scroll</span>
            <span style={{ opacity: 0.4 }}>·</span>
            <span>Hover stream for details</span>
          </span>
        )}
      </div>

      {/* ── Content area ─────────────────────────────────────────────────── */}
      <div style={{ flex: 1, minHeight: 0, overflow: 'hidden', position: 'relative' }}>

        {/* PFD */}
        {module === 'pfd' && (
          <div
            ref={pfdRef}
            style={{ width: '100%', height: '100%', position: 'relative', overflow: 'hidden' }}
          >
            <PFDCanvas section={pfdSection} canvasHeight={canvasHeight} />
          </div>
        )}

        {/* Stream Table */}
        {module === 'streams' && (
          <div style={{ width: '100%', height: '100%', overflow: 'hidden' }}>
            <StreamTable />
          </div>
        )}

        {/* Design Standards — moved to /equipment-design */}
      </div>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
