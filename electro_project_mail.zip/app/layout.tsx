import type { Metadata } from 'next';
import Header from '@/components/layout/Header';
import Sidebar from '@/components/layout/Sidebar';
import './globals.css';

export const metadata: Metadata = {
  title: '전해공장 머티리얼 발란스 | ClorSim Pro',
  description: '아사히카세이 이온교환막 전해조 기반 염소/가성소다 생산 공정 머티리얼 발란스 시뮬레이터',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ko">
      <body>
        <div className="app-layout">
          <Header />
          <div className="app-body">
            <Sidebar />
            <main className="app-main">
              {children}
            </main>
          </div>
        </div>
      </body>
    </html>
  );
}
