// =====================================================================
// 펌프 설계 계산 엔진 (Pump Design Calculation Engine)
// =====================================================================

import {
  FluidProps, densityAtT, viscosityAtT, vaporPressure_kPa,
  pipeID,
} from './physicalProperties';
import {
  calcPipePressureDrop, PipeSegment, PipeCalcResult,
} from './pipePressureDrop';

// ─────────────────────────────────────────────────────────────────────
// 입력 인터페이스
// ─────────────────────────────────────────────────────────────────────
export interface PumpInputs {
  // ── 유체 ────────────────────────────────────────────────────────
  fluid: FluidProps;
  temperature_C: number;
  /** 유량 (m³/h) */
  flowRate_m3h: number;

  // ── 흡입측 조건 ─────────────────────────────────────────────────
  /** 흡입측 정압 (kPa gauge) */
  P_suction_kPaG: number;
  /** 흡입 액면과 펌프 중심의 높이차 (m), 정압두(흡상)=양수, 부두(압상)=음수 */
  suction_head_m: number;
  /** 흡입 배관 구간들 */
  suctionPipe: PipeSegment[];

  // ── 토출측 조건 ─────────────────────────────────────────────────
  /** 토출측 정압 (kPa gauge) */
  P_discharge_kPaG: number;
  /** 토출 액면과 펌프 중심의 높이차 (m), 양수=상승 */
  discharge_head_m: number;
  /** 토출 배관 구간들 */
  dischargePipe: PipeSegment[];

  // ── 펌프 성능 ────────────────────────────────────────────────────
  /** 펌프 효율 (0~1) */
  pumpEfficiency: number;
  /** 전동기 효율 (0~1) */
  motorEfficiency: number;
  /** 펌프 제조사 NPSH required (m) — 미입력 시 NPSHa만 표시 */
  NPSHr_m?: number;
}

// ─────────────────────────────────────────────────────────────────────
// 결과 인터페이스
// ─────────────────────────────────────────────────────────────────────
export interface PumpResults {
  // ── 유체 물성 ────────────────────────────────────────────────────
  density_kgm3: number;
  viscosity_mPas: number;
  vaporPressure_kPa: number;

  // ── 흡입측 ───────────────────────────────────────────────────────
  suctionPipeCalc: PipeCalcResult;
  /** 흡입 배관 마찰수두 (m) */
  hf_suction_m: number;
  /** 흡입 NPSH available (m) */
  NPSHa_m: number;
  NPSHr_m?: number;
  NPSH_margin_m?: number;
  NPSH_ok?: boolean;

  // ── 토출측 ───────────────────────────────────────────────────────
  dischargePipeCalc: PipeCalcResult;
  /** 토출 배관 마찰수두 (m) */
  hf_discharge_m: number;

  // ── 전양정 ───────────────────────────────────────────────────────
  /** 정적 수두 차 (m) */
  staticHead_m: number;
  /** 마찰수두 합계 (m) */
  frictionHead_m: number;
  /** 압력 수두 차 (m) */
  pressureHead_m: number;
  /** 전양정 TDH (m) */
  TDH_m: number;

  // ── 소요 동력 ────────────────────────────────────────────────────
  /** 수동력 (kW) */
  waterPower_kW: number;
  /** 펌프 축동력 (kW) */
  shaftPower_kW: number;
  /** 전동기 소요 출력 (kW) */
  motorPower_kW: number;
  /** 전동기 선정 출력 (kW) — 표준 모터 사이즈 */
  motorNominal_kW: number;
}

// ─────────────────────────────────────────────────────────────────────
// 표준 전동기 출력 사이즈
// ─────────────────────────────────────────────────────────────────────
const MOTOR_SIZES_kW = [
  0.37, 0.55, 0.75, 1.1, 1.5, 2.2, 3.0, 4.0, 5.5, 7.5,
  11, 15, 18.5, 22, 30, 37, 45, 55, 75, 90, 110, 132, 160, 200, 250, 315,
];

function selectMotorSize(required_kW: number): number {
  // 10% 마진 추가 후 다음 표준 사이즈 선택
  const target = required_kW * 1.10;
  return MOTOR_SIZES_kW.find(s => s >= target) ?? MOTOR_SIZES_kW[MOTOR_SIZES_kW.length - 1];
}

// ─────────────────────────────────────────────────────────────────────
// 펌프 설계 계산 메인 함수
// ─────────────────────────────────────────────────────────────────────
export function calcPump(inputs: PumpInputs): PumpResults {
  const { fluid, temperature_C: T, flowRate_m3h: Q } = inputs;
  const rho  = densityAtT(fluid, T);   // kg/m³
  const mu   = viscosityAtT(fluid, T); // mPa·s
  const Pv   = vaporPressure_kPa(fluid, T);  // kPa abs
  const g    = 9.81;

  // ── 흡입 배관 차압 계산 ──────────────────────────────────────────
  const suctionCalc = calcPipePressureDrop(fluid, T, Q, inputs.suctionPipe);
  const hf_suction  = suctionCalc.dP_total_mH2O;

  // ── 토출 배관 차압 계산 ──────────────────────────────────────────
  const dischargeCalc   = calcPipePressureDrop(fluid, T, Q, inputs.dischargePipe);
  const hf_discharge    = dischargeCalc.dP_total_mH2O;

  // ── NPSHa 계산 ───────────────────────────────────────────────────
  // NPSHa = (P_s_abs - Pv) / (ρg) + Hs - hf_suction
  const P_atm_kPa = 101.325;
  const P_suction_abs = inputs.P_suction_kPaG + P_atm_kPa;  // kPa abs
  const NPSHa = (P_suction_abs - Pv) * 1000 / (rho * g)
                + inputs.suction_head_m
                - Math.abs(hf_suction);  // hf_suction은 항상 손실

  const NPSHr = inputs.NPSHr_m;
  const NPSH_margin  = NPSHr != null ? NPSHa - NPSHr : undefined;
  const NPSH_ok      = NPSHr != null ? NPSH_margin! > 0.5 : undefined; // NEMA: NPSHa > NPSHr + 0.5m

  // ── 전양정 TDH ───────────────────────────────────────────────────
  const P_discharge_abs = inputs.P_discharge_kPaG + P_atm_kPa;
  // 압력 수두 차: (Pd - Ps) / (ρg)
  const pressureHead = (P_discharge_abs - P_suction_abs) * 1000 / (rho * g);
  // 정적 수두 차: 토출 액면 - 흡입 액면
  const staticHead   = inputs.discharge_head_m - inputs.suction_head_m;
  // 마찰 수두 합계 (흡입 + 토출)
  const frictionHead = Math.abs(hf_suction) + Math.abs(hf_discharge);
  const TDH = pressureHead + staticHead + frictionHead;

  // ── 소요 동력 ────────────────────────────────────────────────────
  const Q_m3s      = Q / 3600;
  const waterPower  = rho * g * Q_m3s * TDH / 1000;  // kW
  const shaftPower  = waterPower / inputs.pumpEfficiency;
  const motorPower  = shaftPower / inputs.motorEfficiency;
  const motorNominal = selectMotorSize(motorPower);

  return {
    density_kgm3:     rho,
    viscosity_mPas:   mu,
    vaporPressure_kPa: Pv,

    suctionPipeCalc:  suctionCalc,
    hf_suction_m:     hf_suction,
    NPSHa_m:          NPSHa,
    NPSHr_m:          NPSHr,
    NPSH_margin_m:    NPSH_margin,
    NPSH_ok,

    dischargePipeCalc: dischargeCalc,
    hf_discharge_m:    hf_discharge,

    staticHead_m:      staticHead,
    frictionHead_m:    frictionHead,
    pressureHead_m:    pressureHead,
    TDH_m:             TDH,

    waterPower_kW:    waterPower,
    shaftPower_kW:    shaftPower,
    motorPower_kW:    motorPower,
    motorNominal_kW:  motorNominal,
  };
}
