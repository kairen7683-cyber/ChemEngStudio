'use client';

import { create } from 'zustand';
import { ElectrolyzerInputs } from '@/lib/calculations/electrolyzer';
import { PlantMassBalance, calculatePlantBalance } from '@/lib/calculations/streams';
import { DEFAULT_CONDITIONS } from '@/lib/calculations/constants';

interface BalanceStore {
  inputs: ElectrolyzerInputs;
  balance: PlantMassBalance;
  activeSection: '100' | '200' | '300' | '400' | 'all';
  setInput: (key: keyof ElectrolyzerInputs, value: number) => void;
  setActiveSection: (section: '100' | '200' | '300' | '400' | 'all') => void;
  recalculate: () => void;
}

const defaultInputs: ElectrolyzerInputs = {
  numElectrolyzers: DEFAULT_CONDITIONS.numElectrolyzers,
  cellsPerElectrolyzer: DEFAULT_CONDITIONS.cellsPerElectrolyzer,
  operatingCurrentKA: DEFAULT_CONDITIONS.operatingCurrentKA,
  currentEfficiency: DEFAULT_CONDITIONS.currentEfficiency,
};

export const useBalanceStore = create<BalanceStore>((set, get) => ({
  inputs: defaultInputs,
  balance: calculatePlantBalance(defaultInputs),
  activeSection: 'all',

  setInput: (key, value) => {
    const newInputs = { ...get().inputs, [key]: value };
    set({
      inputs: newInputs,
      balance: calculatePlantBalance(newInputs),
    });
  },

  setActiveSection: (section) => set({ activeSection: section }),

  recalculate: () => {
    set({ balance: calculatePlantBalance(get().inputs) });
  },
}));
