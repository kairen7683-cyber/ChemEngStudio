import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface CustomIconDef {
  viewBox: string;
  svgInner: string;
  width: number;
  height: number;
  label?: string;
}

export interface UserEquipmentNode {
  id: string;       // unique, e.g. 'user_abc123'
  tag: string;      // e.g. 'D-010'
  name: string;     // e.g. 'Brine Saturation'
  type: string;     // 'tank' | 'pump' | 'heatExchanger' | ...
  section: string;  // '100' | '200' | '300' | '400' | '600'
  color?: string;
  position: { x: number; y: number };
}

export interface UserEdgeDef {
  id: string;
  source: string;         // full prefixed node id e.g. 's100_D010'
  target: string;
  sourceHandle?: string | null;
  targetHandle?: string | null;
  streamId?: string;
  color?: string;
  fluidType?: string;     // e.g. 'Brine' | 'Cl2' | 'NaOH' | 'H2' | 'custom' ...
}

interface NodePosition { x: number; y: number; }

interface PFDStore {
  editMode: boolean;
  showCrossEdges: boolean;
  nodePositions: Record<string, NodePosition>;
  customIcons: Record<string, CustomIconDef>;
  edgeStreamMap: Record<string, string>;
  /** 모든 엣지(하드코딩 포함)의 색상 오버라이드 — 리로드 후에도 유지 */
  edgeColorOverrides: Record<string, string>;
  /** 모든 엣지의 유체 종류 — 리로드 후에도 유지 */
  edgeFluidMap: Record<string, string>;
  userNodes: UserEquipmentNode[];
  userEdges: UserEdgeDef[];
  deletedNodeIds: string[];
  deletedEdgeIds: string[];
  nodeTagOverrides: Record<string, { tag: string; name: string }>;

  setEditMode: (v: boolean) => void;
  toggleCrossEdges: () => void;
  saveNodePosition: (id: string, pos: NodePosition) => void;
  saveBatchPositions: (positions: Record<string, NodePosition>) => void;
  setCustomIcon: (type: string, def: CustomIconDef) => void;
  removeCustomIcon: (type: string) => void;
  resetNodePositions: () => void;
  setEdgeStream: (edgeId: string, streamId: string) => void;
  clearEdgeStream: (edgeId: string) => void;
  /** 배관 색상+유체 한꺼번에 저장 (모든 엣지 공통) */
  setEdgeAppearance: (edgeId: string, color: string, fluidType: string) => void;
  addUserNode: (node: UserEquipmentNode) => void;
  removeUserNode: (id: string) => void;
  updateUserNodePosition: (id: string, pos: { x: number; y: number }) => void;
  // Edge editing
  addUserEdge: (edge: UserEdgeDef) => void;
  removeUserEdge: (id: string) => void;
  updateUserEdgeColor: (id: string, color: string) => void;
  // Delete
  markNodeDeleted: (id: string) => void;
  markEdgeDeleted: (id: string) => void;
  restoreNode: (id: string) => void;
  restoreEdge: (id: string) => void;
  // Tag overrides
  setNodeTagOverride: (nodeId: string, tag: string, name: string) => void;
  clearNodeTagOverride: (nodeId: string) => void;
}

export const usePFDStore = create<PFDStore>()(
  persist(
    (set) => ({
      editMode: false,
      showCrossEdges: true,
      nodePositions: {},
      customIcons: {},
      edgeStreamMap: {},
      edgeColorOverrides: {},
      edgeFluidMap: {},
      userNodes: [],
      userEdges: [],
      deletedNodeIds: [],
      deletedEdgeIds: [],
      nodeTagOverrides: {},

      setEditMode: (v) => set({ editMode: v }),
      toggleCrossEdges: () => set(s => ({ showCrossEdges: !s.showCrossEdges })),
      saveNodePosition: (id, pos) => set(s => ({
        nodePositions: { ...s.nodePositions, [id]: pos },
      })),
      saveBatchPositions: (positions) => set(s => ({
        nodePositions: { ...s.nodePositions, ...positions },
      })),
      setCustomIcon: (type, def) => set(s => ({
        customIcons: { ...s.customIcons, [type]: def },
      })),
      removeCustomIcon: (type) => set(s => {
        const next = { ...s.customIcons };
        delete next[type];
        return { customIcons: next };
      }),
      resetNodePositions: () => set({ nodePositions: {} }),
      setEdgeStream: (edgeId, streamId) => set(s => ({
        edgeStreamMap: { ...s.edgeStreamMap, [edgeId]: streamId },
      })),
      clearEdgeStream: (edgeId) => set(s => {
        const next = { ...s.edgeStreamMap };
        delete next[edgeId];
        return { edgeStreamMap: next };
      }),
      setEdgeAppearance: (edgeId, color, fluidType) => set(s => ({
        edgeColorOverrides: { ...s.edgeColorOverrides, [edgeId]: color },
        edgeFluidMap:       { ...s.edgeFluidMap,       [edgeId]: fluidType },
        // userEdge 도 함께 업데이트
        userEdges: s.userEdges.map(e =>
          e.id === edgeId ? { ...e, color, fluidType } : e
        ),
      })),
      addUserNode: (node) => set(s => ({ userNodes: [...s.userNodes, node] })),
      removeUserNode: (id) => set(s => ({ userNodes: s.userNodes.filter(n => n.id !== id) })),
      updateUserNodePosition: (id, pos) => set(s => ({
        userNodes: s.userNodes.map(n => n.id === id ? { ...n, position: pos } : n),
      })),
      addUserEdge: (edge) => set(s => ({ userEdges: [...s.userEdges, edge] })),
      removeUserEdge: (id) => set(s => ({ userEdges: s.userEdges.filter(e => e.id !== id) })),
      updateUserEdgeColor: (id, color) => set(s => ({
        userEdges: s.userEdges.map(e => e.id === id ? { ...e, color } : e),
        edgeColorOverrides: { ...s.edgeColorOverrides, [id]: color },
      })),
      markNodeDeleted: (id) => set(s => ({
        deletedNodeIds: s.deletedNodeIds.includes(id) ? s.deletedNodeIds : [...s.deletedNodeIds, id],
      })),
      markEdgeDeleted: (id) => set(s => ({
        deletedEdgeIds: s.deletedEdgeIds.includes(id) ? s.deletedEdgeIds : [...s.deletedEdgeIds, id],
      })),
      restoreNode: (id) => set(s => ({ deletedNodeIds: s.deletedNodeIds.filter(x => x !== id) })),
      restoreEdge: (id) => set(s => ({ deletedEdgeIds: s.deletedEdgeIds.filter(x => x !== id) })),
      setNodeTagOverride: (nodeId, tag, name) => set(s => ({
        nodeTagOverrides: { ...s.nodeTagOverrides, [nodeId]: { tag, name } },
      })),
      clearNodeTagOverride: (nodeId) => set(s => {
        const next = { ...s.nodeTagOverrides };
        delete next[nodeId];
        return { nodeTagOverrides: next };
      }),
    }),
    { name: 'electro-pfd-layout-v8' }   // v8: edgeColorOverrides + edgeFluidMap 영속화
  )
);

// Equipment type display names (used in IconManager)
export const EQUIPMENT_TYPES = [
  { type: 'electrolyzer', label: '이온교환막 전해조',  defaultW: 100, defaultH: 70 },
  { type: 'tank',         label: '탱크 / 용기',        defaultW: 54,  defaultH: 66 },
  { type: 'pump',         label: '펌프',               defaultW: 36,  defaultH: 36 },
  { type: 'separator',    label: '기액분리기',          defaultW: 44,  defaultH: 76 },
  { type: 'heatExchanger',label: '열교환기',            defaultW: 60,  defaultH: 48 },
  { type: 'tower',        label: '컬럼 / 탑',           defaultW: 38,  defaultH: 90 },
  { type: 'compressor',   label: '압축기',              defaultW: 46,  defaultH: 46 },
  { type: 'filter',       label: '여과기',              defaultW: 52,  defaultH: 60 },
  { type: 'valve',        label: '컨트롤 밸브',          defaultW: 28,  defaultH: 28 },
];
