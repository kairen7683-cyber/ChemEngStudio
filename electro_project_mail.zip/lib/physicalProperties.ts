// =====================================================================
// 전해공장 유체 물성 데이터베이스
// Chlor-Alkali Plant Physical Properties Database
// =====================================================================

export interface FluidProps {
  key: string;
  name: string;
  nameKo: string;
  /** 기준 온도 (°C) */
  T_ref: number;
  /** 밀도 (kg/m³) at T_ref */
  density_ref: number;
  /** 동점도 (mPa·s = cP) at T_ref */
  viscosity_ref: number;
  /** 비열 (kJ/kg·K) */
  Cp: number;
  /** 열전도도 (W/m·K) */
  k_thermal?: number;
  /** 증기압 (kPa) at T_ref */
  vaporPressure_ref?: number;
  /** 증기압 Antoine 계수 (log10 Pv = A - B/(C+T), Pv in kPa, T in °C) */
  antoine?: { A: number; B: number; C: number };
  /** 밀도 온도 계수 (kg/m³/°C, 선형 근사) */
  dRho_dT?: number;
  /** 점도 온도 계수 (mPa·s/°C, 선형 근사) */
  dMu_dT?: number;
  phase: 'L' | 'G';
  /** 분자량 (기체용) */
  MW?: number;
  /** 표면장력 (mN/m) at T_ref - 타워 설계용 */
  surfaceTension?: number;
}

// ─────────────────────────────────────────────────────────────────────
// 온도 보정 함수
// ─────────────────────────────────────────────────────────────────────

/** 밀도 온도 보정 (선형 근사) */
export function densityAtT(fluid: FluidProps, T_C: number): number {
  const dRho = fluid.dRho_dT ?? -0.5;
  return fluid.density_ref + dRho * (T_C - fluid.T_ref);
}

/** 점도 온도 보정 (Andrade 방정식 근사: μ = μ_ref × exp(A×(1/T - 1/T_ref))) */
export function viscosityAtT(fluid: FluidProps, T_C: number): number {
  if (fluid.phase === 'G') {
    // 기체: Sutherland 근사 — 온도 상승 시 점도 증가
    const T_K = T_C + 273.15;
    const T0_K = fluid.T_ref + 273.15;
    return fluid.viscosity_ref * Math.pow(T_K / T0_K, 0.7);
  }
  const dMu = fluid.dMu_dT ?? -0.02;
  const mu = fluid.viscosity_ref + dMu * (T_C - fluid.T_ref);
  return Math.max(0.1, mu);  // 최솟값 보정
}

/** Antoine 방정식으로 증기압 계산 (kPa) */
export function vaporPressure_kPa(fluid: FluidProps, T_C: number): number {
  if (!fluid.antoine) return fluid.vaporPressure_ref ?? 0;
  const { A, B, C } = fluid.antoine;
  return Math.pow(10, A - B / (C + T_C));
}

// ─────────────────────────────────────────────────────────────────────
// 전해공장 유체 물성 데이터
// ─────────────────────────────────────────────────────────────────────

export const FLUID_DB: Record<string, FluidProps> = {
  // ── 액상 ──────────────────────────────────────────────────────────
  brine_25: {
    key: 'brine_25',
    name: 'NaCl brine 25wt%',
    nameKo: '포화브라인 (25%)',
    T_ref: 25, density_ref: 1172, viscosity_ref: 1.80,
    Cp: 3.47, k_thermal: 0.59,
    vaporPressure_ref: 2.8,   // kPa (vapor pressure slightly depressed by NaCl)
    antoine: { A: 8.071, B: 1730.6, C: 233.4 },  // approximate
    dRho_dT: -0.45, dMu_dT: -0.025,
    phase: 'L', surfaceTension: 72.5,
  },
  brine_15: {  // 약 15 wt% NaCl — 포화조 출구, 희박 브라인
    key: 'brine_15',
    name: 'NaCl brine 15wt%',
    nameKo: '희박브라인 (15%)',
    T_ref: 70, density_ref: 1085, viscosity_ref: 0.60,
    Cp: 3.78, k_thermal: 0.62,
    vaporPressure_ref: 31.0,
    dRho_dT: -0.40, dMu_dT: -0.012,
    phase: 'L', surfaceTension: 71.0,
  },
  brine_fed: {  // refined brine to electrolyzer ~26% at 60-70°C
    key: 'brine_fed',
    name: 'Refined brine 26wt%',
    nameKo: '정제브라인 (26%)',
    T_ref: 65, density_ref: 1168, viscosity_ref: 0.90,
    Cp: 3.40, k_thermal: 0.57,
    vaporPressure_ref: 25.0,
    dRho_dT: -0.45, dMu_dT: -0.015,
    phase: 'L', surfaceTension: 70.0,
  },
  naoh_32: {
    key: 'naoh_32',
    name: 'NaOH 32wt%',
    nameKo: '가성소다 32%',
    T_ref: 25, density_ref: 1340, viscosity_ref: 3.50,
    Cp: 3.14, k_thermal: 0.54,
    vaporPressure_ref: 1.8,
    dRho_dT: -0.70, dMu_dT: -0.08,
    phase: 'L', surfaceTension: 68.0,
  },
  naoh_50: {
    key: 'naoh_50',
    name: 'NaOH 50wt%',
    nameKo: '가성소다 50%',
    T_ref: 25, density_ref: 1525, viscosity_ref: 36.0,
    Cp: 2.79, k_thermal: 0.48,
    vaporPressure_ref: 0.4,
    dRho_dT: -0.90, dMu_dT: -0.80,
    phase: 'L', surfaceTension: 65.0,
  },
  h2so4_98: {
    key: 'h2so4_98',
    name: 'H2SO4 98wt%',
    nameKo: '황산 98%',
    T_ref: 25, density_ref: 1836, viscosity_ref: 26.7,
    Cp: 1.42, k_thermal: 0.35,
    vaporPressure_ref: 0.03,
    dRho_dT: -1.10, dMu_dT: -0.55,
    phase: 'L', surfaceTension: 55.0,
  },
  hcl_31: {
    key: 'hcl_31',
    name: 'HCl 31wt%',
    nameKo: '염산 31%',
    T_ref: 25, density_ref: 1152, viscosity_ref: 1.90,
    Cp: 2.55, k_thermal: 0.45,
    vaporPressure_ref: 8.5,
    dRho_dT: -0.45, dMu_dT: -0.03,
    phase: 'L', surfaceTension: 65.0,
  },
  process_water: {
    key: 'process_water',
    name: 'Process water',
    nameKo: '공정수',
    T_ref: 25, density_ref: 997, viscosity_ref: 0.89,
    Cp: 4.18, k_thermal: 0.61,
    vaporPressure_ref: 3.17,
    antoine: { A: 8.0700, B: 1730.6, C: 233.4 },
    dRho_dT: -0.33, dMu_dT: -0.020,
    phase: 'L', surfaceTension: 72.0,
  },
  cooling_water: {
    key: 'cooling_water',
    name: 'Cooling water',
    nameKo: '냉각수',
    T_ref: 30, density_ref: 995, viscosity_ref: 0.80,
    Cp: 4.18, k_thermal: 0.61,
    vaporPressure_ref: 4.24,
    dRho_dT: -0.33, dMu_dT: -0.018,
    phase: 'L', surfaceTension: 71.0,
  },
  catholyte: {   // catholyte out: dilute NaOH ~33% at 87-90°C
    key: 'catholyte',
    name: 'Catholyte (33% NaOH)',
    nameKo: '음극액 (33% NaOH)',
    T_ref: 87, density_ref: 1290, viscosity_ref: 1.20,
    Cp: 3.10, k_thermal: 0.50,
    vaporPressure_ref: 60.0,
    dRho_dT: -0.65, dMu_dT: -0.03,
    phase: 'L', surfaceTension: 60.0,
  },
  anolyte: {     // anolyte: depleted brine ~16% NaCl at 87°C
    key: 'anolyte',
    name: 'Anolyte (depleted brine)',
    nameKo: '양극액 (탈염 브라인)',
    T_ref: 87, density_ref: 1089, viscosity_ref: 0.65,
    Cp: 3.80, k_thermal: 0.60,
    vaporPressure_ref: 55.0,
    dRho_dT: -0.40, dMu_dT: -0.012,
    phase: 'L', surfaceTension: 68.0,
  },
  // ── 기상 ──────────────────────────────────────────────────────────
  cl2_gas: {
    key: 'cl2_gas',
    name: 'Cl2 gas',
    nameKo: '염소 가스',
    T_ref: 25, density_ref: 2.90, viscosity_ref: 0.0134,  // mPa·s
    Cp: 0.48, k_thermal: 0.0090, MW: 70.9,
    phase: 'G',
  },
  h2_gas: {
    key: 'h2_gas',
    name: 'H2 gas',
    nameKo: '수소 가스',
    T_ref: 25, density_ref: 0.082, viscosity_ref: 0.0089,
    Cp: 14.32, k_thermal: 0.182, MW: 2.016,
    phase: 'G',
  },
  n2_gas: {
    key: 'n2_gas',
    name: 'N2 gas',
    nameKo: '질소 가스',
    T_ref: 25, density_ref: 1.145, viscosity_ref: 0.0178,
    Cp: 1.04, k_thermal: 0.026, MW: 28.01,
    phase: 'G',
  },
  air: {
    key: 'air',
    name: 'Air',
    nameKo: '공기',
    T_ref: 25, density_ref: 1.184, viscosity_ref: 0.0185,
    Cp: 1.005, k_thermal: 0.026, MW: 28.97,
    phase: 'G',
  },
};

/** 유체 키 → 물성 조회 (없으면 process_water fallback) */
export function getFluidProps(key: string): FluidProps {
  return FLUID_DB[key] ?? FLUID_DB['process_water'];
}

/** 모든 액상 유체 목록 */
export const LIQUID_FLUIDS = Object.values(FLUID_DB).filter(f => f.phase === 'L');
/** 모든 기상 유체 목록 */
export const GAS_FLUIDS = Object.values(FLUID_DB).filter(f => f.phase === 'G');
/** 전체 유체 목록 */
export const ALL_FLUIDS = Object.values(FLUID_DB);

// ─────────────────────────────────────────────────────────────────────
// 이상기체 밀도 계산
// ─────────────────────────────────────────────────────────────────────
export function gasDensity(MW: number, T_C: number, P_kPa: number): number {
  const R = 8314;  // J/kmol·K
  const T_K = T_C + 273.15;
  return (P_kPa * 1000 * MW) / (R * T_K);  // kg/m³
}

// ─────────────────────────────────────────────────────────────────────
// 배관 재질 조도 (Roughness)
// ─────────────────────────────────────────────────────────────────────
export interface PipeMaterial {
  key: string;
  name: string;
  roughness_mm: number;  // absolute roughness ε in mm
}

export const PIPE_MATERIALS: PipeMaterial[] = [
  { key: 'ss316l',    name: 'SS 316L (스테인리스)',   roughness_mm: 0.046 },
  { key: 'ss304',     name: 'SS 304 (스테인리스)',    roughness_mm: 0.046 },
  { key: 'cs',        name: 'Carbon Steel (탄소강)',  roughness_mm: 0.046 },
  { key: 'cs_rust',   name: 'Carbon Steel (녹)',      roughness_mm: 0.20  },
  { key: 'pvc',       name: 'PVC / PP',               roughness_mm: 0.0015 },
  { key: 'frp',       name: 'FRP / GFRP',             roughness_mm: 0.005 },
  { key: 'titanium',  name: 'Titanium',               roughness_mm: 0.046 },
  { key: 'custom',    name: '직접 입력',              roughness_mm: 0.046 },
];

// ─────────────────────────────────────────────────────────────────────
// 배관 호칭 직경 (Nominal Pipe Size) 표준 데이터
// ─────────────────────────────────────────────────────────────────────
export interface PipeSize {
  DN: number;        // mm
  NPS: string;       // inch 표기
  OD_mm: number;     // 외경
  schedule: Record<string, number>;  // 스케줄 → 두께(mm)
}

export const PIPE_SIZES: PipeSize[] = [
  { DN: 15,  NPS: '1/2"',  OD_mm: 21.3,  schedule: { '40S': 2.77, '80S': 3.73 } },
  { DN: 20,  NPS: '3/4"',  OD_mm: 26.7,  schedule: { '40S': 2.87, '80S': 3.91 } },
  { DN: 25,  NPS: '1"',    OD_mm: 33.4,  schedule: { '40S': 3.38, '80S': 4.55 } },
  { DN: 32,  NPS: '1-1/4"',OD_mm: 42.2,  schedule: { '40S': 3.56, '80S': 4.85 } },
  { DN: 40,  NPS: '1-1/2"',OD_mm: 48.3,  schedule: { '40S': 3.68, '80S': 5.08 } },
  { DN: 50,  NPS: '2"',    OD_mm: 60.3,  schedule: { '40S': 3.91, '80S': 5.54 } },
  { DN: 65,  NPS: '2-1/2"',OD_mm: 73.0,  schedule: { '40S': 5.16, '80S': 7.01 } },
  { DN: 80,  NPS: '3"',    OD_mm: 88.9,  schedule: { '40S': 5.49, '80S': 7.62 } },
  { DN: 100, NPS: '4"',    OD_mm: 114.3, schedule: { '40S': 6.02, '80S': 8.56 } },
  { DN: 125, NPS: '5"',    OD_mm: 141.3, schedule: { '40S': 6.55, '80S': 9.52 } },
  { DN: 150, NPS: '6"',    OD_mm: 168.3, schedule: { '40S': 7.11, '80S': 10.97 } },
  { DN: 200, NPS: '8"',    OD_mm: 219.1, schedule: { '40S': 8.18, '80S': 12.70 } },
  { DN: 250, NPS: '10"',   OD_mm: 273.1, schedule: { '40S': 9.27, '80S': 15.09 } },
  { DN: 300, NPS: '12"',   OD_mm: 323.9, schedule: { '40S': 9.52, '80S': 17.48 } },
  { DN: 350, NPS: '14"',   OD_mm: 355.6, schedule: { '40S': 9.52, '80S': 19.05 } },
  { DN: 400, NPS: '16"',   OD_mm: 406.4, schedule: { '40S': 9.52, '80S': 21.44 } },
];

/** ID (내경) 계산 */
export function pipeID(DN: number, sched = '40S'): number {
  const ps = PIPE_SIZES.find(p => p.DN === DN);
  if (!ps) return DN * 0.9;  // 근사
  const t = ps.schedule[sched] ?? ps.schedule['40S'] ?? 3.5;
  return ps.OD_mm - 2 * t;
}
