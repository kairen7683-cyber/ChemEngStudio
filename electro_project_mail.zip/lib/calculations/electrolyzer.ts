// ============================================================
// 전해조 핵심 계산 엔진
// Electrolyzer Core Calculation Engine
// 엑셀: "Brine Flow Calc" 시트 수식 기반
// ============================================================

import { FARADAY, MW, DEFAULT_CONDITIONS } from './constants';

export interface ElectrolyzerInputs {
  numElectrolyzers: number;       // 전해조 수량 (기)
  cellsPerElectrolyzer: number;   // 셀수/전해조
  operatingCurrentKA: number;     // 운전전류 (kA)
  currentEfficiency: number;      // 전류효율 (0~1)
}

export interface ElectrolyzerOutputs {
  // 생산량
  cl2ProductionKgH: number;       // Cl2 생산량 (kg/h)
  cl2ProductionTonD: number;      // Cl2 생산량 (ton/일)
  naohProductionKgH: number;      // NaOH 생산량 (kg/h) — 100% 기준
  h2ProductionKgH: number;        // H2 생산량 (kg/h)
  
  // 전류
  totalCurrentA: number;          // 총 전류 (A)
  totalCellCount: number;         // 총 셀수 (PCS)
  
  // 소모량
  naclConsumptionKgH: number;     // NaCl 소모량 (이론, kg/h)
  waterToMembraneKgH: number;     // 막 통과 수분 이동량 (kg/h) — 엑셀 원본값
  
  // 효율/전력
  theoreticalCurrentEfficiency: number;
}

/**
 * 패러데이 법칙 기반 전해조 계산
 * 엑셀 "Brine Flow Calc" 시트의 핵심 수식 재현
 *
 * Cl2:  n=2, Cl2 생산 = I × N_cell × η × M_Cl2 / (2F × 1000) [kg/h]
 * NaOH: n=1, NaOH 생산 = I × N_cell × η × M_NaOH / (F × 1000)  [kg/h]
 * H2:   n=2, H2 생산  = I × N_cell × η × M_H2 / (2F × 1000)   [kg/h]
 */
export function calculateElectrolyzer(inputs: ElectrolyzerInputs): ElectrolyzerOutputs {
  const { numElectrolyzers, cellsPerElectrolyzer, operatingCurrentKA, currentEfficiency } = inputs;
  
  const I_A = operatingCurrentKA * 1000;           // kA → A
  const N_total = numElectrolyzers * cellsPerElectrolyzer; // 총 셀수
  
  // 단위: A × PCS × (무차원) × g/mol / (C/mol) = g/s → × 3600 / 1000 = kg/h
  const base = I_A * N_total * currentEfficiency / FARADAY * 3600 / 1000;
  
  const cl2KgH  = base * MW.Cl2  / 2;  // Cl2:  n=2 (2e⁻ per Cl₂ mol)
  const naohKgH = base * MW.NaOH;      // NaOH: n=1 (1e⁻ per NaOH mol)
                                         //   음극: 2H₂O+2e⁻→H₂+2OH⁻, 2Na⁺→막 통과→2NaOH
                                         //   ∴ 전자 1개당 NaOH 1몰 생성 (n=1)
                                         //   이론 질량비 NaOH/Cl₂ = 39.98/35.45 = 1.128 (≈1.1배) ✓
  const h2KgH   = base * MW.H2   / 2;  // H2:   n=2 (2e⁻ per H₂ mol)

  // NaCl 소모량: 2NaCl → Cl₂ → NaCl/Cl₂ 몰비=2, 이론 소모량
  const naclKgH = cl2KgH * 2 * MW.NaCl / MW.Cl2;  // = base × MW.NaCl (동일)
  
  // 막 통과 수분: 엑셀 원본 수식 재현
  // 이동량(kg/h) = Cell No. × KA × 효율 × 계수
  // 엑셀 원본: 190셀 × 16.2KA × 0.94 → 8158.8 kg/h
  // 계수 역산: 8158.8 / (190 × 16.2 × 0.94) = 2.824
  const MEMBRANE_WATER_FACTOR = 8158.815201599999 / (190 * 16.2 * 0.94);
  const waterToMembraneKgH = N_total * operatingCurrentKA * currentEfficiency * MEMBRANE_WATER_FACTOR;
  
  return {
    cl2ProductionKgH: cl2KgH,
    cl2ProductionTonD: cl2KgH * 24 / 1000,
    naohProductionKgH: naohKgH,
    h2ProductionKgH: h2KgH,
    totalCurrentA: I_A,
    totalCellCount: N_total,
    naclConsumptionKgH: naclKgH,
    waterToMembraneKgH,
    theoreticalCurrentEfficiency: currentEfficiency,
  };
}

export const defaultInputs: ElectrolyzerInputs = { ...DEFAULT_CONDITIONS };
