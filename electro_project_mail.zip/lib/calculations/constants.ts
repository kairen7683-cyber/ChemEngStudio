// ============================================================
// 염소-알칼리 전해 공정 물성 상수
// Chlor-Alkali Process Physical Constants
// ============================================================

export const FARADAY = 96485; // C/mol (패러데이 상수)

// 분자량 (g/mol)
export const MW = {
  Cl2: 70.9,
  NaOH: 39.98,
  H2: 2.016,
  NaCl: 58.44,
  H2O: 18.015,
  HCl: 36.46,
  O2: 32.0,
  H2SO4: 98.08,
};

// 표준 운전 조건 (엑셀 원본 기준)
export const DEFAULT_CONDITIONS = {
  numElectrolyzers: 5,          // 전해조 수량 (기)
  cellsPerElectrolyzer: 190,    // 셀수/전해조
  operatingCurrentKA: 16.2,     // 운전전류 (kA)
  currentEfficiency: 0.94,      // 전류효율 (94%)
  // 엑셀 원본: Cl2 468 ton/일 @ 5기 × 190셀 × 16.2kA × 94%
};

// 브라인 조건
export const BRINE = {
  feedConcentration_wt: 25.6,   // 피드 NaCl 농도 (wt%)
  feedDensity: 1172,            // kg/m³
  feedTemp: 60,                 // ℃
  anolyteDepleted_wt: 17.45,   // 양극액 출구 NaCl 농도 (wt%)
  anolyteDensity: 1093,         // kg/m³
  anolyteTemp: 90,              // ℃
};

// NaOH 조건
export const NAOH = {
  catholyteConc_wt: 32.3,      // 음극액 NaOH 농도 (wt%) — 제품
  density32: 1304,              // kg/m³ @ 32%
  density50: 1524,              // kg/m³ @ 50%
  temp: 90,                     // ℃
  evapConc50_wt: 50.0,         // 증발농축 후 50% NaOH
};

// Cl2 조건
export const CL2 = {
  anodeTemp: 87,               // 양극 출구 온도 (℃)
  anodePressure: 0.4,          // 양극 압력 (kg/cm².G)
  purity: 99.9,                // % (건조 후)
  liquidTemp: -22,             // ℃ (액화 후)
  liquidPressure: 3.0,         // kg/cm².G
};

// H2 조건
export const H2_COND = {
  cathodeTemp: 90,             // 음극 출구 온도 (℃)
  cathodePressure: 0.45,       // 음극 압력 (kg/cm².G)
};

// 스트림 번호 정의 (엑셀 원본 매핑)
export const STREAM_NUMBERS = {
  // 100 Sec (브라인 정제)
  s001: '001',  // 브라인 피드 (FCV-080)
  s002: '002',  // 
  s004: '004',  // 
  s013: '013',  // 
  s017: '017',  // 
  s022: '022',  // 
  s102: '102',  // 브라인 필터 출구
  s104: '104',  // 브라인 전해 피드
  s105: '105',  // BaCl2
  // 200 Sec (전해조)
  s201: '201',  // 전해조 브라인 피드
  s202: '202',  // 양극액 출구 (묽은 NaCl)
  s203: '203',  // Cl2 가스 (양극)
  s204: '204',  // HCl (피드)
  s208: '208',  // 음극액 피드 (희박 NaOH)
  s209: '209',  // SPW
  s211: '211',  // NaOH 음극액 출구
  s212: '212',  // H2 가스
  s213: '213',  // NaOH (희박액)
  s217: '217',  // NaOH 제품
  s218: '218',  // 양극액 (농축)
  s219: '219',  // NaOH 19%
  s220: '220',  // Cl2 헤더
  s221: '221',  // H2 헤더
  s224: '224',  // 탈염소 브라인 (묽은 NaCl)
  s250: '250',  // 브라인 반환
  s256: '256',  // 브라인 반환
  s259: '259',  // 
  // 300 Sec (NaOH 농축)
  // 400 Sec (Cl2 처리/액화)
  s401: '401',  // Cl2 가스 (습)
  s402: '402',  // Cl2 세정수
  s403: '403',  // Cl2 (건조 후)
};
