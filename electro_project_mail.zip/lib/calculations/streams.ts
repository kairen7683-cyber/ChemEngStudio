// ============================================================
// 전공장 스트림 계산 (100~600 Sec 전체)
// 엑셀 원본: MB-2012 CA NO.3_468TON_R1.XLS
// ============================================================
import { ElectrolyzerInputs, ElectrolyzerOutputs, calculateElectrolyzer } from './electrolyzer';
import { FLUID_DB, densityAtT, gasDensity } from '../physicalProperties';

// ──────────────────────────────────────────────────────────────────────
// 스트림 → DB 유체키 매핑 및 밀도 자동 계산 헬퍼
// 온도 보정이 의미 있는 스트림만 DB 연동, 혼합 기체/비선형 구간은 엑셀 고정값 유지
// ──────────────────────────────────────────────────────────────────────

/** DB에서 온도 보정한 밀도를 반환. key가 없거나 기체 혼합이면 fallback 사용 */
function dbDensity(fluidKey: string, T_C: number, fallback: number): number {
  const fluid = FLUID_DB[fluidKey];
  if (!fluid) return fallback;
  if (fluid.phase === 'G' && fluid.MW) {
    // 기체: 이상기체 계산 (P는 별도 지정 없으면 1 atm 기준)
    // 기체 스트림은 대부분 엑셀 고정값이 더 정확하므로 fallback 우선
    return fallback;
  }
  const calc = densityAtT(fluid, T_C);
  return calc;
}

export interface StreamData {
  id: string;
  name: string;
  section: '100' | '200' | '300' | '400' | '600';
  components: {
    NaCl?: number; H2O?: number; NaOH?: number; Cl2?: number;
    H2?: number;  HCl?: number; O2?: number;  H2SO4?: number;
    BaCl2?: number; Na2SO3?: number;
  };
  total_kgh: number;
  concentration?: number; // wt% of main component
  pressure_kgcm2g?: number;
  temperature_C?: number;
  /** DB 연동 밀도 (온도 보정, kg/m³) — 기체/비선형 구간은 엑셀 고정값 유지 */
  density_kgm3?: number;
  /** physicalProperties.ts DB 키 — 장치설계 계산에서 유체 선택 자동화에 사용 */
  fluidKey?: string;
  phase?: 'L' | 'G' | 'L/G';
  description?: string;
}

export interface PlantMassBalance {
  electrolyzerResult: ElectrolyzerOutputs;
  streams: StreamData[];
  summary: {
    cl2_tonDay: number; naoh32_tonDay: number; naoh50_tonDay: number;
    h2_tonDay: number;  naclUsage_tonDay: number; saltUsage_tonDay: number;
  };
}

// 엑셀 기준 Cl2 생산량 (5기 × 190셀 × 16.2kA × 94% CE)
const BASE_CL2_KGH = 19487.5;

export function calculatePlantBalance(inputs: ElectrolyzerInputs): PlantMassBalance {
  const elec = calculateElectrolyzer(inputs);
  const streams: StreamData[] = [];
  const sf = elec.cl2ProductionKgH / BASE_CL2_KGH; // 스케일 팩터

  // ──────────────────────────────────────────────────────────
  // 100 SEC — 브라인 정제 (Brine Purification)
  // ──────────────────────────────────────────────────────────
  const s001_NaCl = 29733.08 * sf, s001_H2O = 177009.50 * sf;
  streams.push({ id: '001', name: '포화 브라인 피드', section: '100',
    components: { NaCl: s001_NaCl, H2O: s001_H2O },
    total_kgh: s001_NaCl + s001_H2O,
    concentration: s001_NaCl / (s001_NaCl + s001_H2O) * 100,
    pressure_kgcm2g: 3.0, temperature_C: 73, density_kgm3: dbDensity('brine_15', 73, 1078),
    fluidKey: 'brine_15', phase: 'L',
    description: 'FCV-080 포화브라인 피드 (솔트디졸버 출구)'
  });

  const s002_NaCl = 2325.52 * sf, s002_H2O = 13844.48 * sf;
  streams.push({ id: '002', name: '브라인 반응탱크 피드', section: '100',
    components: { NaCl: s002_NaCl, H2O: s002_H2O },
    total_kgh: s002_NaCl + s002_H2O,
    concentration: s002_NaCl / (s002_NaCl + s002_H2O) * 100,
    pressure_kgcm2g: 3.0, temperature_C: 73, density_kgm3: dbDensity('brine_15', 73, 1110),
    fluidKey: 'brine_15', phase: 'L',
    description: 'D-010 반응탱크 입구'
  });

  const s004_NaCl = 61857.20 * sf, s004_H2O = 177009.50 * sf;
  streams.push({ id: '004', name: '반응탱크 출구 브라인', section: '100',
    components: { NaCl: s004_NaCl, H2O: s004_H2O },
    total_kgh: s004_NaCl + s004_H2O,
    concentration: s004_NaCl / (s004_NaCl + s004_H2O) * 100,
    pressure_kgcm2g: 3.8, temperature_C: 70, density_kgm3: dbDensity('brine_25', 70, 1165),
    fluidKey: 'brine_25', phase: 'L',
    description: 'D-010A/B 출구 → 가압 여과기 D-013'
  });

  const s013_NaCl = 61857.20 * sf, s013_H2O = 177009.50 * sf;
  streams.push({ id: '013', name: '여과기 출구 브라인', section: '100',
    components: { NaCl: s013_NaCl, H2O: s013_H2O },
    total_kgh: s013_NaCl + s013_H2O,
    concentration: 25.9,
    pressure_kgcm2g: 3.8, temperature_C: 70, density_kgm3: dbDensity('brine_25', 70, 1165),
    fluidKey: 'brine_25', phase: 'L',
    description: 'D-013 가압여과기 출구 → 이온교환탑'
  });

  streams.push({ id: '017', name: 'BaCl₂ 약품 투입', section: '100',
    components: { BaCl2: 117.0 * sf },
    total_kgh: 117.0 * sf,
    pressure_kgcm2g: 5.0, temperature_C: 25, density_kgm3: 1300, phase: 'L',
    description: 'BaCl₂ 약품 킱크 → D-010 (황산이온 제거)'
  });

  const s022_NaCl = 61857.20 * sf, s022_H2O = 177009.50 * sf;
  streams.push({ id: '022', name: '이온교환탑 출구', section: '100',
    components: { NaCl: s022_NaCl, H2O: s022_H2O },
    total_kgh: s022_NaCl + s022_H2O,
    concentration: 25.9,
    pressure_kgcm2g: 3.5, temperature_C: 60, density_kgm3: dbDensity('brine_25', 60, 1170),
    fluidKey: 'brine_25', phase: 'L',
    description: 'F-050 이온교환탑 출구 (Ca²⁺, Mg²⁺ < 0.02 ppm)'
  });

  const s102_NaCl = 61857.20 * sf, s102_H2O = 177009.50 * sf;
  streams.push({ id: '102', name: '정제 브라인 (여과 후)', section: '100',
    components: { NaCl: s102_NaCl, H2O: s102_H2O },
    total_kgh: s102_NaCl + s102_H2O,
    concentration: 25.9,
    pressure_kgcm2g: 2.0, temperature_C: 60, density_kgm3: dbDensity('brine_25', 60, 1170),
    fluidKey: 'brine_25', phase: 'L',
    description: '정밀여과 후 정제 브라인'
  });

  const s104_NaCl = 61857.20 * sf, s104_H2O = 177009.50 * sf;
  streams.push({ id: '104', name: '정제 브라인 (전해 피드)', section: '100',
    components: { NaCl: s104_NaCl, H2O: s104_H2O },
    total_kgh: s104_NaCl + s104_H2O,
    concentration: s104_NaCl / (s104_NaCl + s104_H2O) * 100,
    pressure_kgcm2g: 4.0, temperature_C: 60, density_kgm3: dbDensity('brine_fed', 60, 1172),
    fluidKey: 'brine_fed', phase: 'L',
    description: 'P-064A/B 출구 → 200 Sec 전해조 피드'
  });

  streams.push({ id: '105', name: 'NaOH 약품 투입 (pH 조정)', section: '100',
    components: { NaOH: 117.0 * sf },
    total_kgh: 117.0 * sf,
    pressure_kgcm2g: 5.0, temperature_C: 25, density_kgm3: dbDensity('naoh_32', 25, 1300),
    fluidKey: 'naoh_32', phase: 'L',
    description: 'F-050 이온교환탑 pH 조정용 NaOH'
  });

  // ──────────────────────────────────────────────────────────
  // 200 SEC — 전해조 (Electrolysis)
  // ──────────────────────────────────────────────────────────
  const s201_NaCl = 13334.56 * sf, s201_H2O = 40838.70 * sf;
  streams.push({ id: '201', name: '전해조 브라인 피드 (1기당)', section: '200',
    components: { NaCl: s201_NaCl, H2O: s201_H2O },
    total_kgh: s201_NaCl + s201_H2O,
    concentration: s201_NaCl / (s201_NaCl + s201_H2O) * 100,
    pressure_kgcm2g: 4.0, temperature_C: 65, density_kgm3: dbDensity('brine_fed', 65, 1159),
    fluidKey: 'brine_fed', phase: 'L',
    description: '전해조 양극 피드 (순환 브라인 포함)'
  });

  const s202_NaCl = 6909.74 * sf, s202_H2O = 32679.89 * sf, s202_Cl2 = 118.18 * sf;
  streams.push({ id: '202', name: '양극액 출구 (묽은 브라인+Cl₂)', section: '200',
    components: { NaCl: s202_NaCl, H2O: s202_H2O, Cl2: s202_Cl2 },
    total_kgh: s202_NaCl + s202_H2O + s202_Cl2,
    concentration: s202_NaCl / (s202_NaCl + s202_H2O) * 100,
    pressure_kgcm2g: 0.5, temperature_C: 87, density_kgm3: dbDensity('anolyte', 87, 1089),
    fluidKey: 'anolyte', phase: 'L/G',
    description: '전해조 양극액 출구 → D-210A 기액분리기'
  });

  const s202a_NaCl = 34548.68 * sf, s202a_H2O = 163399.43 * sf;
  streams.push({ id: '202a', name: '양극액 순환 (묽은 브라인)', section: '200',
    components: { NaCl: s202a_NaCl, H2O: s202a_H2O },
    total_kgh: s202a_NaCl + s202a_H2O,
    concentration: s202a_NaCl / (s202a_NaCl + s202a_H2O) * 100,
    pressure_kgcm2g: 0.4, temperature_C: 90, density_kgm3: dbDensity('anolyte', 90, 1089),
    fluidKey: 'anolyte', phase: 'L',
    description: 'D-210A 분리기 액상 출구 (탈염소 공정으로)'
  });

  const s203_Cl2 = 3900.0 * sf, s203_H2O = 793.98 * sf, s203_HCl = 80.85 * sf;
  streams.push({ id: '203', name: 'Cl₂ 가스 (양극, 1기)', section: '200',
    components: { Cl2: s203_Cl2, H2O: s203_H2O, HCl: s203_HCl },
    total_kgh: s203_Cl2 + s203_H2O + s203_HCl,
    concentration: s203_Cl2 / (s203_Cl2 + s203_H2O + s203_HCl) * 100,
    pressure_kgcm2g: 0.4, temperature_C: 87, density_kgm3: dbDensity('cl2_gas', 87, 2.07),
    fluidKey: 'cl2_gas', phase: 'G',
    description: '전해조 1기 Cl₂ 가스 출구 → [220] 헤더'
  });

  streams.push({ id: '204', name: 'HCl 피드 (pH 조정)', section: '200',
    components: { HCl: 80.85 * sf, H2O: 150.15 * sf },
    total_kgh: 231.0 * sf,
    concentration: 35.0,
    pressure_kgcm2g: 4.0, temperature_C: 30, density_kgm3: dbDensity('hcl_31', 30, 1153),
    fluidKey: 'hcl_31', phase: 'L',
    description: 'HCl 30% 용액 → 양극액 pH 조정'
  });

  const s208_NaCl = 5766.30 * sf, s208_H2O = 27184.00 * sf;
  streams.push({ id: '208', name: '음극액 피드 (희박 NaOH)', section: '200',
    components: { NaCl: s208_NaCl, H2O: s208_H2O },
    total_kgh: s208_NaCl + s208_H2O,
    concentration: 17.5,
    pressure_kgcm2g: 3.5, temperature_C: 87, density_kgm3: dbDensity('anolyte', 87, 1089),
    fluidKey: 'anolyte', phase: 'L',
    description: '전해조 음극 피드 (순환 NaOH 희석)'
  });

  streams.push({ id: '209', name: 'SPW (연수 피드)', section: '200',
    components: { H2O: 3234.0 * sf },
    total_kgh: 3234.0 * sf,
    concentration: 100,
    pressure_kgcm2g: 4.0, temperature_C: 25, density_kgm3: dbDensity('process_water', 25, 997),
    fluidKey: 'process_water', phase: 'L',
    description: '음극액 희석용 연화처리수'
  });

  // [211] 음극액 출구: 엑셀 원본 기준 스케일 (음극액 총 순환량 포함)
  // 엑셀 기준 NaOH=28500.56, H2O=59630.72 kg/h (순환+생산 합산)
  const s211_NaOH = 28500.56 * sf;
  const s211_H2O  = 59630.72 * sf;
  streams.push({ id: '211', name: '음극액 출구 (32% NaOH)', section: '200',
    components: { NaOH: s211_NaOH, H2O: s211_H2O },
    total_kgh: s211_NaOH + s211_H2O,
    concentration: s211_NaOH / (s211_NaOH + s211_H2O) * 100,
    pressure_kgcm2g: 0.5, temperature_C: 90, density_kgm3: dbDensity('naoh_32', 90, 1303),
    fluidKey: 'naoh_32', phase: 'L',
    description: '전해조 음극액 출구 → D-220 기액분리기'
  });

  // [212] H2O: 294.85 kg/h은 1기당 값 (5기 합산 [221]의 1474.23/5=294.85) — /5 제거
  const s212_H2 = elec.h2ProductionKgH / 5, s212_H2O = 294.85 * sf;
  streams.push({ id: '212', name: 'H₂ 가스 (음극, 1기)', section: '200',
    components: { H2: s212_H2, H2O: s212_H2O },
    total_kgh: s212_H2 + s212_H2O,
    concentration: s212_H2 / (s212_H2 + s212_H2O) * 100,
    pressure_kgcm2g: 0.45, temperature_C: 90, density_kgm3: dbDensity('h2_gas', 90, 0.273),
    fluidKey: 'h2_gas', phase: 'G',
    description: '전해조 1기 H₂ 가스 출구 → [221] 헤더'
  });

  // [213] D-220T 출구 (1기당): 엑셀 FCV-232 출구 스트림
  // NaOH = 24,100 kg/h per electrolyzer (1기), [217] = 5 × [213]
  const s213_NaOH = 24100.0 * sf;
  const s213_H2O  = 50513.0 * sf;
  streams.push({ id: '213', name: 'NaOH 32% (D-220 출구, 1기)', section: '200',
    components: { NaOH: s213_NaOH, H2O: s213_H2O },
    total_kgh: s213_NaOH + s213_H2O,
    concentration: s213_NaOH / (s213_NaOH + s213_H2O) * 100,
    pressure_kgcm2g: 5.0, temperature_C: 85, density_kgm3: dbDensity('naoh_32', 85, 1306),
    fluidKey: 'naoh_32', phase: 'L',
    description: 'D-220T 음극액 탱크 출구 (1기당, FCV-232)'
  });

  // [217] = 5기 합산 NaOH 분배 헤더 (엑셀: 5 × [213] = 120,500 NaOH, 252,565 H2O)
  // 엑셀 200 Sec 기준: NaOH=120,499.995, H2O=252,565.005, T=85°C, P=5.0 kg/cm².G
  const s217_NaOH = s213_NaOH * 5;  // 120,500 * sf
  const s217_H2O  = s213_H2O  * 5;  // 252,565 * sf
  streams.push({ id: '217', name: 'NaOH 헤더 (5기 합산)', section: '200',
    components: { NaOH: s217_NaOH, H2O: s217_H2O },
    total_kgh: s217_NaOH + s217_H2O,
    concentration: s217_NaOH / (s217_NaOH + s217_H2O) * 100,
    pressure_kgcm2g: 5.0, temperature_C: 85, density_kgm3: dbDensity('naoh_32', 85, 1306),
    fluidKey: 'naoh_32', phase: 'L',
    description: '5기 전해조 음극액 합산 NaOH 헤더 → T-240 (제품 출하 + 순환)'
  });

  // [219] NaOH 32% 제품 출구 (P-254A/B): 엑셀 기준 22,002.82 NaOH + 45,588.58 H2O
  const s219_NaOH = 22002.82 * sf;
  const s219_H2O  = 45588.58 * sf;

  // [218] 양극액 (묽은 브라인 + 용존 Cl₂): 엑셀 200 Sec 기준 T=87°C
  const s218_NaCl = 28782.38 * sf, s218_H2O = 136215.43 * sf, s218_Cl2 = 118.18 * sf;
  streams.push({ id: '218', name: '양극액 (농축 브라인 + 용존 Cl₂)', section: '200',
    components: { NaCl: s218_NaCl, H2O: s218_H2O, Cl2: s218_Cl2 },
    total_kgh: s218_NaCl + s218_H2O + s218_Cl2,
    concentration: s218_NaCl / (s218_NaCl + s218_H2O) * 100,
    pressure_kgcm2g: 5.1, temperature_C: 87, density_kgm3: dbDensity('anolyte', 87, 1089),
    fluidKey: 'anolyte', phase: 'L',
    description: 'D-210A 기액분리기 액상 (탈염소탑 D-250 피드)'
  });

  // [219] 엑셀 기준: P=3.1 kg/cm².G, T=90°C
  streams.push({ id: '219', name: 'NaOH 32% (제품/저장탱크 피드)', section: '200',
    components: { NaOH: s219_NaOH, H2O: s219_H2O },
    total_kgh: s219_NaOH + s219_H2O,
    concentration: s219_NaOH / (s219_NaOH + s219_H2O) * 100,
    pressure_kgcm2g: 3.1, temperature_C: 90, density_kgm3: dbDensity('naoh_32', 90, 1303),
    fluidKey: 'naoh_32', phase: 'L',
    description: 'P-254A/B → NaOH 저장탱크 / 300 Sec 증발농축 피드'
  });

  // [220] 엑셀 200 Sec 기준: Cl2=19,500, H2O=3,969.89, T=87°C, P=0.25 kg/cm².G
  const s220_Cl2 = elec.cl2ProductionKgH, s220_H2O = 3969.89 * sf, s220_O2 = 26.48 * sf;
  streams.push({ id: '220', name: 'Cl₂ 가스 헤더 (전체)', section: '200',
    components: { Cl2: s220_Cl2, H2O: s220_H2O, O2: s220_O2 },
    total_kgh: s220_Cl2 + s220_H2O + s220_O2,
    concentration: s220_Cl2 / (s220_Cl2 + s220_H2O + s220_O2) * 100,
    pressure_kgcm2g: 0.25, temperature_C: 87, density_kgm3: dbDensity('cl2_gas', 87, 2.05),
    fluidKey: 'cl2_gas', phase: 'G',
    description: '전전해조 Cl₂ 공통 헤더 → 400 Sec'
  });

  const s221_H2 = elec.h2ProductionKgH, s221_H2O = 1474.23 * sf;
  streams.push({ id: '221', name: 'H₂ 가스 헤더 (전체)', section: '200',
    components: { H2: s221_H2, H2O: s221_H2O },
    total_kgh: s221_H2 + s221_H2O,
    concentration: s221_H2 / (s221_H2 + s221_H2O) * 100,
    pressure_kgcm2g: 0.30, temperature_C: 90, density_kgm3: dbDensity('h2_gas', 90, 0.245),
    fluidKey: 'h2_gas', phase: 'G',
    description: '전전해조 H₂ 공통 헤더 → 600 Sec'
  });

  const s224_NaCl = 950.70 * sf, s224_H2O = 4499.30 * sf;
  streams.push({ id: '224', name: '탈염소 브라인 (D-250 출구)', section: '200',
    components: { NaCl: s224_NaCl, H2O: s224_H2O },
    total_kgh: s224_NaCl + s224_H2O,
    concentration: s224_NaCl / (s224_NaCl + s224_H2O) * 100,
    pressure_kgcm2g: 3.2, temperature_C: 86, density_kgm3: dbDensity('anolyte', 86, 1090),
    fluidKey: 'anolyte', phase: 'L',
    description: 'D-250 탈염소탑 출구 → 100 Sec 반환'
  });

  const s250_NaCl = 29733.08 * sf, s250_H2O = 145714.72 * sf;
  streams.push({ id: '250', name: '묽은 브라인 반환 (100 Sec)', section: '200',
    components: { NaCl: s250_NaCl, H2O: s250_H2O },
    total_kgh: s250_NaCl + s250_H2O,
    concentration: s250_NaCl / (s250_NaCl + s250_H2O) * 100,
    pressure_kgcm2g: 0.4, temperature_C: 90, density_kgm3: dbDensity('anolyte', 90, 1089),
    fluidKey: 'anolyte', phase: 'L',
    description: '탈염소탑 출구 → P-284A/B → 100 Sec 브라인 탱크'
  });

  // [252] 엑셀 200 Sec 기준: D-250 탈염소탑 배출 Cl₂ 가스 (141.47 kg/h)
  // 주의: 엑셀 [252]는 대형 브라인 재순환이 아닌 소량 Cl₂ 배출 가스임
  streams.push({ id: '252', name: '탈염소탑 배출 Cl₂ 가스 (D-250)', section: '200',
    components: { Cl2: 139.18 * sf, H2O: 2.29 * sf },
    total_kgh: 141.47 * sf,
    concentration: 139.18 / 141.47 * 100,
    pressure_kgcm2g: 0.2, temperature_C: 40, density_kgm3: 3.15,
    fluidKey: 'cl2_gas', phase: 'G',
    description: 'D-250 탈염소탑 배출 Cl₂ 가스 → 400 Sec 처리 (용존 Cl₂ 스트리핑)'
  });

  // [256] 엑셀 200 Sec 기준: NaCl=29,733, H2O=146,811, T=90°C, P=3.3 kg/cm².G
  // (앱 오류: [259] 연수 30,199 kg/h가 잘못 합산돼 H2O가 과다했음)
  const s256_NaCl = 29733.08 * sf, s256_H2O = 146810.72 * sf;
  streams.push({ id: '256', name: '브라인 반환 (100 Sec 피드)', section: '200',
    components: { NaCl: s256_NaCl, H2O: s256_H2O },
    total_kgh: s256_NaCl + s256_H2O,
    concentration: s256_NaCl / (s256_NaCl + s256_H2O) * 100,
    pressure_kgcm2g: 3.3, temperature_C: 90, density_kgm3: dbDensity('anolyte', 90, 1089),
    fluidKey: 'anolyte', phase: 'L',
    description: 'P-284A/B 출구 → 100 Sec 브라인 반환'
  });

  // ──────────────────────────────────────────────────────────
  // 300 SEC — NaOH 증발 농축 (32% → 50%)
  // 3효 강하막식 증발: E-320(1효) → E-330(2효) → E-340(3효)
  // ──────────────────────────────────────────────────────────
  const naoh32_total = (s217_NaOH + s217_H2O);
  const naoh_sf = sf; // NaOH 생산량도 Cl2와 동일 스케일팩터

  streams.push({ id: 'L1', name: '32% NaOH 피드 (증발입구)', section: '300',
    components: { NaOH: 21450.0 * naoh_sf, H2O: 45510.14 * naoh_sf },
    total_kgh: 66960.14 * naoh_sf,
    concentration: 32.0,
    pressure_kgcm2g: 0.0, temperature_C: 90, density_kgm3: dbDensity('naoh_32', 90, 1311),
    fluidKey: 'naoh_32', phase: 'L',
    description: '200 Sec [217] → E-340 예열기 입구'
  });

  streams.push({ id: 'L2', name: '3효 증발기 출구 (32%)', section: '300',
    components: { NaOH: 21450.0 * naoh_sf, H2O: 45510.14 * naoh_sf },
    total_kgh: 66960.14 * naoh_sf,
    concentration: 32.0,
    pressure_kgcm2g: -0.8, temperature_C: 68.4, density_kgm3: dbDensity('naoh_32', 68.4, 1362),
    fluidKey: 'naoh_32', phase: 'L',
    description: 'E-340 예열/3효 출구 → P-374A/B'
  });

  const L5_total = 58100.0 * naoh_sf;
  streams.push({ id: 'L5', name: '2효 증발기 피드 (36.4%)', section: '300',
    components: { NaOH: 21143.0 * naoh_sf, H2O: 36957.0 * naoh_sf },
    total_kgh: L5_total,
    concentration: 36.4,
    pressure_kgcm2g: -0.6, temperature_C: 109.6, density_kgm3: 1333, phase: 'L',
    description: 'E-320(1효) 출구 → P-314A/B → E-330(2효)'
  });

  const L7_total = 50850.0 * naoh_sf;
  streams.push({ id: 'L7', name: '1효 증발기 피드 (42.1%)', section: '300',
    components: { NaOH: 21422.0 * naoh_sf, H2O: 29428.0 * naoh_sf },
    total_kgh: L7_total,
    concentration: 42.1,
    pressure_kgcm2g: -0.3, temperature_C: 108.5, density_kgm3: 1394, phase: 'L',
    description: 'E-330(2효) 출구 → P-284A/B → E-320(1효, HP)'
  });

  const L10_total = 42824.4 * naoh_sf;
  streams.push({ id: 'L10', name: '50% NaOH 1효 출구', section: '300',
    components: { NaOH: 21442.0 * naoh_sf, H2O: 21382.4 * naoh_sf },
    total_kgh: L10_total,
    concentration: 50.04,
    pressure_kgcm2g: 0.0, temperature_C: 164.8, density_kgm3: 1438, phase: 'L',
    description: 'E-320(1효) 출구 → 냉각기 E-332/E-342'
  });

  streams.push({ id: 'L11', name: '50% NaOH E-332 출구', section: '300',
    components: { NaOH: 21442.0 * naoh_sf, H2O: 21382.4 * naoh_sf },
    total_kgh: L10_total,
    concentration: 50.04,
    pressure_kgcm2g: 0.0, temperature_C: 120, density_kgm3: 1469, phase: 'L',
    description: 'E-332 1단 냉각 후'
  });

  streams.push({ id: 'L12', name: '50% NaOH E-342 출구', section: '300',
    components: { NaOH: 21442.0 * naoh_sf, H2O: 21382.4 * naoh_sf },
    total_kgh: L10_total,
    concentration: 50.04,
    pressure_kgcm2g: 0.0, temperature_C: 75, density_kgm3: 1501, phase: 'L',
    description: 'E-342 2단 냉각 후'
  });

  streams.push({ id: 'L14', name: '50% NaOH 제품 (냉각 완료)', section: '300',
    components: { NaOH: 21442.0 * naoh_sf, H2O: 21382.4 * naoh_sf },
    total_kgh: L10_total,
    concentration: 50.04,
    pressure_kgcm2g: 0.0, temperature_C: 42, density_kgm3: 1524, phase: 'L',
    description: 'E-352 최종냉각 후 → T-350 저장탱크'
  });

  streams.push({ id: 'L15', name: '50% NaOH 저장탱크 출구', section: '300',
    components: { NaOH: 21442.0 * naoh_sf, H2O: 21382.4 * naoh_sf },
    total_kgh: L10_total,
    concentration: 50.0,
    pressure_kgcm2g: 0.0, temperature_C: 42, density_kgm3: 1524, phase: 'L',
    description: 'T-350 50% NaOH 출하 탱크 출구'
  });

  // Steam / condensate
  streams.push({ id: 'S1', name: '13K 스팀 (1효 가열)', section: '300',
    components: { H2O: 10713.1 * naoh_sf },
    total_kgh: 10713.1 * naoh_sf,
    pressure_kgcm2g: 13.0, temperature_C: 191, density_kgm3: 6.5, phase: 'G',
    description: '1효 증발기 E-320 가열 스팀'
  });

  streams.push({ id: 'C1', name: '응축수 (스팀 응축)', section: '300',
    components: { H2O: 10355.9 * naoh_sf },
    total_kgh: 10355.9 * naoh_sf,
    pressure_kgcm2g: 3.0, temperature_C: 126.6, density_kgm3: 938, phase: 'L',
    description: '1효 스팀 응축수 → 응축수 회수'
  });

  // ──────────────────────────────────────────────────────────
  // 400 SEC — Cl₂ 처리 / 액화 (Cl2 Processing & Liquefaction)
  // ──────────────────────────────────────────────────────────
  const cl2_sf = sf; // Cl2 계통 스케일팩터

  const s401_Cl2 = 19483.8 * cl2_sf, s401_O2 = 26.48 * cl2_sf, s401_H2O = 3969.89 * cl2_sf;
  streams.push({ id: '401', name: 'Cl₂ (수세탑 T-410 출구)', section: '400',
    components: { Cl2: s401_Cl2, O2: s401_O2, H2O: s401_H2O * 0.08 },
    total_kgh: s401_Cl2 + s401_O2 + s401_H2O * 0.08,
    concentration: s401_Cl2 / (s401_Cl2 + s401_O2 + s401_H2O * 0.08) * 100,
    pressure_kgcm2g: 0.27, temperature_C: 40, density_kgm3: 3.35, phase: 'G',
    description: 'T-410 수세탑 출구 → E-413 냉각기'
  });

  streams.push({ id: '402', name: '수세 폐수 (T-410 액상)', section: '400',
    components: { H2O: 6096.0 * cl2_sf, HCl: 21.0 * cl2_sf, Cl2: 0.9 * cl2_sf },
    total_kgh: 6117.9 * cl2_sf,
    pressure_kgcm2g: 0.0, temperature_C: 50, density_kgm3: 1050, phase: 'L',
    description: 'T-410 수세탑 폐수 → 탈염소 처리'
  });

  const s403_Cl2 = 19483.8 * cl2_sf, s403_H2O = 301.65 * cl2_sf;
  streams.push({ id: '403', name: 'Cl₂ (E-413 냉각 후)', section: '400',
    components: { Cl2: s403_Cl2, H2O: s403_H2O, O2: s401_O2 },
    total_kgh: s403_Cl2 + s403_H2O + s401_O2,
    concentration: s403_Cl2 / (s403_Cl2 + s403_H2O + s401_O2) * 100,
    pressure_kgcm2g: 0.27, temperature_C: 40, density_kgm3: 3.35, phase: 'G',
    description: 'E-413 1차 냉각기 출구 → E-423 2차 냉각기'
  });

  const s405_H2O = 92.36 * cl2_sf;
  streams.push({ id: '405', name: 'Cl₂ (E-423 냉각 후, 20°C)', section: '400',
    components: { Cl2: s403_Cl2, H2O: s405_H2O, O2: s401_O2 },
    total_kgh: s403_Cl2 + s405_H2O + s401_O2,
    concentration: s403_Cl2 / (s403_Cl2 + s405_H2O + s401_O2) * 100,
    pressure_kgcm2g: 0.27, temperature_C: 20, density_kgm3: 3.67, phase: 'G',
    description: 'E-423 2차 냉각기 출구 → T-420 1차 건조탑'
  });

  const s409_H2O = 1.02 * cl2_sf;
  streams.push({ id: '409', name: 'Cl₂ (T-420 1차건조 후)', section: '400',
    components: { Cl2: s403_Cl2, H2O: s409_H2O, O2: s401_O2 },
    total_kgh: s403_Cl2 + s409_H2O + s401_O2,
    concentration: s403_Cl2 / (s403_Cl2 + s409_H2O + s401_O2) * 100,
    pressure_kgcm2g: 0.22, temperature_C: 25, density_kgm3: 3.40, phase: 'G',
    description: 'T-420 1차 H₂SO₄ 건조탑 출구 → T-430'
  });

  const s411_H2O = 0.001 * cl2_sf;
  streams.push({ id: '411', name: 'Cl₂ (건조 완료, T-440/450 후)', section: '400',
    components: { Cl2: s403_Cl2, H2O: s411_H2O, O2: s401_O2 },
    total_kgh: s403_Cl2 + s411_H2O + s401_O2,
    concentration: 99.86,
    pressure_kgcm2g: 0.20, temperature_C: 25, density_kgm3: 3.35, phase: 'G',
    description: '건조 Cl₂ (수분 < 10 ppm) → F-424 미스트 제거기'
  });

  streams.push({ id: '413', name: 'Cl₂ (F-424 미스트 제거 후)', section: '400',
    components: { Cl2: s403_Cl2, O2: s401_O2 },
    total_kgh: s403_Cl2 + s401_O2,
    concentration: 99.86,
    pressure_kgcm2g: 0.17, temperature_C: 25, density_kgm3: 3.30, phase: 'G',
    description: 'F-424 출구 → C-470 압축기 흡입'
  });

  const s415_Cl2 = s403_Cl2, s415_O2 = s401_O2;
  streams.push({ id: '415', name: 'Cl₂ (C-470 압축 후)', section: '400',
    components: { Cl2: s415_Cl2, O2: s415_O2 },
    total_kgh: s415_Cl2 + s415_O2,
    concentration: 99.86,
    pressure_kgcm2g: 3.0, temperature_C: 40, density_kgm3: 10.79, phase: 'G',
    description: 'C-470 압축기 출구 (3.0 kg/cm².G) → 액화기 E-460'
  });

  streams.push({ id: '416', name: '98% H₂SO₄ (건조탑 피드)', section: '400',
    components: { H2SO4: 352.99 * cl2_sf, H2O: 7.20 * cl2_sf },
    total_kgh: 360.19 * cl2_sf,
    concentration: 98.0,
    pressure_kgcm2g: 3.8, temperature_C: -20, density_kgm3: 1831, phase: 'L',
    description: 'P-450A/B → 건조탑 H₂SO₄ 피드'
  });

  streams.push({ id: '418', name: '액화 Cl₂ (E-460 출구)', section: '400',
    components: { Cl2: s415_Cl2 * 0.98, O2: s415_O2 * 0.05 },
    total_kgh: s415_Cl2 * 0.98,
    concentration: 99.88,
    pressure_kgcm2g: 3.0, temperature_C: -22, density_kgm3: 1516, phase: 'L',
    description: 'E-460 액화기 출구 → D-484 수액기'
  });

  streams.push({ id: '420', name: '테일가스 (비응축 Cl₂+O₂)', section: '400',
    components: { Cl2: 402.0 * cl2_sf, O2: 8.85 * cl2_sf },
    total_kgh: 410.85 * cl2_sf,
    pressure_kgcm2g: 3.0, temperature_C: -20, density_kgm3: 12.5, phase: 'G',
    description: 'D-484/D-495 테일가스 → D-940 NaOH 흡수탑'
  });

  streams.push({ id: '421', name: '액화 Cl₂ (D-484 → D-496)', section: '400',
    components: { Cl2: 10677.9 * cl2_sf },
    total_kgh: 10677.9 * cl2_sf,
    concentration: 99.88,
    pressure_kgcm2g: 3.0, temperature_C: -17, density_kgm3: 1516, phase: 'L',
    description: 'D-484 수액기 출구 → D-496 저장탱크'
  });

  streams.push({ id: '425', name: '액화 Cl₂ 제품 (D-496 출구)', section: '400',
    components: { Cl2: 10677.9 * cl2_sf },
    total_kgh: 10677.9 * cl2_sf,
    concentration: 99.88,
    pressure_kgcm2g: 24.0, temperature_C: -17, density_kgm3: 1516, phase: 'L',
    description: 'P-494A/B → 액화 Cl₂ 출하'
  });

  streams.push({ id: '426', name: '가스상 Cl₂ 제품 (압축Cl₂)', section: '400',
    components: { Cl2: 8799.9 * cl2_sf, O2: s415_O2 * 0.5 },
    total_kgh: 8799.9 * cl2_sf,
    concentration: 99.86,
    pressure_kgcm2g: 3.0, temperature_C: 40, density_kgm3: 10.5, phase: 'G',
    description: '가스상 Cl₂ 제품 출하 (압력 유지)'
  });

  streams.push({ id: '429', name: '테일가스 (D-495 기상)', section: '400',
    components: { Cl2: 6.0 * cl2_sf, O2: 1.76 * cl2_sf },
    total_kgh: 7.76 * cl2_sf,
    pressure_kgcm2g: 3.0, temperature_C: -20, density_kgm3: 12.0, phase: 'G',
    description: 'D-495 분리기 기상 → D-940 흡수탑'
  });

  // ──────────────────────────────────────────────────────────
  // 600 SEC — H₂ 처리 (H2 Processing)
  // H₂ 냉각 → 압축 → 건조 → 제품
  // ──────────────────────────────────────────────────────────
  const h2_sf = sf;
  const h2_total = elec.h2ProductionKgH;

  // [221]은 200 Sec에서 이미 추가됨, 600 Sec에서는 [601]부터
  const s601_H2 = h2_total, s601_H2O = 1474.23 * h2_sf;
  streams.push({ id: '601', name: 'H₂ 헤더 (PCV 후)', section: '600',
    components: { H2: s601_H2, H2O: s601_H2O },
    total_kgh: s601_H2 + s601_H2O,
    concentration: s601_H2 / (s601_H2 + s601_H2O) * 100,
    pressure_kgcm2g: 0.211, temperature_C: 90, density_kgm3: 0.229, phase: 'G',
    description: 'PCV-227 후 H₂ 헤더 → E-5613 1차 냉각기'
  });

  const s602_H2O = 338.46 * h2_sf;
  streams.push({ id: '602', name: 'H₂ (E-5613 1차냉각 후, 41°C)', section: '600',
    components: { H2: s601_H2, H2O: s602_H2O },
    total_kgh: s601_H2 + s602_H2O,
    concentration: s601_H2 / (s601_H2 + s602_H2O) * 100,
    pressure_kgcm2g: 0.211, temperature_C: 41, density_kgm3: 0.141, phase: 'G',
    description: 'E-5613 1차 냉각기 출구 → E-5630 2차 냉각기 (CCW)'
  });

  const s603_H2O = 50.74 * h2_sf;
  streams.push({ id: '603', name: 'H₂ (E-5630 2차냉각 후, 10°C)', section: '600',
    components: { H2: s601_H2, H2O: s603_H2O },
    total_kgh: s601_H2 + s603_H2O,
    concentration: s601_H2 / (s601_H2 + s603_H2O) * 100,
    pressure_kgcm2g: 0.210, temperature_C: 10, density_kgm3: 0.112, phase: 'G',
    description: 'E-5630 2차 냉각기 출구 → D-610 수분 분리기'
  });

  streams.push({ id: '604', name: '수분 분리 응축수 (D-610)', section: '600',
    components: { H2O: 3000.0 * h2_sf },
    total_kgh: 3000.0 * h2_sf,
    temperature_C: 38, density_kgm3: 996, phase: 'L',
    description: 'D-610 기액분리기 액상 → T-620 응축수 탱크'
  });

  const s607_H2O = 15.53 * h2_sf;
  streams.push({ id: '607', name: 'H₂ (D-610 분리 후)', section: '600',
    components: { H2: s601_H2, H2O: s607_H2O },
    total_kgh: s601_H2 + s607_H2O,
    concentration: s601_H2 / (s601_H2 + s607_H2O) * 100,
    pressure_kgcm2g: 0.210, temperature_C: 10, density_kgm3: 0.106, phase: 'G',
    description: 'D-610 기상 출구 → C-620 H₂ 압축기'
  });

  streams.push({ id: '608', name: 'H₂ (C-620 압축 후, 23 kg/cm².G)', section: '600',
    components: { H2: s601_H2, H2O: s607_H2O },
    total_kgh: s601_H2 + s607_H2O,
    concentration: s601_H2 / (s601_H2 + s607_H2O) * 100,
    pressure_kgcm2g: 23.0, temperature_C: 40, density_kgm3: 1.857, phase: 'G',
    description: 'C-620 H₂ 압축기 출구 → E-5680 냉각기'
  });

  const s609_H2O = 2.60 * h2_sf;
  streams.push({ id: '609', name: 'H₂ (E-5680 냉각 후)', section: '600',
    components: { H2: s601_H2, H2O: s609_H2O },
    total_kgh: s601_H2 + s609_H2O,
    concentration: s601_H2 / (s601_H2 + s609_H2O) * 100,
    pressure_kgcm2g: 23.0, temperature_C: 10, density_kgm3: 2.012, phase: 'G',
    description: 'E-5680 냉각 후 → D-650 실리카겔 제습기'
  });

  streams.push({ id: '610', name: 'H₂ (D-650 제습 후, 건조)', section: '600',
    components: { H2: s601_H2, H2O: s609_H2O * 0.17 },
    total_kgh: s601_H2 + s609_H2O * 0.17,
    concentration: 99.53,
    pressure_kgcm2g: 23.0, temperature_C: 80, density_kgm3: 1.613, phase: 'G',
    description: 'D-650 제습기 출구 → E-5682 최종냉각기'
  });

  streams.push({ id: '611', name: 'H₂ 제품 (공급 헤더)', section: '600',
    components: { H2: s601_H2 },
    total_kgh: s601_H2,
    concentration: 99.53,
    pressure_kgcm2g: 23.0, temperature_C: 40, density_kgm3: 1.857, phase: 'G',
    description: 'D-680 H₂ 공급 헤더 → 소비처 (HCl 합성, 연료 등)'
  });

  streams.push({ id: '612', name: 'CCW 냉각수 (E-5630 피드)', section: '600',
    components: { H2O: 25731.54 * h2_sf },
    total_kgh: 25731.54 * h2_sf,
    temperature_C: 7, density_kgm3: 998, phase: 'L',
    description: '저온 냉각수 (Chilled Water) → E-5630'
  });

  streams.push({ id: '613', name: '응축수 (D-650 제습기)', section: '600',
    components: { H2O: 204.92 * h2_sf },
    total_kgh: 204.92 * h2_sf,
    pressure_kgcm2g: 3.0, temperature_C: 143.9, density_kgm3: 2.145, phase: 'L',
    description: 'D-650 재생 응축수'
  });

  // ──────────────────────────────────────────────────────────
  // 요약 계산
  // ──────────────────────────────────────────────────────────
  // ── 요약: 용액 총 유량(solution total) 기준 ─────────────────
  // 검증:
  //   naoh32 / cl2 ≈ 1.1/0.323 ≈ 3.40  (dry 1.1배 → 32% 용액 3.40배)
  //   naoh50 / cl2 ≈ 1.1/0.500 ≈ 2.20  (dry 1.1배 → 50% 용액 2.20배)
  // 요약: [217]은 5기 합산 헤더(순환 포함), 제품량은 [219] 기준으로 계산
  const s219_total_kgh = s219_NaOH + s219_H2O;   // 32% NaOH 제품 유량 (출하 기준)
  const L14_NaOH_kgh   = 21442.0 * naoh_sf;       // 50% NaOH 용액 내 드라이 NaOH
  const L14_H2O_kgh    = 21382.4 * naoh_sf;       // 50% NaOH 용액 내 H2O
  const L14_total_kgh  = L14_NaOH_kgh + L14_H2O_kgh; // 50% 용액 총 유량

  const summary = {
    cl2_tonDay:        elec.cl2ProductionTonD,
    naoh32_tonDay:     s219_total_kgh * 24 / 1000,   // 32% NaOH 제품 ton/day ([219] 기준)
    naoh50_tonDay:     L14_total_kgh  * 24 / 1000,   // 50% NaOH 용액 ton/day
    h2_tonDay:         elec.h2ProductionKgH * 24 / 1000,
    naclUsage_tonDay:  elec.naclConsumptionKgH * 24 / 1000,
    saltUsage_tonDay:  elec.naclConsumptionKgH * 24 / 1000 / 0.985,
  };

  return { electrolyzerResult: elec, streams, summary };
}
