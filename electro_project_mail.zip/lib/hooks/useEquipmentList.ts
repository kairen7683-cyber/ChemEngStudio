// =====================================================================
// 장치 선택 시 연결 스트림/유체 자동 감지 훅
// PFD의 하드코딩 노드와 userNodes를 합쳐서 목록 제공
// =====================================================================

import { useMemo } from 'react';
import { usePFDStore } from '@/lib/stores/pfdStore';

// ─── PFD 유체컬러 → fluidType 매핑 ─────────────────────────────────
// PFDCanvas의 C 객체 색상과 물성DB key를 연결
const COLOR_TO_FLUID_KEY: Record<string, string> = {
  '#4fc3f7': 'brine_25',     // brine blue
  '#81d4fa': 'brine_25',
  '#e0f7fa': 'brine_25',
  '#b2ebf2': 'brine_25',
  '#80cbc4': 'brine_25',
  '#66bb6a': 'naoh_32',      // NaOH green
  '#4caf50': 'naoh_32',
  '#a5d6a7': 'naoh_32',
  '#c8e6c9': 'naoh_32',
  '#ffb300': 'cl2_gas',      // Cl2 yellow
  '#ffc107': 'cl2_gas',
  '#ffe082': 'cl2_gas',
  '#e53935': 'h2_gas',       // H2 red
  '#ef5350': 'h2_gas',
  '#2196f3': 'process_water',
  '#42a5f5': 'process_water',
};

// 유체 타입 문자열 → physicalProperties key 매핑 (SelectionPanel의 fluidType 사용)
const FLUID_TYPE_TO_KEY: Record<string, string> = {
  'Brine':          'brine_25',
  'NaOH':           'naoh_32',
  'NaOH32':         'naoh_32',
  'NaOH50':         'naoh_50',
  'Cl2':            'cl2_gas',
  'H2':             'h2_gas',
  'HCl':            'hcl_31',
  'H2SO4':          'h2so4_98',
  'Water':          'process_water',
  'ProcessWater':   'process_water',
  'CoolingWater':   'cooling_water',
  'Catholyte':      'catholyte',
  'Anolyte':        'anolyte',
};

// ─── 장치 타입 ───────────────────────────────────────────────────────
export type EquipmentItem = {
  id: string;
  tag: string;
  name: string;
  type: string;    // 'pump' | 'tower' | 'tank' | ...
  section: string;
  /** 연결된 유체 키 (physicalProperties) — 감지 실패 시 undefined */
  fluidKey?: string;
  /** 연결된 스트림 번호 */
  streamIds: string[];
  /** 연결된 엣지들의 fluidType (SelectionPanel 저장값) */
  fluidType?: string;
};

// PFD 하드코딩 펌프/타워 정적 데이터
// (PFDCanvas.tsx 의 nodes 배열에서 추출 — 동기화 유지 필요)
const STATIC_EQUIPMENT: EquipmentItem[] = [
  // 100 Sec pumps
  { id: 'P044', tag: 'P-044A/B', name: 'Brine Saturation Pump',    type: 'pump',  section: '100', fluidKey: 'brine_25',    streamIds: ['004'] },
  { id: 'P033', tag: 'P-033A/B', name: 'Brine Storage Pump',       type: 'pump',  section: '100', fluidKey: 'brine_25',    streamIds: ['013'] },
  { id: 'P014', tag: 'P-014A/B', name: 'Reaction Tank Pump',       type: 'pump',  section: '100', fluidKey: 'brine_25',    streamIds: ['022'] },
  { id: 'P154', tag: 'P-154A/B', name: 'Brine Filter Feed Pump',   type: 'pump',  section: '100', fluidKey: 'brine_25',    streamIds: ['102'] },
  { id: 'P084', tag: 'P-084A/B', name: 'Brine Feed Pump (to Elec)',type: 'pump',  section: '100', fluidKey: 'brine_fed',   streamIds: ['104'] },
  // 100 Sec towers
  { id: 'T160', tag: 'T-160',    name: 'Ion Exchange Resin Tower', type: 'tower', section: '100', fluidKey: 'brine_25',    streamIds: ['102', '104'] },
  // 200 Sec pumps
  { id: 'P244', tag: 'P-244A/B', name: 'NaOH Circulating Pump',   type: 'pump',  section: '200', fluidKey: 'naoh_32',     streamIds: ['211', '208'] },
  { id: 'P254', tag: 'P-254A/B', name: 'NaOH Product Pump',       type: 'pump',  section: '200', fluidKey: 'naoh_32',     streamIds: ['217'] },
  { id: 'P284', tag: 'P-284A/B', name: 'Brine Return Pump',       type: 'pump',  section: '200', fluidKey: 'anolyte',     streamIds: ['250', '252'] },
  { id: 'P264', tag: 'P-264A/B', name: 'Dechlorinated Brine Pump',type: 'pump',  section: '200', fluidKey: 'brine_25',    streamIds: ['224'] },
  { id: 'P314', tag: 'P-314A/B', name: 'Brine Return Pump (200)', type: 'pump',  section: '200', fluidKey: 'anolyte',     streamIds: ['259'] },
  { id: 'P374', tag: 'P-374A/B', name: 'Depleted Brine Pump',     type: 'pump',  section: '200', fluidKey: 'anolyte',     streamIds: ['250'] },
  // 400 Sec pumps
  { id: 'P413a', tag: 'P-413A/B', name: 'H2SO4 Pump (Cl2 Drying)',type: 'pump', section: '400', fluidKey: 'h2so4_98',    streamIds: ['414-1'] },
  { id: 'P413c', tag: 'P-413C/D', name: 'H2SO4 Pump (Cl2 Drying)',type: 'pump', section: '400', fluidKey: 'h2so4_98',    streamIds: ['416'] },
  { id: 'P494',  tag: 'P-494A/B', name: 'Liq Cl2 Transfer Pump',  type: 'pump', section: '400', fluidKey: 'cl2_gas',     streamIds: ['421'] },
  { id: 'P496',  tag: 'P-496A/B', name: 'Liq Cl2 Product Pump',   type: 'pump', section: '400', fluidKey: 'cl2_gas',     streamIds: ['425'] },
  { id: 'P450',  tag: 'P-450A/B', name: 'Cl2 Scrubber Pump',      type: 'pump', section: '400', fluidKey: 'process_water',streamIds: ['404'] },
  // 400 Sec towers
  { id: 'T410',  tag: 'T-410',    name: 'Cl2 Scrubber Tower',     type: 'tower', section: '400', fluidKey: 'cl2_gas',    streamIds: ['220', '403'] },
  { id: 'T420',  tag: 'T-420',    name: 'H2SO4 Drying Tower 1',  type: 'tower', section: '400', fluidKey: 'cl2_gas',    streamIds: ['406', '409'] },
  { id: 'T430',  tag: 'T-430',    name: 'H2SO4 Drying Tower 2',  type: 'tower', section: '400', fluidKey: 'cl2_gas',    streamIds: ['409', '411'] },
  { id: 'T440',  tag: 'T-440',    name: 'H2SO4 Drying Tower 3',  type: 'tower', section: '400', fluidKey: 'cl2_gas',    streamIds: ['411', '413'] },
  { id: 'T450',  tag: 'T-450',    name: 'NaOH Scrubber Tower',   type: 'tower', section: '400', fluidKey: 'naoh_32',    streamIds: ['420'] },
  { id: 'D940',  tag: 'D-940',    name: 'NaOH Tail Gas Absorber',type: 'tower', section: '400', fluidKey: 'naoh_32',    streamIds: ['426'] },
  // 600 Sec pumps
  { id: 'P613',  tag: 'P-613A/B', name: 'H2 Drain Pump',         type: 'pump', section: '600', fluidKey: 'process_water',streamIds: ['604'] },
];

// ─── 메인 훅 ─────────────────────────────────────────────────────────
export function useEquipmentList(typeFilter?: 'pump' | 'tower') {
  // 개별 selector 로 shallow 비교 없이 안정된 참조 확보
  const userNodes    = usePFDStore(s => s.userNodes);
  const edgeFluidMap = usePFDStore(s => s.edgeFluidMap ?? {});

  return useMemo(() => {
    // 정적 장치 목록 + user 생성 장치
    const allEquipment: EquipmentItem[] = [
      ...STATIC_EQUIPMENT,
      ...userNodes
        .filter(n => !typeFilter || n.type === typeFilter)
        .map(n => ({
          id:        n.id,
          tag:       n.tag,
          name:      n.name,
          type:      n.type,
          section:   n.section,
          streamIds: [] as string[],
          fluidKey:  undefined as string | undefined,
          fluidType: undefined as string | undefined,
        })),
    ];

    // edgeFluidMap에서 각 장치의 fluidType 보완
    const fluidByNode: Record<string, string> = {};
    Object.entries(edgeFluidMap).forEach(([edgeId, fluidType]) => {
      const parts = edgeId.split('-');
      if (parts.length >= 2) {
        const nodeIds = parts.slice(1);
        nodeIds.forEach(nid => {
          if (!fluidByNode[nid] && fluidType && fluidType !== 'custom') {
            fluidByNode[nid] = fluidType;
          }
        });
      }
    });

    const resolveFluidKey = (fluidType?: string, defaultKey?: string): string | undefined => {
      if (!fluidType) return defaultKey;
      return FLUID_TYPE_TO_KEY[fluidType] ?? defaultKey;
    };

    const enriched = allEquipment.map(eq => {
      const detectedFluidType = fluidByNode[eq.id];
      return {
        ...eq,
        fluidType: detectedFluidType ?? eq.fluidType,
        fluidKey:  resolveFluidKey(detectedFluidType, eq.fluidKey),
      };
    });

    return typeFilter
      ? enriched.filter(e => e.type === typeFilter)
      : enriched;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userNodes, edgeFluidMap, typeFilter]);
}

/** 장치 tag로 조회 */
export function useEquipmentByTag(tag: string): EquipmentItem | undefined {
  const all = useEquipmentList();
  return all.find(e => e.tag === tag || e.id === tag);
}
